var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var jy;
(function (jy) {
    /**
     * ## 主体UI的容器
     * 1. 当屏幕长或者宽任意一边小于`基准尺寸(basis)`时
     *      * 首先根据基准尺寸的窄边得到缩放比
     *      * 然后将容器按此缩放比进行缩放
     *      * 根据容器内UI的布局配置，基于当前屏幕大小进行重新布局
     * 2. 如果屏幕的长或者宽都大于或者等于`基准尺寸(basis)`时
     *      * 容器内UI不做缩放
     *      * 直接根据容器内UI的布局配置，基于当前屏幕大小进行重新布局
     *
     * @export
     * @class MainUIContainer
     * @extends {egret.Sprite}
     */
    var MainUIContainer = (function (_super) {
        __extends(MainUIContainer, _super);
        function MainUIContainer() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        MainUIContainer.prototype.onResize = function () {
            var host = this._host;
            var stage = host.stage || egret.sys.$TempStage;
            var basis = this._basis;
            var sw = stage.stageWidth, sh = stage.stageHeight, bw = basis.width, bh = basis.height;
            var dw = sw, dh = sh, lw = sw, lh = sh;
            var scale = 1;
            if (sw < bw || sh < bh) {
                var result = jy.getFixedLayout(sw, sh, bw, bh);
                dh = result.dh;
                dw = result.dw;
                lw = result.lw;
                lh = result.lh;
                scale = result.scale;
            }
            this._lw = lw;
            this._lh = lh;
            host.x = 0;
            host.y = 0;
            host.scaleY = host.scaleX = scale;
            this.layoutAll();
        };
        MainUIContainer.prototype.add = function (d, type, offsetRect, hide) {
            var raw = d.suiRawRect;
            var result = jy.Layout.getLayoutPos(raw.width, raw.height, offsetRect.width, offsetRect.height, type);
            var dx = raw.x - offsetRect.x;
            var dy = raw.y - offsetRect.y;
            var oh = dx - result.x;
            var ov = dy - result.y;
            this.addLayout(d, type, raw, oh, ov, false, false, hide);
        };
        MainUIContainer.prototype.binLayout = function (bin) {
            if (bin.type == 0 /* FullScreen */) {
                var dis = bin.dis;
                var host = this._host;
                var scale = host.scaleX;
                dis.x = bin.hoffset * scale;
                dis.y = bin.voffset * scale;
                var stage = host.stage || egret.sys.$TempStage;
                dis.width = stage.stageWidth / scale;
                dis.height = stage.stageHeight / scale;
            }
            else {
                _super.prototype.binLayout.call(this, bin);
            }
        };
        return MainUIContainer;
    }(jy.LayoutContainer));
    jy.MainUIContainer = MainUIContainer;
    __reflect(MainUIContainer.prototype, "jy.MainUIContainer");
})(jy || (jy = {}));
//# sourceMappingURL=MainUIContainer.js.map