var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var jy;
(function (jy) {
    var LayoutContainer = (function () {
        function LayoutContainer(basis, host) {
            this.$layoutBins = new jy.ArraySet();
            host = host || new egret.Sprite();
            this._host = host;
            this._basis = basis;
            jy.on(-1998 /* ReLayout */, this.onResize, this);
            host.on("removedFromStage" /* REMOVED_FROM_STAGE */, this.offStage, this);
            host.on("addedToStage" /* ADDED_TO_STAGE */, this.onStage, this);
            if (host.stage) {
                this.onStage();
            }
        }
        /**
         * 重置尺寸
         *
         * @param {Size} basis
         *
         * @memberOf LayoutContainer
         */
        LayoutContainer.prototype.resetBasis = function (basis) {
            this._basis = basis;
        };
        LayoutContainer.prototype.onStage = function () {
            this._host.stage.on("resize" /* RESIZE */, this.onResize, this);
            this.onResize();
        };
        LayoutContainer.prototype.offStage = function () {
            egret.sys.$TempStage.off("resize" /* RESIZE */, this.onResize, this);
        };
        Object.defineProperty(LayoutContainer.prototype, "view", {
            get: function () {
                return this._host;
            },
            enumerable: true,
            configurable: true
        });
        /**
         * 移除视图
         *
         * @param {egret.DisplayObject} dis
         * @returns
         */
        LayoutContainer.prototype.remove = function (dis) {
            dis.$layoutHost = undefined;
            return this.$layoutBins.delete(dis.hashCode);
        };
        LayoutContainer.prototype.addLayout = function (dis, type, size, hoffset, voffset, outerV, outerH, hide) {
            if (type === void 0) { type = 5 /* TOP_LEFT */; }
            var list = this.$layoutBins;
            size = size || dis;
            var key = dis.hashCode;
            if (list.get(key)) {
                return;
            }
            dis.$layoutHost = this;
            var bin = { dis: dis, type: type, hoffset: hoffset, voffset: voffset, outerV: outerV, outerH: outerH, size: size };
            list.set(key, bin);
            if (hide) {
                jy.removeDisplay(dis);
            }
            else {
                this._host.addChild(dis);
            }
            var stage = dis.stage;
            if (stage) {
                this.binLayout(bin);
            }
            //不管在不在舞台上，都应该监听
            dis.on("addedToStage" /* ADDED_TO_STAGE */, this.onAdded, this);
        };
        LayoutContainer.prototype.onAdded = function (e) {
            var dis = e.currentTarget;
            var host = dis.$layoutHost;
            if (host) {
                var set = host.$layoutBins;
                if (set) {
                    var bin = set.get(dis.hashCode);
                    if (bin) {
                        this.binLayout(bin);
                    }
                }
            }
        };
        LayoutContainer.prototype.binLayout = function (bin) {
            var dis = bin.dis, type = bin.type, hoffset = bin.hoffset, voffset = bin.voffset, outerV = bin.outerV, outerH = bin.outerH, size = bin.size;
            var pt = jy.Temp.SharedPoint1;
            jy.Layout.getLayoutPos(size.width, size.height, this._lw, this._lh, type, pt, hoffset, voffset, outerV, outerH);
            dis.x = pt.x;
            dis.y = pt.y;
        };
        LayoutContainer.prototype.$doLayout = function () {
            jy.Global.callLater(this.layoutAll, 0, this);
        };
        LayoutContainer.prototype.layoutAll = function () {
            var set = this.$layoutBins;
            if (set) {
                var list = set.rawList;
                for (var i = 0, len = list.length; i < len;) {
                    this.binLayout(list[i++]);
                }
            }
        };
        LayoutContainer.MIN = Object.freeze({ width: 0, height: 0 });
        return LayoutContainer;
    }());
    jy.LayoutContainer = LayoutContainer;
    __reflect(LayoutContainer.prototype, "jy.LayoutContainer");
    /**
     * @param sw 舞台宽度
     * @param sh 舞台高度
     * @param bw 要调整的可视对象宽度
     * @param bh 要调整的可视对象高度
     * @param {boolean} [isWide=false] fixedNarrow 还是 fixedWide，默认按fixedNarrow布局
     */
    function getFixedLayout(sw, sh, bw, bh, isWide) {
        var dw = sw, dh = sh;
        var scaleX = sw / bw;
        var scaleY = sh / bh;
        var lw = bw;
        var lh = bh;
        var scale;
        if (scaleX < scaleY == !isWide) {
            scale = scaleX;
            dh = scaleX * bh;
            lh = bh * sh / dh;
        }
        else {
            scale = scaleY;
            dw = scaleY * bw;
            lw = bw * sw / dw;
        }
        return { dw: dw, dh: dh, scale: scale, lw: lw, lh: lh };
    }
    jy.getFixedLayout = getFixedLayout;
})(jy || (jy = {}));
//# sourceMappingURL=LayoutContainer.js.map