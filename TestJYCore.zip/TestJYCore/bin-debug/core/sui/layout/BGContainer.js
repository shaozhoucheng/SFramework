var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var jy;
(function (jy) {
    /**
     * ## 背景图容器
     * 1. 当屏幕长或者宽任意一边大于`基准尺寸(basis)`时
     *      * 首先根据基准尺寸的宽边得到缩放比
     *      * 然后将容器按此缩放比进行缩放
     *      * 根据容器内UI的布局配置，基于当前屏幕大小进行重新布局
     * 2. 如果屏幕的长或者宽都小于或者等于`基准尺寸(basis)`时
     *      * 直接根据容器内UI的布局配置，基于当前屏幕大小进行重新布局
     *
     * @export
     * @class MainUIContainer
     * @extends {egret.Sprite}
     */
    var BGContainer = (function (_super) {
        __extends(BGContainer, _super);
        function BGContainer(basis, host, layout) {
            if (layout === void 0) { layout = 6 /* TOP_CENTER */; }
            var _this = _super.call(this, basis, host) || this;
            _this._layout = layout;
            return _this;
        }
        BGContainer.prototype.onResize = function () {
            var host = this._host;
            var stage = host.stage || egret.sys.$TempStage;
            var basis = this._basis;
            var sw = stage.stageWidth, sh = stage.stageHeight, bw = basis.width, bh = basis.height;
            var dw = sw, dh = sh, lw = sw, lh = sh;
            var scale = 1;
            if (sw > bw || sh > bh) {
                var result = jy.getFixedLayout(sw, sh, bw, bh, true);
                dh = result.dh;
                dw = result.dw;
                lw = result.lw;
                lh = result.lh;
                scale = result.scale;
            }
            else {
                dw = bw;
                dh = bh;
            }
            this._lw = lw;
            this._lh = lh;
            host.scaleY = host.scaleX = scale;
            var pt = jy.Temp.SharedPoint1;
            jy.Layout.getLayoutPos(dw, dh, sw, sh, this._layout, pt);
            host.x = pt.x;
            host.y = pt.y;
            this.layoutAll();
        };
        return BGContainer;
    }(jy.LayoutContainer));
    jy.BGContainer = BGContainer;
    __reflect(BGContainer.prototype, "jy.BGContainer");
})(jy || (jy = {}));
//# sourceMappingURL=BGContainer.js.map