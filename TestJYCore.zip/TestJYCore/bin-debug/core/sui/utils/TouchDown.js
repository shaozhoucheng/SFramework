var jy;
(function (jy) {
    var _$TDOpt = Object.freeze({ int: { x: 1, y: 1 } });
    /**
     * TouchDown显示对象放大效果
     */
    var TouchDown;
    (function (TouchDown) {
        /**
         * 绑定组件
         *
         * @param {TouchDownItem} item
         */
        function bind(item) {
            if (item) {
                item.on("touchBegin" /* TOUCH_BEGIN */, touchBegin);
            }
        }
        TouchDown.bind = bind;
        /**
         * 解绑组件
         *
         * @param {TouchDownItem} item
         */
        function loose(item) {
            if (item) {
                item.off("touchBegin" /* TOUCH_BEGIN */, touchBegin);
                clearEndListener(item);
            }
        }
        TouchDown.loose = loose;
        /**
         * 重置组件
         *
         * @export
         * @param {TouchDownItem} item
         */
        function reset(item) {
            var data = item.$_tdi;
            if (data) {
                var tween = data.tween, raw = data.raw;
                if (tween) {
                    jy.Global.removeTween(tween);
                }
                if (raw) {
                    var x = raw.x, y = raw.y, scaleX = raw.scaleX, scaleY = raw.scaleY;
                    item.x = x;
                    item.y = y;
                    item.scaleX = scaleX;
                    item.scaleY = scaleY;
                }
                item.$_tdi = undefined;
            }
        }
        TouchDown.reset = reset;
        function clearEndListener(item) {
            item.off("touchEnd" /* TOUCH_END */, touchEnd);
            item.off("touchCancel" /* TOUCH_CANCEL */, touchEnd);
            item.off("touchReleaseOutside" /* TOUCH_RELEASE_OUTSIDE */, touchEnd);
            item.off("removedFromStage" /* REMOVED_FROM_STAGE */, touchEnd);
        }
        function touchBegin(e) {
            var target = e.target;
            target.on("touchEnd" /* TOUCH_END */, touchEnd);
            target.on("touchCancel" /* TOUCH_CANCEL */, touchEnd);
            target.on("touchReleaseOutside" /* TOUCH_RELEASE_OUTSIDE */, touchEnd);
            target.on("removedFromStage" /* REMOVED_FROM_STAGE */, touchEnd);
            var data = target.$_tdi;
            if (data) {
                var tween = data.tween;
                if (tween) {
                    jy.Global.removeTween(tween);
                }
            }
            else {
                target.$_tdi = data = {};
                var x = target.x, y = target.y, scaleX = target.scaleX, scaleY = target.scaleY;
                data.raw = { x: x, y: y, scaleX: scaleX, scaleY: scaleY };
            }
            var raw = data.raw;
            data.tween = jy.Global.getTween(target, _$TDOpt).to({ x: raw.x - target.width * 0.0625 /* Multi */, y: raw.y - target.height * 0.0625 /* Multi */, scaleX: 1.125 /* Scale */ * raw.scaleX, scaleY: 1.125 /* Scale */ * raw.scaleY }, 100, jy.Ease.quadOut);
        }
        function touchEnd(e) {
            var target = e.target;
            clearEndListener(target);
            var raw = target.$_tdi;
            if (raw) {
                var tween = raw.tween;
                if (tween) {
                    jy.Global.removeTween(tween);
                }
                raw.tween = jy.Global.getTween(target, _$TDOpt)
                    .to(raw.raw, 100, jy.Ease.quadOut)
                    .call(endComplete, null, target);
            }
        }
        function endComplete(target) {
            target.$_tdi = undefined;
        }
    })(TouchDown = jy.TouchDown || (jy.TouchDown = {}));
})(jy || (jy = {}));
//# sourceMappingURL=TouchDown.js.map