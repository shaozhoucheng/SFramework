var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var jy;
(function (jy) {
    /**
     * 单选按钮组
     */
    var Group = (function (_super) {
        __extends(Group, _super);
        function Group() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this._list = [];
            _this._selectedIndex = -1;
            return _this;
        }
        /**
         * 添加单个组件
         *
         * @param {IGroupItem} item
         */
        Group.prototype.addItem = function (item) {
            if (item) {
                this._list.pushOnce(item);
                item.on("touchTap" /* TOUCH_TAP */, this.touchHandler, this);
            }
        };
        Group.prototype.getAllItems = function () {
            return this._list;
        };
        Object.defineProperty(Group.prototype, "length", {
            get: function () {
                return this._list.length;
            },
            enumerable: true,
            configurable: true
        });
        /**
         * 获取 IGroupItem
         *
         * @param {number} idx
         * @returns
         */
        Group.prototype.getItemAt = function (idx) {
            idx = idx >>> 0;
            return this._list[idx];
        };
        Group.prototype.removeAt = function (idx) {
            idx = idx >>> 0;
            var list = this._list;
            if (idx < list.length) {
                var item = list[idx];
                this.removeItem(item);
                return item;
            }
        };
        Group.prototype.touchHandler = function (e) {
            this.$setSelectedItem(e.target);
        };
        /**
         * 移除单个组件
         *
         * @param {IGroupItem} item
         */
        Group.prototype.removeItem = function (item) {
            if (item) {
                if (this._selectedItem == item) {
                    this.$setSelectedItem();
                }
                this._list.remove(item);
                item.off("touchTap" /* TOUCH_TAP */, this.touchHandler, this);
                return item;
            }
        };
        Group.prototype.addItems = function () {
            for (var i = 0; i < arguments.length; i++) {
                var item = arguments[i];
                this.addItem(item);
            }
        };
        Object.defineProperty(Group.prototype, "selectedItem", {
            get: function () {
                return this._selectedItem;
            },
            /**
             * 设置选中组件
             */
            set: function (item) {
                this.$setSelectedItem(item);
            },
            enumerable: true,
            configurable: true
        });
        Group.prototype.$setSelectedItem = function (item) {
            var _selectedItem = this._selectedItem;
            if (_selectedItem != item) {
                if (_selectedItem) {
                    _selectedItem.selected = false;
                }
                var idx = -1;
                if (item) {
                    idx = this._list.indexOf(item);
                    if (~idx) {
                        item.selected = true;
                    }
                    else {
                        item = undefined;
                        jy.ThrowError("Group 设置的组件未添加到该组");
                    }
                }
                this._selectedItem = item;
                this._selectedIndex = idx;
                return this.dispatch(-1020 /* GROUP_CHANGE */);
            }
        };
        Object.defineProperty(Group.prototype, "selectedIndex", {
            get: function () {
                return this._selectedIndex;
            },
            /**
             * 设置选中索引
             */
            set: function (idx) {
                this.$setSelectedIndex(idx);
            },
            enumerable: true,
            configurable: true
        });
        Group.prototype.$setSelectedIndex = function (idx) {
            if (this._selectedIndex != idx) {
                var item = idx >= 0 ? this._list[idx] : undefined;
                this.$setSelectedItem(item);
            }
        };
        Group.prototype.clear = function () {
            var list = this._list;
            for (var i = 0; i < list.length; i++) {
                var item = list[i];
                item.off("touchTap" /* TOUCH_TAP */, this.touchHandler, this);
            }
            list.length = 0;
            this._selectedIndex = -1;
        };
        Group.prototype.onRecycle = function () {
            this.clear();
        };
        return Group;
    }(egret.EventDispatcher));
    jy.Group = Group;
    __reflect(Group.prototype, "jy.Group");
})(jy || (jy = {}));
//# sourceMappingURL=Group.js.map