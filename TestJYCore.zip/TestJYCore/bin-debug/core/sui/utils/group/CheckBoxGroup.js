var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var jy;
(function (jy) {
    /**
     * 多选分组
     *
     * @export
     * @class CheckBoxGroup
     * @extends {Group}
     * @author 3tion
     */
    var CheckBoxGroup = (function (_super) {
        __extends(CheckBoxGroup, _super);
        function CheckBoxGroup(maxSelected) {
            var _this = _super.call(this) || this;
            /**
             * 选中的选项
             *
             * @protected
             * @type {IGroupItem[]}
             */
            _this._selected = [];
            _this.maxSelected = maxSelected;
            return _this;
        }
        CheckBoxGroup.prototype.removeItem = function (item) {
            if (item) {
                this._list.remove(item);
                this._selected.remove(item);
                item.off("touchTap" /* TOUCH_TAP */, this.touchHandler, this);
                return item;
            }
        };
        CheckBoxGroup.prototype.$setSelectedItem = function (item) {
            if (!item) {
                return;
            }
            // 检查是否勾选
            var selected = this._selected;
            var changed, idx = -1;
            if (item.selected) {
                item.selected = false;
                selected.remove(item);
                idx = selected.length - 1;
                changed = true;
            }
            else {
                //未选中，检查当前选中的按钮是否达到最大数量
                var maxSelected = this.maxSelected || Infinity;
                if (selected.length < maxSelected) {
                    item.selected = true;
                    idx = selected.pushOnce(item);
                    changed = true;
                }
                else {
                    return this.dispatch(-1021 /* GROUP_FULL */);
                }
            }
            if (changed) {
                this._selectedIndex = idx;
                this._selectedItem = !~idx ? selected[idx] : undefined;
                return this.dispatch(-1020 /* GROUP_CHANGE */);
            }
        };
        Object.defineProperty(CheckBoxGroup.prototype, "selected", {
            /**
             * 获取选中的选项
             *
             * @readonly
             */
            get: function () {
                return this._selected;
            },
            enumerable: true,
            configurable: true
        });
        CheckBoxGroup.prototype.clear = function () {
            _super.prototype.clear.call(this);
            this._selected.length = 0;
        };
        return CheckBoxGroup;
    }(jy.Group));
    jy.CheckBoxGroup = CheckBoxGroup;
    __reflect(CheckBoxGroup.prototype, "jy.CheckBoxGroup");
})(jy || (jy = {}));
//# sourceMappingURL=CheckBoxGroup.js.map