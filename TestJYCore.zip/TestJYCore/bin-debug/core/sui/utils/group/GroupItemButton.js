var jy;
(function (jy) {
    /**
     * 绑定按钮和文本框，让文本框的点击，可以触发按钮的选中事件
     *
     * @export
     */
    jy.GroupItemButton = (function () {
        var TE = "touchTap" /* TOUCH_TAP */;
        var ButtonKey = "$gib$btn";
        var TextFieldKey = "$gib$txt";
        return {
            /**
             *
             * 绑定按钮和文本框
             * @param {Button} btn
             * @param {egret.TextField} txt
             */
            bind: function (btn, txt) {
                if (!txt[ButtonKey]) {
                    txt[ButtonKey] = btn;
                }
                else if (true) {
                    jy.ThrowError("\u91CD\u590D\u7ED1\u5B9A\u4E86\u6587\u672C\u6846\u548C\u6309\u94AE");
                }
                txt.touchEnabled = true;
                txt.on(TE, onTE);
                var old = btn[TextFieldKey];
                if (old) {
                    if (old[ButtonKey] == btn) {
                        delete old[ButtonKey];
                        old.off(TE, onTE);
                    }
                }
                btn[TextFieldKey] = txt;
            },
            /**
             * 接触按钮和文本框的绑定
             *
             * @param {Button} btn
             */
            loose: function (btn) {
                var txt = btn[TextFieldKey];
                if (txt) {
                    delete btn[TextFieldKey];
                    if (txt[ButtonKey] == btn) {
                        delete txt[ButtonKey];
                        txt.off(TE, onTE);
                    }
                }
            }
        };
        function onTE(e) {
            var txt = e.currentTarget;
            var btn = txt[ButtonKey];
            btn.dispatchEvent(e);
        }
    })();
})(jy || (jy = {}));
//# sourceMappingURL=GroupItemButton.js.map