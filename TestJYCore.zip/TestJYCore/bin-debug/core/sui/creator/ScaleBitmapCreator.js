var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var jy;
(function (jy) {
    var ScaleBitmapCreator = (function (_super) {
        __extends(ScaleBitmapCreator, _super);
        function ScaleBitmapCreator() {
            return _super.call(this) || this;
        }
        ScaleBitmapCreator.prototype.parseSelfData = function (data) {
            var _this = this;
            var mdata = data[0];
            var textureIndex = mdata[2];
            if (textureIndex < 0) {
                this.isjpg = true;
            }
            var rectData = data[1];
            var flag = data[0] != 0;
            var rectData2 = mdata[1];
            var width = rectData2[3];
            var height = rectData2[4];
            if (rectData) {
                var rect = new egret.Rectangle(rectData[0], rectData[1], rectData[2], rectData[3]);
            }
            this._createT = function () {
                var suiData = _this._suiData;
                var bitmap = new egret.Bitmap();
                // let inx = textureIndex;
                // let img = suiData.pngtexs;
                // if(!this.ispng){
                //     inx = -1-textureIndex;
                //     img = suiData.jpgtexs;
                // }
                bitmap.scale9Grid = rect;
                if (flag) {
                    bitmap.texture = suiData.getTexture(textureIndex); //img[inx];//suiData.imgs[textureIndex];
                    bitmap.width = width;
                    bitmap.height = height;
                    _this.bindEvent(bitmap);
                }
                return bitmap;
            };
        };
        return ScaleBitmapCreator;
    }(jy.BitmapCreator));
    jy.ScaleBitmapCreator = ScaleBitmapCreator;
    __reflect(ScaleBitmapCreator.prototype, "jy.ScaleBitmapCreator");
})(jy || (jy = {}));
//# sourceMappingURL=ScaleBitmapCreator.js.map