var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var jy;
(function (jy) {
    /**
     * 艺术字
     */
    var ArtText = (function (_super) {
        __extends(ArtText, _super);
        function ArtText() {
            var _this = _super.call(this) || this;
            /**
             * 垂直对齐方式
             *
             * @private
             * @type {LayoutTypeVertical}
             */
            _this._align = 4 /* TOP */;
            _this.artwidth = 0;
            _this._maxHeight = 0;
            return _this;
        }
        ArtText.prototype.refreshBMD = function () {
            for (var _i = 0, _a = this.$children; _i < _a.length; _i++) {
                var bmp = _a[_i];
                bmp.refreshBMD();
            }
        };
        /**
         * 设置垂直对齐规则
         *
         * @param {LayoutTypeVertical} value
         */
        ArtText.prototype.setVerticalAlign = function (value) {
            if (this._align != value) {
                this._align = value;
            }
        };
        ArtText.prototype.$setValue = function (val) {
            if (this._value == val)
                return;
            if (val == undefined)
                val = "";
            this._value = val;
            var tempval = val + "";
            var len = tempval.length;
            var key;
            var txs = this.textures;
            var children = this.$children;
            var numChildren = this.numChildren;
            var bmp;
            var ox = 0;
            var hgap = this.hgap || 0;
            var _maxHeight = 0;
            for (var i = 0; i < len; i++) {
                key = tempval.charAt(i);
                if (i < numChildren) {
                    bmp = children[i];
                }
                else {
                    bmp = new egret.Bitmap();
                    this.addChild(bmp);
                }
                var tx = txs[key];
                if (!tx) {
                    if (true) {
                        jy.ThrowError("\u4F20\u5165\u4E86\u7EB9\u7406\u4E2D\u6CA1\u6709\u7684\u6570\u636E[" + key + "]");
                    }
                    continue;
                }
                if (tx.textureHeight > _maxHeight) {
                    _maxHeight = tx.textureHeight;
                }
                bmp.x = ox;
                bmp.texture = null;
                bmp.texture = tx;
                ox += tx.textureWidth + hgap;
            }
            this.artwidth = ox - hgap;
            for (i = numChildren - 1; i >= len; i--) {
                this.$doRemoveChild(i);
            }
            this._maxHeight = _maxHeight;
            this.checkAlign();
        };
        Object.defineProperty(ArtText.prototype, "value", {
            get: function () {
                return this._value;
            },
            set: function (val) {
                this.$setValue(val);
            },
            enumerable: true,
            configurable: true
        });
        ArtText.prototype.$getWidth = function () {
            return this.artwidth;
        };
        ArtText.prototype.checkAlign = function () {
            var children = this.$children;
            var _maxHeight = this._maxHeight;
            switch (this._align) {
                case 4 /* TOP */:
                    children.forEach(function (bmp) {
                        bmp.y = 0;
                    });
                    break;
                case 12 /* BOTTOM */:
                    children.forEach(function (bmp) {
                        bmp.y = _maxHeight - bmp.height;
                    });
                    break;
                case 8 /* MIDDLE */:
                    children.forEach(function (bmp) {
                        bmp.y = _maxHeight - bmp.height >> 1;
                    });
                    break;
            }
        };
        ArtText.prototype.dispose = function () {
            _super.prototype.dispose.call(this);
            jy.removeDisplay(this);
        };
        return ArtText;
    }(jy.Component));
    jy.ArtText = ArtText;
    __reflect(ArtText.prototype, "jy.ArtText");
    /**
     *
     * @author gushuai
     *
     */
    var ArtTextCreator = (function (_super) {
        __extends(ArtTextCreator, _super);
        function ArtTextCreator() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        ArtTextCreator.prototype.parseSelfData = function (data) {
            var _this = this;
            var splitStr = data[0];
            var len = splitStr.length;
            var suiData = this._suiData;
            // const imgs = suiData.pngtexs;
            var txs = {};
            for (var i = 0; i < len; i++) {
                var tx = suiData.getTexture(data[i + 1]); //imgs[data[i + 1]];
                var key = splitStr.charAt(i);
                txs[key] = tx;
            }
            this._txs = txs;
            jy.refreshTexs(suiData, this);
            this._createT = function () {
                var shape = new ArtText();
                _this.bindEvent(shape);
                shape.textures = txs;
                return shape;
            };
        };
        ArtTextCreator.prototype.bindEvent = function (bmp) {
            bmp.on("addedToStage" /* ADDED_TO_STAGE */, this.onAddedToStage, this);
            bmp.on("removedFromStage" /* REMOVED_FROM_STAGE */, this.onRemoveFromStage, this);
        };
        ArtTextCreator.prototype.onAddedToStage = function (e) {
            var suiData = this._suiData;
            if (suiData) {
                var bmp = e.currentTarget;
                suiData.checkRefreshBmp(bmp);
            }
        };
        ArtTextCreator.prototype.onRemoveFromStage = function () {
            var suiData = this._suiData;
            if (suiData) {
                var bmd = suiData.pngbmd;
                bmd.using--;
                bmd.lastUseTime = jy.Global.now;
            }
        };
        return ArtTextCreator;
    }(jy.BaseCreator));
    jy.ArtTextCreator = ArtTextCreator;
    __reflect(ArtTextCreator.prototype, "jy.ArtTextCreator");
})(jy || (jy = {}));
//# sourceMappingURL=ArtTextCreator.js.map