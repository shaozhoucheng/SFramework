var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var jy;
(function (jy) {
    /**
     * 进度条
     * @author 3tion
     *
     */
    var ProgressBar = (function (_super) {
        __extends(ProgressBar, _super);
        function ProgressBar() {
            var _this = _super.call(this) || this;
            _this._labelFun = ProgressBar.defaultLabelFunction;
            _this._value = 0;
            _this._maxValue = 1;
            /**
             * 背景和bar的差值
             *
             * @protected
             */
            _this._delta = 0;
            return _this;
        }
        Object.defineProperty(ProgressBar.prototype, "labelFun", {
            get: function () {
                return this._labelFun;
            },
            /**自定义文本显示方法*/
            set: function (value) {
                if (this._labelFun != value) {
                    this._labelFun = value;
                    this.refresh();
                }
            },
            enumerable: true,
            configurable: true
        });
        /**
         * 设置进度条宽度
         *
         * @param {number} width
         */
        ProgressBar.prototype.setWidth = function (width) {
            var _a = this, bg = _a.bg, bar = _a.bar, tf = _a.tf;
            if (bg) {
                bg.width = width;
            }
            bar.width = width - this._delta;
        };
        Object.defineProperty(ProgressBar.prototype, "skin", {
            set: function (skin) {
                if (this._skin != skin) {
                    this._skin = skin;
                    var bg = skin.bg, bar = skin.bar, tf = skin.tf;
                    this.bar = bar;
                    this._barWidth = bar.width;
                    if (bg) {
                        this.bg = bg;
                        this._delta = bg.width - bar.width;
                    }
                    this.tf = tf;
                }
            },
            enumerable: true,
            configurable: true
        });
        /*设置进度*/
        ProgressBar.prototype.progress = function (value, maxValue) {
            if (value < 0) {
                value = 0;
            }
            if (maxValue < 0) {
                if (true) {
                    jy.ThrowError("进度条最大宽度不应小等于0");
                }
                maxValue = 0.00001;
            }
            if (value > maxValue) {
                value = maxValue;
            }
            this._value = value;
            this._maxValue = maxValue;
            this.refresh();
        };
        /*更新文本显示*/
        ProgressBar.prototype.updateLabel = function () {
            var tf = this.tf;
            var fun = this._labelFun;
            if (tf && fun) {
                tf.text = fun(this._value, this._maxValue);
            }
        };
        ProgressBar.prototype.getPercent = function () {
            return this._value / this._maxValue;
        };
        /*更新进度条显示*/
        ProgressBar.prototype.updateBar = function () {
            var bar = this.bar;
            var v = this.getPercent() * this._barWidth;
            if (this.useMask) {
                var rect = bar.scrollRect;
                if (!rect) {
                    rect = new egret.Rectangle(0, 0, 0, bar.height);
                }
                rect.width = v;
                bar.scrollRect = rect;
            }
            else {
                bar.width = v;
            }
        };
        /*更新显示*/
        ProgressBar.prototype.refresh = function () {
            this.updateLabel();
            this.updateBar();
        };
        ProgressBar.defaultLabelFunction = function (value, maxValue) {
            return value + " / " + maxValue;
        };
        return ProgressBar;
    }(jy.Component));
    jy.ProgressBar = ProgressBar;
    __reflect(ProgressBar.prototype, "jy.ProgressBar");
    /**
     * 进度条创建
     *
     */
    var ProgressBarCreator = (function (_super) {
        __extends(ProgressBarCreator, _super);
        function ProgressBarCreator() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        ProgressBarCreator.prototype.parseSelfData = function (data) {
            var _this = this;
            this._createT = function () {
                var progressBar = new ProgressBar();
                var len = data.length;
                var item, tf, bar, bg;
                for (var i = 0; i < len; i++) {
                    item = data[i];
                    if (item) {
                        var dis = _this.createElement(item);
                        if (i == 0) {
                            tf = dis;
                        }
                        else if (i == 1) {
                            bar = dis;
                        }
                        else if (i == 2) {
                            bg = dis;
                        }
                    }
                }
                if (bg) {
                    progressBar.addChild(bg);
                }
                if (bar) {
                    progressBar.addChild(bar);
                }
                if (tf) {
                    progressBar.addChild(tf);
                }
                progressBar.skin = { bg: bg, bar: bar, tf: tf };
                return progressBar;
            };
        };
        return ProgressBarCreator;
    }(jy.BaseCreator));
    jy.ProgressBarCreator = ProgressBarCreator;
    __reflect(ProgressBarCreator.prototype, "jy.ProgressBarCreator");
    /**
     * MC进度条创建
     *
     * @export
     * @class MCProgressCreator
     * @extends {BaseCreator<ProgressBar>}
     */
    var MCProgressCreator = (function (_super) {
        __extends(MCProgressCreator, _super);
        function MCProgressCreator() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        MCProgressCreator.prototype.parseSelfData = function (data) {
            var suiData = this._suiData;
            var framesData = jy.MovieClipCreator.prototype.$getFramesData(data);
            this._createT = function () {
                var mc = new jy.MovieClip(data, framesData, suiData);
                var bar = new ProgressBar();
                bar.addChild(mc);
                bar.skin = mc;
                return bar;
            };
        };
        return MCProgressCreator;
    }(jy.BaseCreator));
    jy.MCProgressCreator = MCProgressCreator;
    __reflect(MCProgressCreator.prototype, "jy.MCProgressCreator");
})(jy || (jy = {}));
//# sourceMappingURL=ProgressBarCreator.js.map