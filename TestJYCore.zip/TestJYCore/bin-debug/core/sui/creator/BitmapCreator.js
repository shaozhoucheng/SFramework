var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var jy;
(function (jy) {
    /**
     * 位图的创建器
     * @author 3tion
     *
     */
    var BitmapCreator = (function (_super) {
        __extends(BitmapCreator, _super);
        function BitmapCreator(value) {
            var _this = _super.call(this) || this;
            _this._suiData = value;
            return _this;
        }
        BitmapCreator.prototype.parseSelfData = function (data) {
            var _this = this;
            if (typeof data === "number") {
                if (data < 0) {
                    this.isjpg = true;
                }
                this._createT = function () {
                    var bmp = new egret.Bitmap;
                    bmp.texture = _this._suiData.getTexture(data);
                    _this.bindEvent(bmp);
                    return bmp;
                };
            }
        };
        BitmapCreator.prototype.bindEvent = function (bmp) {
            bmp.on("addedToStage" /* ADDED_TO_STAGE */, this.onAddedToStage, this);
            bmp.on("removedFromStage" /* REMOVED_FROM_STAGE */, this.onRemoveFromStage, this);
        };
        BitmapCreator.prototype.onAddedToStage = function (e) {
            var suiData = this._suiData;
            if (suiData) {
                var bmp = e.currentTarget;
                suiData.checkRefreshBmp(bmp, this.isjpg);
            }
        };
        BitmapCreator.prototype.onRemoveFromStage = function (e) {
            var suiData = this._suiData;
            if (suiData) {
                var bmd = this.isjpg ? suiData.jpgbmd : suiData.pngbmd;
                bmd.using--;
                bmd.lastUseTime = jy.Global.now;
            }
        };
        return BitmapCreator;
    }(jy.BaseCreator));
    jy.BitmapCreator = BitmapCreator;
    __reflect(BitmapCreator.prototype, "jy.BitmapCreator");
})(jy || (jy = {}));
//# sourceMappingURL=BitmapCreator.js.map