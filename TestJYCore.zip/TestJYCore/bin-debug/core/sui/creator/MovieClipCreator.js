var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var jy;
(function (jy) {
    var MovieClip = (function (_super) {
        __extends(MovieClip, _super);
        function MovieClip(data, framesData, suiData) {
            var _this = _super.call(this) || this;
            /**
             * 是否循环
             * 默认循环播放
             */
            _this.loop = true;
            /**
             * 每帧播放时长
             *
             * @type {number}
             */
            _this.timePerFrame = 100;
            _this.suiData = suiData;
            var compsData = data[0];
            /**
             * 组件字典
             */
            var comps;
            if (compsData) {
                var sm = jy.singleton(jy.SuiResManager);
                var j = 0;
                comps = [];
                for (var i = 0; i < compsData.length; i++) {
                    var dis = sm.createComponent(compsData[i], suiData, _this);
                    if (dis instanceof egret.DisplayObject) {
                        comps[j++] = dis;
                    }
                }
            }
            else {
                comps = jy.Temp.EmptyArray;
            }
            _this.compData = comps;
            _this.framesData = framesData;
            _this.totalFrame = framesData.length;
            _this.stop(0);
            return _this;
        }
        /**
         * 停在某一帧或当前帧
         * 索引从0开始
         * @param {number} [frame]
         */
        MovieClip.prototype.stop = function (frame) {
            var cf = this.validateFrame(this.getFrame(frame));
            this.playing = false;
            this.render(cf);
            this.currentFrame = cf;
            this.off("enterFrame" /* ENTER_FRAME */, this.doRender, this);
        };
        MovieClip.prototype.play = function (frame) {
            this.currentFrame = this.getFrame(frame);
            this.playing = true;
            this._nt = jy.Global.now + this.timePerFrame;
            this.on("enterFrame" /* ENTER_FRAME */, this.doRender, this);
        };
        MovieClip.prototype.doRender = function () {
            var now = jy.Global.now;
            var nt = this._nt;
            if (nt < now) {
                var cf = this.currentFrame;
                var timePerFrame = this.timePerFrame;
                //需要增加的帧数
                var delta = (now - nt) / timePerFrame | 0;
                cf = this.validateFrame(cf + 1 + delta);
                this.render(cf);
                this.currentFrame = cf;
                this._nt = nt + (delta + 1) * timePerFrame;
            }
        };
        MovieClip.prototype.validateFrame = function (cf) {
            var totalFrame = this.totalFrame;
            if (cf >= totalFrame) {
                if (this.loop) {
                    cf = cf % totalFrame;
                }
                else {
                    //只到最后一帧
                    cf = totalFrame - 1;
                }
            }
            return cf;
        };
        MovieClip.prototype.getFrame = function (frame) {
            return frame == undefined ? this.currentFrame : frame;
        };
        MovieClip.prototype.render = function (frame) {
            var frameData = this.framesData[frame];
            if (frameData && frameData.key != this.currentFrame) {
                var dict = this.compData;
                var sm = jy.singleton(jy.SuiResManager);
                var tc = sm.sharedTFCreator;
                var suiData = this.suiData;
                //清理子对象
                this.removeChildren();
                for (var _i = 0, _a = frameData.data; _i < _a.length; _i++) {
                    var dat = _a[_i];
                    var idx = void 0, pData = void 0, comp = void 0, textData = void 0;
                    if (Array.isArray(dat)) {
                        idx = dat[0];
                        pData = dat[1];
                        textData = dat[2];
                    }
                    else {
                        idx = dat;
                    }
                    if (idx == -1) {
                        comp = sm.createComponent(pData, suiData, this);
                    }
                    else {
                        comp = dict[idx];
                        if (comp instanceof egret.DisplayObject) {
                            this.addChild(comp);
                            if (pData) {
                                jy.SuiResManager.initBaseData(comp, pData);
                            }
                            if (comp instanceof egret.TextField) {
                                if (!textData) {
                                    textData = comp.rawTextData;
                                }
                                sm.sharedTFCreator.initTextData(comp, textData);
                            }
                        }
                    }
                }
            }
        };
        return MovieClip;
    }(jy.Component));
    jy.MovieClip = MovieClip;
    __reflect(MovieClip.prototype, "jy.MovieClip");
    /**
     * MC创建器
     *
     * @export
     * @class MovieClipCreator
     * @extends {BaseCreator<MovieClip>}
     */
    var MovieClipCreator = (function (_super) {
        __extends(MovieClipCreator, _super);
        function MovieClipCreator() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        MovieClipCreator.prototype.parseSelfData = function (data) {
            var suiData = this._suiData;
            var framesData = this.$getFramesData(data);
            this._createT = function () { return new MovieClip(data, framesData, suiData); };
        };
        MovieClipCreator.prototype.$getFramesData = function (data) {
            var framesData = [];
            var j = 0;
            //整理数据，补全非关键帧
            for (var _i = 0, _a = data[1]; _i < _a.length; _i++) {
                var mcData = _a[_i];
                var frameCount = mcData[0], frameData = mcData[1];
                var key = j;
                for (var i = 0; i < frameCount; i++) {
                    framesData[j++] = { key: key, data: frameData };
                }
            }
            return framesData;
        };
        return MovieClipCreator;
    }(jy.BaseCreator));
    jy.MovieClipCreator = MovieClipCreator;
    __reflect(MovieClipCreator.prototype, "jy.MovieClipCreator");
})(jy || (jy = {}));
//# sourceMappingURL=MovieClipCreator.js.map