var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var jy;
(function (jy) {
    /**
     * 按钮
     * 在fla中 按钮只是需要1帧
     * 按钮帧数对应的状态为
     * 第1帧  启用 未选中
     * 第2帧  启用 选中
     * 第3帧  禁用 未选中
     * 第4帧  禁用 选中
     *
     * 第4帧 没有，会用 第3帧代替
     * 第3帧 或者 第2帧 没有，会用第一帧代替
     * @author 3tion
     *
     */
    var Button = (function (_super) {
        __extends(Button, _super);
        function Button() {
            var _this = _super.call(this) || this;
            _this._label = "";
            jy.TouchDown.bind(_this);
            return _this;
        }
        Button.prototype.bindChildren = function () {
            if (this.txtLabel) {
                this.addChild(this.txtLabel);
            }
            this.refresh(true);
        };
        Object.defineProperty(Button.prototype, "label", {
            /**
             * 获取按钮上的标签
             */
            get: function () {
                return this._label;
            },
            /**
             * 设置按钮上的标签
             */
            set: function (value) {
                if (this._label != value) {
                    this.$setLabel(value);
                }
            },
            enumerable: true,
            configurable: true
        });
        Button.prototype.$setLabel = function (value) {
            var tf = this.txtLabel;
            if (tf) {
                tf.setHtmlText(value);
                this._label = value;
            }
        };
        Button.prototype.$setEnabled = function (value) {
            _super.prototype.$setEnabled.call(this, value);
            this.refresh();
        };
        Object.defineProperty(Button.prototype, "selected", {
            /**
             * 获取当前按钮选中状态
             */
            get: function () {
                return this._selected;
            },
            /**
             * 设置选中
             */
            set: function (value) {
                if (this._selected != value) {
                    this.$setSelected(value);
                }
            },
            enumerable: true,
            configurable: true
        });
        Button.prototype.$setSelected = function (value) {
            this._selected = value;
            this.refresh();
        };
        Button.prototype.refresh = function (changed) {
            var frame = this.$getBtnFrame();
            var bmp = this.bitmaps[frame];
            var old = this._currentBmp;
            if (!bmp) {
                bmp = this.bitmaps[0];
            }
            if (old != bmp) {
                changed = true;
                jy.removeDisplay(old);
                this._currentBmp = bmp;
            }
            if (changed) {
                if (this.floor) {
                    _super.prototype.addChild.call(this, this.floor);
                }
                if (bmp) {
                    _super.prototype.addChild.call(this, bmp);
                }
                if (this.txtLabel) {
                    _super.prototype.addChild.call(this, this.txtLabel);
                }
                if (this.ceil) {
                    _super.prototype.addChild.call(this, this.ceil);
                }
                if (this._children) {
                    _super.prototype.addChild.call(this, this._children);
                }
            }
        };
        /**
         * 获取按钮的帧数
         *
         * @returns
         */
        Button.prototype.$getBtnFrame = function () {
            return +!this._enabled << 1 | (+this._selected);
        };
        /**
         * 绑定TOUCH_TAP的回调
         *
         * @template T
         * @param {{ (this: T, e?: egret.Event): any }} handler
         * @param {T} [thisObject]
         * @param {number} [priority]
         * @param {boolean} [useCapture]
         */
        Button.prototype.bindTouch = function (handler, thisObject, priority, useCapture) {
            this.on("touchTap" /* TOUCH_TAP */, handler, thisObject, useCapture, priority);
        };
        /**
         * 解除TOUCH_TAP的回调的绑定
         *
         * @param {Function} handler
         * @param {*} thisObject
         * @param {boolean} [useCapture]
         *
         * @memberOf Button
         */
        Button.prototype.looseTouch = function (handler, thisObject, useCapture) {
            this.off("touchTap" /* TOUCH_TAP */, handler, thisObject, useCapture);
        };
        Button.prototype.addChild = function (child) {
            var children = this._children;
            if (!children) {
                this._children = children = new egret.DisplayObjectContainer;
                this.refresh(true);
            }
            children.addChild(child);
            return child;
        };
        Button.prototype.dispose = function () {
            _super.prototype.dispose.call(this);
            jy.TouchDown.loose(this);
        };
        return Button;
    }(jy.Component));
    jy.Button = Button;
    __reflect(Button.prototype, "jy.Button", ["jy.IButton", "jy.Component", "jy.ComponentWithEnable"]);
    /**
     * 按钮创建器
     * @author 3tion
     *
     */
    var ButtonCreator = (function (_super) {
        __extends(ButtonCreator, _super);
        function ButtonCreator() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        ButtonCreator.prototype.parseSelfData = function (data) {
            var _this = this;
            var tc;
            if (data[0]) {
                tc = new jy.TextFieldCreator();
                tc.setBaseData(data[0][1]);
                tc.parseSelfData(data[0][2]);
            }
            var bcs = [];
            for (var i = 1; i < 5; i++) {
                var dat = data[i];
                if (dat) {
                    bcs[i - 1] = dat;
                }
            }
            this._createT = function () {
                var btn = new Button();
                if (tc) {
                    btn.txtLabel = tc.get();
                }
                var bmps = [];
                for (var i = 0; i < 4; i++) {
                    if (bcs[i]) {
                        bmps[i] = _this.createElement(bcs[i]);
                    }
                }
                if (!bmps[1]) {
                    bmps[1] = bmps[0];
                }
                var useDisableFilter = false;
                if (!bmps[2]) {
                    bmps[2] = bmps[0];
                    useDisableFilter = true;
                }
                if (!bmps[3]) {
                    bmps[3] = bmps[2];
                }
                btn.bitmaps = bmps;
                if (data[5]) {
                    btn.floor = _this.createElement(data[5]);
                    useDisableFilter = true;
                }
                if (data[6]) {
                    btn.ceil = _this.createElement(data[6]);
                    useDisableFilter = true;
                }
                btn.useDisFilter = useDisableFilter;
                return btn;
            };
        };
        return ButtonCreator;
    }(jy.BaseCreator));
    jy.ButtonCreator = ButtonCreator;
    __reflect(ButtonCreator.prototype, "jy.ButtonCreator");
})(jy || (jy = {}));
//# sourceMappingURL=ButtonCreator.js.map