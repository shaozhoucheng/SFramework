var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var jy;
(function (jy) {
    var Slider = (function (_super) {
        __extends(Slider, _super);
        function Slider() {
            var _this = _super.call(this) || this;
            _this.initBaseContainer();
            _this.touchChildren = _this.touchEnabled = true;
            _this.thumb.touchEnabled = true;
            _this.bgline.touchEnabled = true;
            _this.addListener();
            return _this;
        }
        Slider.prototype.addListener = function () {
            this.thumb.on("touchBegin" /* TOUCH_BEGIN */, this.onThumbBegin, this);
            this.on("addedToStage" /* ADDED_TO_STAGE */, this.onAddToStage, this);
        };
        Slider.prototype.onAddToStage = function (e) {
            if (this._barEnabled) {
                this.stage.on("touchEnd" /* TOUCH_END */, this.bgOut, this);
            }
        };
        Object.defineProperty(Slider.prototype, "barEnabled", {
            /*使不使用底条点击直接设值 */
            set: function (value) {
                this._barEnabled = value;
                if (value) {
                    this.bgline.on("touchBegin" /* TOUCH_BEGIN */, this.bgClick, this);
                    if (this.stage) {
                        this.stage.on("touchEnd" /* TOUCH_END */, this.bgOut, this);
                    }
                }
                else {
                    this.bgline.off("touchBegin" /* TOUCH_BEGIN */, this.bgClick, this);
                    if (this.stage) {
                        this.bgline.off("touchEnd" /* TOUCH_END */, this.bgOut, this);
                    }
                }
            },
            enumerable: true,
            configurable: true
        });
        Slider.prototype.bgClick = function (e) {
            this._lastThumbX = this.thumb.localToGlobal().x;
            var currentX = e.stageX;
            this.tipTxt.visible = true;
            this.calculatevalue(currentX);
            this.tipTxt.text = this.value.toString();
        };
        Slider.prototype.bgOut = function (e) {
            this.tipTxt.visible = false;
        };
        Slider.prototype.onThumbBegin = function (e) {
            this._lastThumbX = this.thumb.localToGlobal().x;
            this.stage.on("touchMove" /* TOUCH_MOVE */, this.mouseMove, this);
            this.thumb.on("touchEnd" /* TOUCH_END */, this.onThumbEnd, this);
            this.thumb.on("touchReleaseOutside" /* TOUCH_RELEASE_OUTSIDE */, this.onThumbEnd, this);
            this.tipTxt.visible = true;
        };
        Slider.prototype.onThumbEnd = function (e) {
            this.stage.off("touchMove" /* TOUCH_MOVE */, this.mouseMove, this);
            this.thumb.off("touchEnd" /* TOUCH_END */, this.onThumbEnd, this);
            this.thumb.off("touchReleaseOutside" /* TOUCH_RELEASE_OUTSIDE */, this.onThumbEnd, this);
        };
        Slider.prototype.mouseMove = function (e) {
            var currentX = e.stageX;
            this.calculatevalue(currentX);
            this.tipTxt.text = this.value.toString();
        };
        Slider.prototype.calculatevalue = function (currentX) {
            var sub = currentX - this._lastThumbX;
            var steps;
            var value;
            if (Math.abs(sub) >= this._perStepPixel) {
                steps = sub / this._perStepPixel;
                steps = Math.round(steps);
                value = this.value + steps * this._step;
                if (value <= this._minValue) {
                    value = this._minValue;
                }
                if (value >= this._maxVlaue) {
                    value = this._maxVlaue;
                }
                this.value = value;
                this._lastThumbX = this.thumb.localToGlobal().x;
                this.tipTxt.x = this.thumb.x + this._halfThumbWidth - 40;
            }
        };
        Slider.prototype.initBaseContainer = function () {
            this.thumb = new egret.Sprite();
            this.bgline = new egret.Sprite();
            this.addChild(this.bgline);
            this.addChild(this.thumb);
            this.tipTxt = new egret.TextField();
            this.tipTxt.y = -12;
            this.tipTxt.textAlign = egret.HorizontalAlign.CENTER;
            this.tipTxt.width = 80;
            this.tipTxt.size = 12;
            this.tipTxt.bold = false;
            this.addChild(this.tipTxt);
        };
        /**
         * 设置底条新式
         *
         * @param {ScaleBitmap} bg (description)
         */
        Slider.prototype.setBg = function (bg) {
            this._bgBmp = bg;
            this.bgline.addChild(bg);
            this._width = bg.width;
        };
        /**
         * 设置滑块样式
         *
         * @param {egret.Bitmap} tb (description)
         */
        Slider.prototype.setThumb = function (tb) {
            this.thumb.x = tb.x;
            this.thumb.y = tb.y;
            tb.x = tb.y = 0;
            this.thumb.addChild(tb);
            this._halfThumbWidth = tb.width * 0.5;
        };
        Object.defineProperty(Slider.prototype, "value", {
            get: function () {
                return this._value;
            },
            set: function (val) {
                if (this._value == val)
                    return;
                this._value = val;
                this.dispatch(-1040 /* VALUE_CHANGE */);
                this.thumb.x = ((val - this._minValue) / this._step) * this._perStepPixel - this._halfThumbWidth;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(Slider.prototype, "width", {
            get: function () {
                return this._width;
            },
            /**
             * 设置底条宽度
             */
            set: function (value) {
                if (this._width == value)
                    return;
                this._width = value;
                if (this._bgBmp) {
                    this._bgBmp.width = value;
                }
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(Slider.prototype, "height", {
            get: function () {
                return this._height;
            },
            /**
             * 设置底条高度
             */
            set: function (value) {
                if (this._height == value)
                    return;
                this._height = value;
                if (this._bgBmp) {
                    this._bgBmp.height = value;
                }
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(Slider.prototype, "maxVlaue", {
            set: function (value) {
                this._maxVlaue = value;
                this.checkStepPixel();
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(Slider.prototype, "minValue", {
            set: function (value) {
                this._minValue = value;
                this.checkStepPixel();
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(Slider.prototype, "step", {
            /**
             * 滑块移动一个单位的值
             */
            set: function (value) {
                this._step = value;
                this.checkStepPixel();
            },
            enumerable: true,
            configurable: true
        });
        Slider.prototype.checkStepPixel = function () {
            this._perStepPixel = this.bgline.width / ((this._maxVlaue - this._minValue) / this._step);
        };
        return Slider;
    }(jy.Component));
    jy.Slider = Slider;
    __reflect(Slider.prototype, "jy.Slider");
    var SliderCreator = (function (_super) {
        __extends(SliderCreator, _super);
        function SliderCreator() {
            return _super.call(this) || this;
        }
        SliderCreator.prototype.parseSelfData = function (data) {
            this.uiData = data;
            this.txtCreator = new jy.TextFieldCreator();
            this.scale9Creator = new jy.ScaleBitmapCreator();
            this.bitmapCreator = new jy.BitmapCreator(this._suiData);
            this.suiManager = jy.singleton(jy.SuiResManager);
            this._createT = this.createSlider;
        };
        SliderCreator.prototype.createSlider = function () {
            var slider = new Slider();
            var comData = this.uiData;
            var len = comData.length;
            var tmpData;
            var type;
            var sourceData = this._suiData.sourceComponentData;
            var index;
            var sourceArr;
            var name;
            for (var i = 0; i < len; i++) {
                tmpData = comData[i];
                type = tmpData[0];
                index = tmpData[2];
                if (type == 0) {
                    this.bitmapCreator.parseSelfData(index);
                    var bmp = this.bitmapCreator.get();
                    slider.setThumb(bmp);
                }
                else if (type == 5) {
                    sourceArr = sourceData[type];
                    name = sourceArr[0][index];
                    var sc = this.suiManager.createDisplayObject(this._suiData.key, name, tmpData[1]);
                    slider.setBg(sc);
                }
            }
            return slider;
        };
        return SliderCreator;
    }(jy.BaseCreator));
    jy.SliderCreator = SliderCreator;
    __reflect(SliderCreator.prototype, "jy.SliderCreator");
})(jy || (jy = {}));
//# sourceMappingURL=SliderCreator.js.map