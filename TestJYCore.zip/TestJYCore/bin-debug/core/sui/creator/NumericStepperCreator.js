var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var jy;
(function (jy) {
    var NumericStepper = (function (_super) {
        __extends(NumericStepper, _super);
        function NumericStepper() {
            var _this = _super.call(this) || this;
            _this._minValue = 1;
            return _this;
        }
        NumericStepper.prototype.bindChildren = function () {
            var _a = this, txtbg = _a.txtbg, subBtn = _a.subBtn, addBtn = _a.addBtn, txt = _a.txt;
            this.addChild(txtbg);
            this.addChild(subBtn);
            this.addChild(addBtn);
            subBtn.enabled = true;
            addBtn.enabled = true;
            subBtn.bindTouch(this.subValue, this);
            addBtn.bindTouch(this.addValue, this);
            this.addChild(txt);
            if (this.minBtn) {
                this.addChild(this.minBtn);
                this.minBtn.enabled = true;
                this.minBtn.bindTouch(this.setMinValue, this);
            }
            if (this.maxBtn) {
                this.addChild(this.maxBtn);
                this.maxBtn.enabled = true;
                this.maxBtn.bindTouch(this.setMaxValue, this);
                this._width = this.maxBtn.width + this.maxBtn.x;
            }
            else {
                this._width = this.addBtn.width + this.addBtn.x;
            }
        };
        Object.defineProperty(NumericStepper.prototype, "width", {
            get: function () {
                return this._width;
            },
            set: function (value) {
                if (this._width == value)
                    return;
                var sub = value - this._width;
                this.txt.width += sub;
                this.txtbg.width += sub;
                this.addBtn.x += sub;
                if (this.maxBtn)
                    this.maxBtn.x += sub;
                this._width = value;
            },
            enumerable: true,
            configurable: true
        });
        NumericStepper.prototype.setMinValue = function (e) {
            if (this._minValue)
                this.value = this._minValue;
        };
        NumericStepper.prototype.addValue = function (e) {
            if (this.value < this._maxValue) {
                this.value += 1;
            }
        };
        NumericStepper.prototype.subValue = function (e) {
            if (this.value > this._minValue) {
                this.value -= 1;
            }
        };
        NumericStepper.prototype.setMaxValue = function (e) {
            if (this._maxValue)
                this.value = this._maxValue;
        };
        Object.defineProperty(NumericStepper.prototype, "value", {
            get: function () {
                return this._value;
            },
            set: function (val) {
                if (this._value != val) {
                    this._value = val;
                    this.txt.text = val + "";
                    this.dispatch(-1040 /* VALUE_CHANGE */);
                }
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(NumericStepper.prototype, "minValue", {
            get: function () {
                return this._minValue;
            },
            /*设置最小值*/
            set: function (value) {
                if (value)
                    this._minValue = value;
                else
                    jy.ThrowError("最小值需大于0");
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(NumericStepper.prototype, "maxValue", {
            get: function () {
                return this._maxValue;
            },
            /*设置最大值*/
            set: function (value) {
                if (value)
                    this._maxValue = value;
                else
                    jy.ThrowError("最大值需大于0");
            },
            enumerable: true,
            configurable: true
        });
        return NumericStepper;
    }(jy.Component));
    jy.NumericStepper = NumericStepper;
    __reflect(NumericStepper.prototype, "jy.NumericStepper");
    var NumericStepperCreator = (function (_super) {
        __extends(NumericStepperCreator, _super);
        function NumericStepperCreator() {
            return _super.call(this) || this;
        }
        NumericStepperCreator.prototype.parseSelfData = function (data) {
            this.uiData = data;
            var txtCreator = new jy.TextFieldCreator();
            this.txtCreator = txtCreator;
            var data0 = data[0], data1 = data[1];
            txtCreator.setBaseData(data0[1]);
            txtCreator.parseSelfData(data0[2]);
            var scale9Creator = new jy.ScaleBitmapCreator();
            this.scale9Creator = scale9Creator;
            var _suiData = this._suiData;
            var sourceComponentData = _suiData.sourceComponentData;
            scale9Creator.bindSuiData(_suiData);
            scale9Creator.parseSelfData(sourceComponentData[5][1][data1[2]]);
            scale9Creator.setBaseData(data1[1]);
            var btnCreator = [];
            this.btnCreator = btnCreator;
            var sourceComponentData31 = sourceComponentData[3][1];
            for (var i = 2; i < data.length; i++) {
                var dat = data[i];
                if (dat) {
                    var bc = new jy.ButtonCreator();
                    bc.bindSuiData(_suiData);
                    bc.parseSelfData(sourceComponentData31[dat[2]]);
                    bc.setBaseData(dat[1]);
                    btnCreator.push(bc);
                }
            }
            this._createT = this.createNumericStepper;
            this.suiManager = jy.singleton(jy.SuiResManager);
        };
        NumericStepperCreator.prototype.createNumericStepper = function () {
            var numstep = new NumericStepper();
            numstep.txt = this.txtCreator.get();
            numstep.txtbg = this.scale9Creator.get();
            var btnCreator = this.btnCreator;
            var len = btnCreator.length;
            if (len >= 3) {
                //4个按钮
                numstep.minBtn = btnCreator[0].get();
                numstep.subBtn = btnCreator[1].get();
                numstep.addBtn = btnCreator[2].get();
                numstep.maxBtn = btnCreator[3].get();
            }
            else {
                //2个按钮
                numstep.subBtn = btnCreator[0].get();
                numstep.addBtn = btnCreator[1].get();
            }
            numstep.bindChildren();
            return numstep;
        };
        return NumericStepperCreator;
    }(jy.BaseCreator));
    jy.NumericStepperCreator = NumericStepperCreator;
    __reflect(NumericStepperCreator.prototype, "jy.NumericStepperCreator");
})(jy || (jy = {}));
//# sourceMappingURL=NumericStepperCreator.js.map