var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var jy;
(function (jy) {
    /**
     * 格位基本类
     * @author 3tion
     */
    var Slot = (function (_super) {
        __extends(Slot, _super);
        function Slot() {
            var _this = _super.call(this) || this;
            _this._count = 1;
            _this._countShow = 1 /* Show */;
            _this.icon = new jy.Image();
            return _this;
        }
        Object.defineProperty(Slot.prototype, "data", {
            get: function () {
                return this._data;
            },
            set: function (value) {
                this.$setData(value);
            },
            enumerable: true,
            configurable: true
        });
        /**
         * 设置数据，只允许子类调用
         * @protected
         */
        Slot.prototype.$setData = function (value) {
            this._data = value;
        };
        Object.defineProperty(Slot.prototype, "rect", {
            get: function () {
                return this._rect;
            },
            set: function (rect) {
                if (rect) {
                    this._rect = rect;
                    var icon = this.icon;
                    icon.x = rect.x;
                    icon.y = rect.y;
                    icon.width = rect.width;
                    icon.height = rect.height;
                }
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(Slot.prototype, "countTxt", {
            get: function () {
                return this._countTxt;
            },
            set: function (txt) {
                var old = this._countTxt;
                if (old != txt) {
                    jy.removeDisplay(old);
                    this._countTxt = txt;
                    this.refreshCount();
                    this.invalidateDisplay();
                }
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(Slot.prototype, "iconSource", {
            set: function (uri) {
                if (this._uri != uri) {
                    this._uri = uri;
                    this.icon.source = uri;
                }
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(Slot.prototype, "count", {
            set: function (value) {
                if (this._count != value) {
                    this._count = value;
                    this.refreshCount();
                }
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(Slot.prototype, "countShow", {
            get: function () {
                return this._countShow;
            },
            /**
             * 数量显示状态<br/>
             * 0 不显示数值<br/>
             * 1 默认显示大于1的数量<br/>
             * 2 大于1的数量，显示数值，超过一万的，会以xxx万显示 默认为2<br/>
             */
            set: function (value) {
                if (this._countShow != value) {
                    this._countShow = value;
                    this.refreshCount();
                }
            },
            enumerable: true,
            configurable: true
        });
        Slot.prototype.refreshCount = function () {
            if (this.stage && this._countTxt) {
                this._countTxt.text = this.getCount();
            }
        };
        Slot.prototype.getCount = function () {
            var str = "";
            var count = this._count;
            switch (this.countShow) {
                case 1 /* Show */:
                    if (count > 1) {
                        str = count + "";
                    }
                    break;
                case 2 /* Custom */:
                    str = Slot.getCountString(count);
                    break;
                default:
                    break;
            }
            return str;
        };
        Slot.prototype.invalidateDisplay = function () {
            this._changed = true;
            if (this.stage) {
                jy.Global.callLater(this.refreshDisplay, 0, this);
            }
        };
        Slot.prototype.refreshDisplay = function () {
            if (!this._changed) {
                return false;
            }
            this._changed = false;
            if (this.bg) {
                this.addChild(this.bg);
            }
            this.addChild(this.icon);
            if (this._countTxt) {
                this.addChild(this._countTxt);
            }
            return true;
        };
        /**
         * 皮肤添加到舞台
         */
        Slot.prototype.awake = function () {
            this.refreshDisplay();
            this.refreshCount();
        };
        /**
         * 销毁
         * to be override
         */
        Slot.prototype.dispose = function () {
            this.icon.dispose();
            _super.prototype.dispose.call(this);
        };
        Object.defineProperty(Slot.prototype, "width", {
            get: function () {
                return this.suiRawRect.width;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(Slot.prototype, "height", {
            get: function () {
                return this.suiRawRect.height;
            },
            enumerable: true,
            configurable: true
        });
        /**
         *
         * 获取类型2的数量处理方法
         * @static
         */
        Slot.getCountString = function (count) { return count <= 1 ? "" : count < 10000 ? count + "" : jy.LangUtil.getMsg("$_wan", Math.floor(count / 10000)); };
        return Slot;
    }(jy.Component));
    jy.Slot = Slot;
    __reflect(Slot.prototype, "jy.Slot");
    /**
     * 格位创建器
     *
     * @export
     * @class SlotCreator
     * @extends {BaseCreator<Slot>}
     * @author pb
     */
    var SlotCreator = (function (_super) {
        __extends(SlotCreator, _super);
        function SlotCreator() {
            return _super.call(this) || this;
        }
        SlotCreator.prototype.parseSelfData = function (data) {
            var _this = this;
            var scaleData = data[0];
            var rect = scaleData ? new egret.Rectangle(scaleData[0], scaleData[1], scaleData[2], scaleData[3]) : undefined;
            this._createT = function () {
                var slot = new Slot();
                slot.rect = rect;
                var item = data[1];
                if (item) {
                    var dis = _this.createElement(item);
                    slot.countTxt = dis;
                }
                item = data[2];
                if (item) {
                    var dis = _this.createElement(item);
                    if (item.length > 1) {
                        slot.bg = dis;
                    }
                    else {
                        slot.bg = dis;
                    }
                }
                slot.invalidateDisplay();
                return slot;
            };
        };
        return SlotCreator;
    }(jy.BaseCreator));
    jy.SlotCreator = SlotCreator;
    __reflect(SlotCreator.prototype, "jy.SlotCreator");
})(jy || (jy = {}));
//# sourceMappingURL=SlotCreator.js.map