var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var jy;
(function (jy) {
    /**
     * 文本框创建器
     * @author
     *
     */
    var TextFieldCreator = (function (_super) {
        __extends(TextFieldCreator, _super);
        function TextFieldCreator() {
            return _super.call(this) || this;
        }
        TextFieldCreator.prototype.parseSelfData = function (data) {
            var _this = this;
            this._createT = function () {
                var tf = new egret.TextField();
                tf.rawTextData = data;
                _this.initTextData(tf, data);
                return tf;
            };
        };
        TextFieldCreator.prototype.initTextData = function (tf, data) {
            //静态文本框按动态文本框处理
            var textType = ["dynamic", "dynamic", "input"][+data[0]];
            var face = data[1] || TextFieldCreator.DefaultFonts;
            var align = ["left", "center", "right", "justify"][+data[2]];
            var color = jy.ColorUtil.getColorValue(data[3]);
            var size = data[4] || 12; //默认12px字
            var spacing = +data[5];
            var bold = !!data[6];
            var italic = !!data[7];
            var stroke = 0;
            var strokeColor = 0;
            var strokeDat = data[8];
            //            // blurX 作为描边宽度
            //            data[8] = [filter.color,filter.blurX];
            if (Array.isArray(strokeDat)) {
                strokeColor = strokeDat[0];
                if (typeof strokeColor == "string") {
                    strokeColor = jy.ColorUtil.getColorValue(strokeColor);
                }
                stroke = strokeDat[1];
            }
            tf.type = textType;
            tf.fontFamily = face;
            tf.textAlign = align;
            tf.textColor = color;
            tf.size = size;
            tf.lineSpacing = spacing;
            tf.bold = bold;
            tf.italic = italic;
            tf.stroke = stroke;
            tf.strokeColor = strokeColor;
        };
        TextFieldCreator.DefaultFonts = "";
        return TextFieldCreator;
    }(jy.BaseCreator));
    jy.TextFieldCreator = TextFieldCreator;
    __reflect(TextFieldCreator.prototype, "jy.TextFieldCreator");
})(jy || (jy = {}));
//# sourceMappingURL=TextFieldCreator.js.map