var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var jy;
(function (jy) {
    var ScrollBar = (function (_super) {
        __extends(ScrollBar, _super);
        function ScrollBar() {
            var _this = _super.call(this) || this;
            _this._scrollType = 0 /* Vertical */;
            _this._supportSize = 15;
            _this.initBaseContainer();
            return _this;
        }
        ScrollBar.prototype.initBaseContainer = function () {
            var bar = new egret.Sprite();
            var bg = new egret.Sprite();
            this.addChild(bg);
            this.addChild(bar);
            bg.visible = false;
            this.bar = bar;
            this.bg = bg;
        };
        Object.defineProperty(ScrollBar.prototype, "scrollType", {
            /**滚动条方式 0：垂直，1：水平 defalut:0*/
            get: function () {
                return this._scrollType;
            },
            /**滚动条方式 0：垂直，1：水平 defalut:0*/
            set: function (value) {
                this._scrollType = value;
                this.checkBarSize();
                this.checkBgSize();
                this.$setSupportSize(this._supportSize);
            },
            enumerable: true,
            configurable: true
        });
        /**
         * 设置滚动条的底与默认尺寸
         *
         * @value 背景底
         * @bgSize 尺寸
         */
        ScrollBar.prototype.setBg = function (value, bgSize) {
            this._bgBmp = value;
            value.y = 0;
            if (bgSize > 0) {
                this._bgSize = bgSize;
            }
            else {
                this.checkBgSize();
            }
            this.bg.addChild(value);
            this.$setSupportSize(this._supportSize);
        };
        /**
         * 设置滑块按钮的样式
         *
         * @value 滑块按钮
         * @barSize 滑块的尺寸大小
         */
        ScrollBar.prototype.setBar = function (value, barSize) {
            this._barBmp = value;
            value.y = 0;
            if (barSize > 0) {
                this._barSize = barSize;
            }
            else {
                this.checkBarSize();
            }
            this.bar.addChild(value);
            this.$setSupportSize(this._supportSize);
        };
        Object.defineProperty(ScrollBar.prototype, "bgSize", {
            get: function () {
                return this._bgSize;
            },
            /**
             * 滚动条背景尺寸
             */
            set: function (value) {
                if (this._bgSize != value) {
                    this.$setBgSize(value);
                }
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(ScrollBar.prototype, "barSize", {
            get: function () {
                return this._barSize;
            },
            /**
             * 滑块的尺寸
             */
            set: function (value) {
                if (this._barSize != value) {
                    this.$setBarSize(value);
                }
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(ScrollBar.prototype, "supportSize", {
            get: function () {
                return this._supportSize;
            },
            /**当垂直滚动时，此值为滑块的宽度，当水平滚动时，此值为滑块的高度 */
            set: function (value) {
                if (this._supportSize != value) {
                    this.$setSupportSize(value);
                }
            },
            enumerable: true,
            configurable: true
        });
        ScrollBar.prototype.$setSupportSize = function (_supportSize) {
            this._supportSize = _supportSize;
            var _a = this, _bgBmp = _a._bgBmp, _barBmp = _a._barBmp;
            if (this._scrollType == 0 /* Vertical */) {
                if (_bgBmp)
                    _bgBmp.width = _supportSize;
                if (_barBmp)
                    _barBmp.width = _supportSize;
            }
            else {
                if (_bgBmp)
                    _bgBmp.height = _supportSize;
                if (_barBmp)
                    _barBmp.height = _supportSize;
            }
        };
        ScrollBar.prototype.$setBarSize = function (_barSize) {
            this._barSize = _barSize;
            var _barBmp = this._barBmp;
            if (_barBmp) {
                if (this._scrollType == 0 /* Vertical */) {
                    _barBmp.height = _barSize;
                }
                else {
                    _barBmp.width = _barSize;
                }
            }
        };
        ScrollBar.prototype.$setBgSize = function (_bgSize) {
            this._bgSize = _bgSize;
            var _bgBmp = this._bgBmp;
            if (_bgBmp) {
                if (this._scrollType == 0 /* Vertical */) {
                    _bgBmp.height = _bgSize;
                }
                else {
                    _bgBmp.width = _bgSize;
                }
            }
        };
        ScrollBar.prototype.checkBgSize = function () {
            var _bgBmp = this._bgBmp;
            if (_bgBmp) {
                if (this._scrollType == 0 /* Vertical */) {
                    this._bgSize = _bgBmp.height;
                }
                else {
                    this._bgSize = _bgBmp.width;
                }
            }
        };
        ScrollBar.prototype.checkBarSize = function () {
            var _barBmp = this._bgBmp;
            if (_barBmp) {
                if (this._scrollType == 0 /* Vertical */) {
                    this._barSize = _barBmp.height;
                }
                else {
                    this._barSize = _barBmp.width;
                }
            }
        };
        return ScrollBar;
    }(jy.Component));
    jy.ScrollBar = ScrollBar;
    __reflect(ScrollBar.prototype, "jy.ScrollBar");
    var ScrollBarCreator = (function (_super) {
        __extends(ScrollBarCreator, _super);
        function ScrollBarCreator() {
            return _super.call(this) || this;
        }
        ScrollBarCreator.prototype.parseSelfData = function (data) {
            this.uiData = data;
            this.suiManager = jy.singleton(jy.SuiResManager);
            this._createT = this.createScrollBar;
        };
        ScrollBarCreator.prototype.createScrollBar = function () {
            var scrollBar = new ScrollBar();
            var comData = this.uiData;
            // let len = comData.length;
            var tmpData;
            var sourceData = this._suiData.sourceComponentData;
            var index;
            var sourceArr;
            var name;
            tmpData = comData[0];
            index = tmpData[2];
            sourceArr = sourceData[5];
            name = sourceArr[0][index];
            var sc = this.suiManager.createDisplayObject(this._suiData.key, name, tmpData[1]);
            scrollBar.setBar(sc);
            tmpData = comData[1];
            index = tmpData[2];
            sourceArr = sourceData[5];
            name = sourceArr[0][index];
            sc = this.suiManager.createDisplayObject(this._suiData.key, name, tmpData[1]);
            scrollBar.setBg(sc);
            return scrollBar;
        };
        return ScrollBarCreator;
    }(jy.BaseCreator));
    jy.ScrollBarCreator = ScrollBarCreator;
    __reflect(ScrollBarCreator.prototype, "jy.ScrollBarCreator");
})(jy || (jy = {}));
//# sourceMappingURL=ScrollBarCreator.js.map