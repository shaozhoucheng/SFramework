var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var jy;
(function (jy) {
    /**
     *
     * 新版使用MC的按钮，减少制作按钮的难度
     *
     *
     * @export
     * @class MCButton
     * @extends {Button}
     */
    var MCButton = (function (_super) {
        __extends(MCButton, _super);
        function MCButton(mc) {
            var _this = _super.call(this) || this;
            if (mc) {
                _this.setSkin(mc);
            }
            return _this;
        }
        MCButton.prototype.setSkin = function (mc) {
            //检查是否有文本框
            this.txtLabel = mc.tf;
            this.mc = mc;
            this.addChild(mc);
            this.refresh();
        };
        MCButton.prototype.refresh = function () {
            //停在指定帧
            var mc = this.mc;
            if (mc) {
                mc.stop(this.$getBtnFrame());
            }
        };
        MCButton.prototype.dispose = function () {
            _super.prototype.dispose.call(this);
            var mc = this.mc;
            if (mc) {
                mc.dispose();
            }
        };
        return MCButton;
    }(jy.Button));
    jy.MCButton = MCButton;
    __reflect(MCButton.prototype, "jy.MCButton");
    MCButton.prototype.addChild = jy.Component.prototype.addChild;
    /**
     * MC按钮创建器
     *
     * @export
     * @class MCButtonCreator
     * @extends {BaseCreator<MCButton>}
     */
    var MCButtonCreator = (function (_super) {
        __extends(MCButtonCreator, _super);
        function MCButtonCreator() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        MCButtonCreator.prototype.parseSelfData = function (data) {
            var suiData = this._suiData;
            var framesData = jy.MovieClipCreator.prototype.$getFramesData(data);
            this._createT = function () { return new MCButton(new jy.MovieClip(data, framesData, suiData)); };
        };
        return MCButtonCreator;
    }(jy.BaseCreator));
    jy.MCButtonCreator = MCButtonCreator;
    __reflect(MCButtonCreator.prototype, "jy.MCButtonCreator");
})(jy || (jy = {}));
//# sourceMappingURL=MCButtonCreator.js.map