var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var jy;
(function (jy) {
    /**
     * 图片
     * 外部加载
     * @pb
     *
     */
    var Image = (function (_super) {
        __extends(Image, _super);
        function Image() {
            var _this = _super.call(this) || this;
            _this.on("addedToStage" /* ADDED_TO_STAGE */, _this.addedToStage, _this);
            _this.on("removedFromStage" /* REMOVED_FROM_STAGE */, _this.removedFromStage, _this);
            return _this;
        }
        Image.prototype.addedToStage = function () {
            if (this.uri) {
                var res = jy.ResManager.getTextureRes(this.uri, this.noWebp);
                if (res) {
                    res.qid = this.qid;
                    //先设置为占位用，避免有些玩家加载慢，无法看到图
                    this.texture = this.placehoder;
                    res.bind(this);
                    res.load();
                }
            }
        };
        Image.prototype.removedFromStage = function () {
            if (this.uri) {
                var res = jy.ResManager.getResource(this.uri);
                if (res) {
                    res.loose(this);
                }
            }
        };
        Object.defineProperty(Image.prototype, "source", {
            /**
             * 设置资源标识
             */
            set: function (value) {
                if (this.uri == value)
                    return;
                if (this.uri) {
                    this.removedFromStage();
                }
                this.uri = value;
                if (value) {
                    if (this.stage) {
                        this.addedToStage();
                    }
                }
                else {
                    this.texture = undefined;
                }
            },
            enumerable: true,
            configurable: true
        });
        /**
         * 销毁图片
         */
        Image.prototype.dispose = function () {
            this.removedFromStage();
            this.off("addedToStage" /* ADDED_TO_STAGE */, this.addedToStage, this);
            this.off("removedFromStage" /* REMOVED_FROM_STAGE */, this.removedFromStage, this);
        };
        return Image;
    }(egret.Bitmap));
    jy.Image = Image;
    __reflect(Image.prototype, "jy.Image");
    ;
    jy.addEnable(Image);
})(jy || (jy = {}));
//# sourceMappingURL=Image.js.map