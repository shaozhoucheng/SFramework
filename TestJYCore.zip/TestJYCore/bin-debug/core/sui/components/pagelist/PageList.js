var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var jy;
(function (jy) {
    var PageList = (function (_super) {
        __extends(PageList, _super);
        /**
         * Creates an instance of PageList.
         * @param {ClassFactory<R> | Creator<R>} renderfactory
         * @param {PageListOption} [option]
         */
        function PageList(renderfactory, option) {
            var _this = _super.call(this) || this;
            _this._sizeChanged = false;
            _this.scroller = null; //站位用，便于对Scroller的绑定
            _this._waitForSetIndex = false;
            _this.renderChange = false;
            if (!(renderfactory instanceof jy.ClassFactory)) {
                renderfactory = new jy.ClassFactory(renderfactory);
            }
            _this._factory = renderfactory;
            _this.init(option);
            return _this;
        }
        Object.defineProperty(PageList.prototype, "container", {
            /**
             * 容器
             *
             * @readonly
             */
            get: function () {
                return this._con;
            },
            set: function (con) {
                if (!con) {
                    true && jy.ThrowError("\u5BB9\u5668\u4E0D\u5141\u8BB8\u8BBE\u7F6E\u7A7A\u503C");
                    return;
                }
                var old = this._con;
                if (old != con) {
                    if (old) {
                        delete old.$_page;
                        delete old.scrollRect;
                    }
                    this._con = con;
                    con.$_page = this;
                    Object.defineProperty(con, "scrollRect", define);
                }
            },
            enumerable: true,
            configurable: true
        });
        PageList.prototype.init = function (option) {
            option = option || jy.Temp.EmptyObject;
            var hgap = option.hgap, vgap = option.vgap, type = option.type, itemWidth = option.itemWidth, itemHeight = option.itemHeight, columnCount = option.columnCount, staticSize = option.staticSize, noScroller = option.noScroller, con = option.con;
            this.staticSize = staticSize;
            type = ~~type;
            columnCount = ~~columnCount;
            if (columnCount < 1) {
                if (type == 1 /* Horizon */) {
                    columnCount = Infinity;
                }
                else {
                    columnCount = 1;
                }
            }
            this._columncount = columnCount;
            this._hgap = ~~hgap;
            this._vgap = ~~vgap;
            this.itemWidth = itemWidth;
            this.itemHeight = itemHeight;
            //@ts-ignore
            this.scrollType = type;
            this.container = con || new egret.Sprite();
            if (!noScroller) {
                var scroller = this.scroller = new jy.Scroller();
                scroller.scrollType = this.scrollType;
                scroller.bindObj2(con, con.suiRawRect);
            }
        };
        PageList.prototype.displayList = function (data) {
            this._selectedIndex = -1;
            if (this._data != data) {
                this.rawDataChanged = true;
            }
            var nlen = data ? data.length : 0;
            if (this._data) {
                //如果新赋值的数据长度比以前的短，就自动清理掉多出来的item
                var list = this._list;
                var llen = list.length;
                if (nlen < llen) {
                    for (var i = nlen; i < list.length; i++) {
                        var render = list[i];
                        this._removeRender(render);
                    }
                    list.length = nlen;
                }
            }
            this._data = data;
            this._lastRect = undefined;
            if (!nlen) {
                this.dispose();
                this._dataLen = 0;
                this.rawDataChanged = false;
                return;
            }
            this._dataLen = nlen;
            this.initItems();
            if (this.scroller) {
                this.scroller.scrollToHead();
            }
            this.rawDataChanged = false;
        };
        /**
         * 初始化render占据array，不做任何初始化容器操作
         *
         * @private
         */
        PageList.prototype.initItems = function () {
            var len = this._data.length;
            this.doRender(0, len - 1);
            this._sizeChanged = true;
            this.reCalc();
            this.checkViewRect();
        };
        PageList.prototype.onChange = function () {
            if (!this.itemWidth || !this.itemHeight) {
                this._sizeChanged = true;
                this.reCalc();
            }
        };
        PageList.prototype._get = function (index) {
            var list = this._list;
            var render = list[index];
            if (!render) {
                render = this._factory.get();
                list[index] = render;
                render.on(-1999 /* Resize */, this.onSizeChange, this);
                render.on(-1001 /* ITEM_TOUCH_TAP */, this.onTouchItem, this);
            }
            render.index = index;
            return render;
        };
        PageList.prototype.onSizeChange = function () {
            if (!this._sizeChanged) {
                this._sizeChanged = true;
                this.once("enterFrame" /* ENTER_FRAME */, this.reCalc, this);
            }
        };
        PageList.prototype.getSize = function (v) {
            var size = v;
            if (this.staticSize) {
                var rect = v.suiRawRect;
                if (rect) {
                    size = rect;
                }
            }
            return size;
        };
        /**
         * 重新计算Render的坐标
         *
         * @private
         * @param {number} [start]
         * @param {number} [end]
         * @returns
         */
        PageList.prototype.reCalc = function () {
            if (!this._sizeChanged) {
                return;
            }
            this._sizeChanged = false;
            var renderList = this._list;
            var len = renderList.length;
            var end = len - 1;
            // let lastrender: R;
            //得到单行/单列最大索引数
            var _a = this, itemWidth = _a.itemWidth, itemHeight = _a.itemHeight, _columncount = _a._columncount, _hgap = _a._hgap, _vgap = _a._vgap, staticSize = _a.staticSize;
            var rowCount = len / _columncount;
            var oy = 0, ox = 0;
            var maxWidth = 0, maxHeight = 0;
            var i = 0;
            for (var r = 0; r <= rowCount; r++) {
                //单行的最大高度
                var lineMaxHeight = 0;
                for (var c = 0; c < _columncount; c++) {
                    if (i > end) {
                        break;
                    }
                    var render = renderList[i++];
                    var v = render.view;
                    var w = 0;
                    if (v) {
                        var size = void 0;
                        if (itemWidth) {
                            w = itemWidth;
                        }
                        else {
                            size = this.getSize(v);
                            w = size.width;
                        }
                        var vh = void 0;
                        if (itemHeight) {
                            vh = itemHeight;
                        }
                        else {
                            if (!size) {
                                size = this.getSize(v);
                            }
                            vh = size.height;
                        }
                        v.x = ox;
                        v.y = oy;
                        var rright = v.x + w;
                        if (maxWidth < rright) {
                            maxWidth = rright;
                        }
                        if (lineMaxHeight < vh) {
                            lineMaxHeight = vh;
                        }
                    }
                    ox += _hgap + w;
                }
                var mh = oy + lineMaxHeight;
                if (maxHeight < mh) {
                    maxHeight = mh;
                }
                if (i > end) {
                    break;
                }
                ox = 0;
                //偏移量，优先使用itemHeight
                oy += _vgap + (itemHeight || lineMaxHeight);
            }
            if (maxWidth != this._w || maxHeight != this._h) {
                this._w = maxWidth;
                this._h = maxHeight;
                var g = this._con.graphics;
                g.clear();
                g.beginFill(0, 0);
                g.drawRect(0, 0, maxWidth, maxHeight);
                g.endFill();
                this.dispatch(-1999 /* Resize */);
            }
        };
        PageList.prototype.$setSelectedIndex = function (value) {
            this._waitIndex = value;
            if (!this._data) {
                this._waitForSetIndex = true;
                return;
            }
            var render;
            var renderList = this._list;
            var len_1 = renderList.length - 1;
            if (value > len_1) {
                value = len_1;
            }
            render = this._list[value];
            this.changeRender(render, value);
            var view = render.view;
            if (view && view.stage) {
                this._waitForSetIndex = false;
                this.moveScroll(render);
            }
            else {
                this._waitForSetIndex = true;
            }
            if (this._waitForSetIndex) {
                this.moveScroll(render);
                //假如列表里有30个项，选中第20个，所以前20个都没有渲染，这边自己设置的rect，并不能引发scroller抛CHANGE事件
                //所以自己抛一下
                //如果已经渲染过，可不用抛
                // this.dispatchEventWith(EventConst.SCROLL_POSITION_CHANGE);
            }
        };
        PageList.prototype.moveScroll = function (render) {
            var con = this._con;
            var rect = con.scrollRect;
            if (!rect)
                return;
            var v = render.view;
            if (!v) {
                if (true) {
                    jy.ThrowError("render[" + egret.getQualifiedClassName(render) + "]\u6CA1\u6709renderView");
                }
                return;
            }
            var oldPos, endPos, max;
            if (this.scrollType == 0 /* Vertical */) {
                oldPos = rect.y;
                var d = this.itemHeight;
                if (!d) {
                    d = this.getSize(v).height;
                }
                endPos = v.y + d;
                max = this._h;
            }
            else {
                oldPos = rect.x;
                var d = this.itemWidth;
                if (!d) {
                    d = this.getSize(v).width;
                }
                endPos = v.x + d;
                max = this._w;
            }
            if (endPos > max) {
                endPos = max;
            }
            if (rect) {
                if (this.scrollType == 0 /* Vertical */) {
                    endPos = endPos - rect.height;
                }
                else {
                    endPos = endPos - rect.width;
                }
                if (endPos < 0) {
                    endPos = 0;
                }
            }
            var scroller = this.scroller;
            if (scroller) {
                scroller.stopTouchTween();
            }
            jy.Global.removeTweens(this);
            if (this.useTweenIndex) {
                this.useTweenIndex = false;
                var result = this.scrollType == 1 /* Horizon */ ? { tweenX: endPos } : { tweenY: endPos };
                var tween = jy.Global.getTween(this).to(result, 500, jy.Ease.quadOut);
                if (scroller) {
                    scroller.showBar();
                    tween.call(scroller.hideBar, scroller);
                }
            }
            else {
                if (scroller) {
                    scroller.doMoveScrollBar(oldPos - endPos);
                }
                if (this.scrollType == 0 /* Vertical */) {
                    rect.y = endPos;
                }
                else {
                    rect.x = endPos;
                }
                con.scrollRect = rect;
            }
        };
        Object.defineProperty(PageList.prototype, "tweenX", {
            get: function () {
                var rect = this._con.scrollRect;
                return rect ? rect.x : 0;
            },
            set: function (value) {
                var con = this._con;
                var rect = con.scrollRect || new egret.Rectangle(NaN);
                if (value != rect.x) {
                    var delta = value - rect.x;
                    rect.x = value;
                    var scroller = this.scroller;
                    if (scroller) {
                        scroller.doMoveScrollBar(delta);
                    }
                    con.scrollRect = rect;
                }
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(PageList.prototype, "tweenY", {
            get: function () {
                var rect = this._con.scrollRect;
                return rect ? rect.y : 0;
            },
            set: function (value) {
                var con = this._con;
                var rect = con.scrollRect || new egret.Rectangle(0, NaN);
                if (value != rect.y) {
                    var delta = value - rect.y;
                    rect.y = value;
                    var scroller = this.scroller;
                    if (scroller) {
                        scroller.doMoveScrollBar(delta);
                    }
                    con.scrollRect = rect;
                }
            },
            enumerable: true,
            configurable: true
        });
        /**
         * 滚动到指定index
         */
        PageList.prototype.tweenToIndex = function (index) {
            this.useTweenIndex = true;
            this.selectedIndex = index;
        };
        PageList.prototype.selectItemByData = function (key, value, useTween) {
            if (useTween === void 0) { useTween = false; }
            var data = this._data;
            var len = data && data.length || 0;
            for (var i = 0; i < len; i++) {
                if (key in data[i]) {
                    if (data[i][key] == value) {
                        if (useTween) {
                            this.tweenToIndex(i);
                        }
                        else {
                            this.selectedIndex = i;
                        }
                        break;
                    }
                }
            }
        };
        /**
         * 更新item数据
         *
         * @param {number} index (description)
         * @param {*} data (description)
         */
        PageList.prototype.updateByIdx = function (index, data) {
            var item = this.getItemAt(index);
            if (item) {
                this._data[index] = data;
                this.doRender(index);
            }
        };
        PageList.prototype.removeAt = function (idx) {
            idx = idx >>> 0;
            var list = this._list;
            if (idx < list.length) {
                var item = list[idx];
                list.splice(idx, 1);
                this._data.splice(idx, 1);
                this._removeRender(item);
            }
        };
        PageList.prototype.removeItem = function (item) {
            var index = this._list.indexOf(item);
            if (index != -1) {
                this.removeAt(index);
            }
        };
        PageList.prototype._removeRender = function (item) {
            item.data = undefined;
            jy.removeDisplay(item.view);
            item.off(-1999 /* Resize */, this.onSizeChange, this);
            item.off(-1001 /* ITEM_TOUCH_TAP */, this.onTouchItem, this);
            item.dispose();
            if (!this.renderChange) {
                this.renderChange = true;
                this.once("enterFrame" /* ENTER_FRAME */, this.refreshByRemoveItem, this);
            }
        };
        PageList.prototype.refreshByRemoveItem = function () {
            if (!this.renderChange) {
                return;
            }
            this.renderChange = false;
            this._sizeChanged = true;
            this.reCalc();
            this.checkViewRect();
        };
        /**
         * 销毁
         *
         */
        PageList.prototype.dispose = function () {
            this.clear();
        };
        /**
         * 清理
         *
         */
        PageList.prototype.clear = function () {
            this._con.graphics.clear();
            this._selectedIndex = -1;
            this._data = undefined;
            var list = this._list;
            for (var i = 0; i < list.length; i++) {
                this._removeRender(list[i]);
            }
            list.length = 0;
            this._selectedItem = undefined;
            this._waitForSetIndex = false;
            this._waitIndex = -1;
            this._w = 0;
            this._h = 0;
        };
        Object.defineProperty(PageList.prototype, "showStart", {
            /**
             * 在舞台之上的起始索引
             *
             * @readonly
             */
            get: function () {
                return this._showStart;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(PageList.prototype, "showEnd", {
            /**
             * 在舞台之上的结束索引
             *
             * @readonly
             */
            get: function () {
                return this._showEnd;
            },
            enumerable: true,
            configurable: true
        });
        PageList.prototype.checkViewRect = function () {
            var _con = this._con;
            var rect = _con.scrollRect;
            var list = this._list;
            var len = list.length;
            var len_1 = len - 1;
            if (!rect) {
                // 应该为全部添加到舞台
                for (var i = 0; i < len; i++) {
                    var render = list[i];
                    var v = render.view;
                    if (v) {
                        _con.addChild(v);
                    }
                }
                this._showStart = 0;
                this._showEnd = len - 1;
                return;
            }
            //设置rect时，检查哪些Render应该在舞台上
            var lastRect = this._lastRect;
            var checkStart, inc;
            if (lastRect) {
                //检查滚动方向
                var key1 = "x" /* X */, key2 = "width" /* Width */;
                if (this.scrollType == 0 /* Vertical */) {
                    key1 = "y" /* Y */;
                    key2 = "height" /* Height */;
                }
                var delta = rect[key1] - lastRect[key1];
                if (delta == 0 && rect[key2] == lastRect[key2]) {
                    if (!this.rawDataChanged) {
                        return;
                    }
                }
                var showStart = this._showStart;
                var showEnd = this._showEnd;
                //先全部从舞台移除
                for (var i = showStart; i <= showEnd; i++) {
                    var render = list[i];
                    if (render) {
                        jy.removeDisplay(render.view);
                    }
                }
                if (delta > 0) {
                    checkStart = showStart;
                    inc = true;
                }
                else {
                    checkStart = showEnd;
                    inc = false;
                }
                lastRect[key1] = rect[key1];
                lastRect[key2] = rect[key2];
            }
            else {
                if (!len) {
                    return;
                }
                lastRect = rect.clone();
                this._lastRect = lastRect;
                checkStart = 0;
                inc = true;
            }
            var first, last, fIdx, lIdx;
            var tmp = jy.Temp.SharedArray3;
            var tmpRect = jy.Temp.SharedRect1;
            var staticSize = this.staticSize;
            tmp.length = 0;
            if (inc) {
                fIdx = 0;
                lIdx = len_1;
                /**
                 *
                 *
                 *   ├────────┤
                 *   │render0 │                         以前和scrollRect相交的render0，现在不再相交，从舞台移除
                 *  ┌├────────┤┐───
                 *  ││render1 ││ ↑ scrollRect           以前和scrollRect相交的render1，现在还相交
                 *  │├────────┤│ ↓
                 *  └│render2 │┘───                     以前不和scrollRect相交的render2，现在相交
                 *   ├────────┤
                 *
                 *  需要从起始点开始找，找到第一个和当前rect相交的render
                 *  直到找到最后一个和rect相交的render，再往后则无需检测
                 */
                for (var i = checkStart; i < len; i++) {
                    if (check(i, this)) {
                        break;
                    }
                }
                for (var i = 0, tlen = tmp.length; i < tlen; i++) {
                    var v = tmp[i];
                    _con.addChild(v);
                }
                this._showStart = fIdx;
                this._showEnd = lIdx;
            }
            else {
                fIdx = len_1;
                lIdx = 0;
                for (var i = checkStart; i >= 0; i--) {
                    if (check(i, this)) {
                        break;
                    }
                }
                for (var i = tmp.length - 1; i >= 0; i--) {
                    var v = tmp[i];
                    _con.addChild(v);
                }
                this._showStart = lIdx;
                this._showEnd = fIdx;
            }
            tmp.length = 0;
            return;
            function check(i, d) {
                var render = list[i];
                var v = render.view;
                if (v) {
                    var rec = void 0;
                    if (staticSize) {
                        rec = tmpRect;
                        rec.x = v.x;
                        rec.y = v.y;
                        var suiRect = v.suiRawRect;
                        rec.width = d.itemWidth || suiRect.width;
                        rec.height = d.itemHeight || suiRect.height;
                    }
                    else {
                        rec = v;
                    }
                    if (jy.intersects(rec, rect)) {
                        if (!first) {
                            first = render;
                            fIdx = i;
                        }
                        tmp.push(v);
                    }
                    else {
                        if (first) {
                            last = render;
                            lIdx = i;
                            if (staticSize) {
                                return true;
                            }
                        }
                    }
                }
            }
        };
        return PageList;
    }(jy.AbsPageList));
    jy.PageList = PageList;
    __reflect(PageList.prototype, "jy.PageList");
    var define = {
        set: function (rect) {
            egret.DisplayObject.prototype.$setScrollRect.call(this, rect);
            this.$_page.checkViewRect();
        },
        get: function () {
            return this.$scrollRect;
        },
        configurable: true
    };
})(jy || (jy = {}));
//# sourceMappingURL=PageList.js.map