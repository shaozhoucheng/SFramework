var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var jy;
(function (jy) {
    var AbsPageList = (function (_super) {
        __extends(AbsPageList, _super);
        function AbsPageList() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this._list = [];
            _this._selectedIndex = -1;
            _this._dataLen = 0;
            return _this;
        }
        Object.defineProperty(AbsPageList.prototype, "dataLen", {
            /**
             * 获取数据长度
             *
             * @readonly
             */
            get: function () {
                return this._dataLen;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(AbsPageList.prototype, "data", {
            /**
             * 获取数据集
             *
             * @readonly
             */
            get: function () {
                return this._data;
            },
            enumerable: true,
            configurable: true
        });
        /**
         * 渲染指定位置的render
         *
         * @ private
         * @ param {number} start (起始索引)
         * @ param {number} end (结束索引)
         */
        AbsPageList.prototype.doRender = function (start, end) {
            var render;
            var data = this._data;
            end == undefined && (end = start);
            for (var i = start; i <= end; i++) {
                render = this._get(i);
                if (!render) {
                    continue;
                }
                if (render.inited === false) {
                    if (render.bindComponent) {
                        render.bindComponent();
                    }
                    render.inited = true;
                }
                var tmp = render.data;
                if (!tmp || tmp != data[i] || render.dataChange) {
                    render.data = data[i];
                    if (render.handleView) {
                        render.handleView();
                    }
                    if (render.dataChange) {
                        render.dataChange = false;
                    }
                }
            }
        };
        Object.defineProperty(AbsPageList.prototype, "selectedIndex", {
            get: function () {
                return this._selectedIndex;
            },
            set: function (value) {
                if (this._selectedIndex == value && value >= 0)
                    return;
                if (value < 0) {
                    var selectedItem = this._selectedItem;
                    if (selectedItem) {
                        selectedItem.selected = false;
                        this._selectedItem = undefined;
                    }
                    this._selectedIndex = value;
                    return;
                }
                this.$setSelectedIndex(value);
            },
            enumerable: true,
            configurable: true
        });
        AbsPageList.prototype.$setSelectedIndex = function (value) {
            var render;
            var renderList = this._list;
            var len_1 = renderList.length - 1;
            if (value > len_1) {
                value = len_1;
            }
            render = this._list[value];
            this.changeRender(render, value);
        };
        /**
         *
         * 根据索引获得视图
         * @param {number} idx
         * @returns
         */
        AbsPageList.prototype.getItemAt = function (idx) {
            idx = idx >>> 0;
            return this._list[idx];
        };
        AbsPageList.prototype.selectItemByData = function (key, value, useTween) {
            var _this = this;
            if (useTween === void 0) { useTween = false; }
            this.find(function (dat, render, idx) {
                if (dat && (key in dat) && dat[key] == value) {
                    _this.selectedIndex = idx;
                    return true;
                }
            });
        };
        /**
         * 遍历列表
         *
         * @param {{(data:T,render:R,idx:number,...args)}} handle
         * @param {any} otherParams
         */
        AbsPageList.prototype.forEach = function (handle) {
            var otherParams = [];
            for (var _i = 1; _i < arguments.length; _i++) {
                otherParams[_i - 1] = arguments[_i];
            }
            var datas = this._data;
            var renders = this._list;
            var len = this._dataLen;
            for (var i = 0; i < len; i++) {
                var data = datas[i];
                var render = renders[i];
                handle.apply(void 0, [data, render, i].concat(otherParams));
            }
        };
        /**
         * 找到第一个符合要求的render
         *
         * @param {{(data:T,render:R,idx:number,...args):boolean}} handle
         * @param {any} otherParams
         * @returns
         */
        AbsPageList.prototype.find = function (handle) {
            var otherParams = [];
            for (var _i = 1; _i < arguments.length; _i++) {
                otherParams[_i - 1] = arguments[_i];
            }
            var datas = this._data;
            var renders = this._list;
            var len = this._dataLen;
            for (var i = 0; i < len; i++) {
                var data = datas[i];
                var render = renders[i];
                if (handle.apply(void 0, [data, render, i].concat(otherParams))) {
                    return render;
                }
            }
        };
        Object.defineProperty(AbsPageList.prototype, "selectedItem", {
            get: function () {
                return this._selectedItem;
            },
            enumerable: true,
            configurable: true
        });
        /**
         * 根据key value获取item,将item的data重新赋值为data
         *
         * @param {string} key (description)
         * @param {*} value (description)
         * @param {T} data (description)
         */
        AbsPageList.prototype.updateByKey = function (key, value, data) {
            var _this = this;
            this.find(function (dat, render, idx) {
                if (dat && (key in dat) && dat[key] == value) {
                    _this.updateByIdx(idx, data === undefined ? dat : data);
                    return true;
                }
            });
        };
        AbsPageList.prototype.onTouchItem = function (e) {
            var render = e.target;
            this.changeRender(render);
        };
        AbsPageList.prototype.changeRender = function (render, index) {
            var old = this._selectedItem;
            if (old != render) {
                index == undefined && (index = this._list.indexOf(render));
                if (old) {
                    old.selected = false;
                }
                this._selectedItem = render;
                this._selectedIndex = index;
                render.selected = true;
                this.onChange();
                this.dispatch(-1052 /* ITEM_SELECTED */);
            }
        };
        AbsPageList.prototype.getAllItems = function () {
            return this._list;
        };
        Object.defineProperty(AbsPageList.prototype, "length", {
            get: function () {
                return this._list.length;
            },
            enumerable: true,
            configurable: true
        });
        /**
         * 让所有在舞台上的render重新刷新一次数据
         *
         *
         * @memberOf PageList
         */
        AbsPageList.prototype.refresh = function () {
            var data = this._data;
            if (data) {
                var len = data.length;
                for (var i = 0; i < len; i++) {
                    this.refreshAt(i);
                }
            }
        };
        /**
         * 根据index使某个在舞台上的render刷新
         *
         * @param {number}  idx
         * @param {boolean} [force]     是否强制执行setData和handleView
         * @memberOf PageList
         */
        AbsPageList.prototype.refreshAt = function (idx, force) {
            var renderer = this._get(idx);
            if (force || renderer.view.stage) {
                renderer.data = this._data[idx];
                if (typeof renderer.handleView === "function") {
                    renderer.handleView();
                }
                if (renderer.dataChange) {
                    renderer.dataChange = false;
                }
            }
        };
        /**
         * render进行切换
         *
         * @protected
         */
        AbsPageList.prototype.onChange = function () { };
        return AbsPageList;
    }(egret.EventDispatcher));
    jy.AbsPageList = AbsPageList;
    __reflect(AbsPageList.prototype, "jy.AbsPageList");
})(jy || (jy = {}));
//# sourceMappingURL=AbsPageList.js.map