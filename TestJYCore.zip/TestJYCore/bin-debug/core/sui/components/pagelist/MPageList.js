var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var jy;
(function (jy) {
    /**
     * 为已布局好的render提供List功能
     *
     * @export
     * @class MPageList
     * @extends {PageList}
     */
    var MPageList = (function (_super) {
        __extends(MPageList, _super);
        function MPageList() {
            var _this = _super.call(this, null) || this;
            _this._viewCount = 0;
            return _this;
        }
        MPageList.prototype.displayList = function (data) {
            this._selectedIndex = -1;
            var dataLen = data && data.length || 0;
            //如果新赋值的数据长度比以前的短，就自动清理掉多出来的item
            var olen = Math.max(this._dataLen, this._viewCount);
            while (olen > dataLen) {
                var render = this.getItemAt(olen - 1);
                if (render) {
                    render.data = undefined;
                    if (render.handleView) {
                        render.handleView();
                    }
                }
                olen--;
            }
            this._data = data;
            this._dataLen = dataLen;
            this.doRender(0, dataLen - 1);
        };
        /**
         * 更新item数据
         *
         * @param {number} index (description)
         * @param {*} data (description)
         */
        MPageList.prototype.updateByIdx = function (index, data) {
            var item = this.getItemAt(index);
            if (item) {
                this._data[index] = data;
                item.data = data;
                if (item.handleView) {
                    item.handleView();
                }
            }
        };
        MPageList.prototype.addItem = function (item, index) {
            var list = this._list;
            var idx = list.indexOf(item);
            if (idx == -1) {
                idx = list.length;
                list[idx] = item;
                item.on(-1001 /* ITEM_TOUCH_TAP */, this.onTouchItem, this);
            }
            item.index = index == undefined ? idx : index;
            this._viewCount = list.length;
        };
        MPageList.prototype._get = function (index) {
            var list = this._list;
            var render = list[index];
            if (render) {
                render.index = index;
                return render;
            }
        };
        MPageList.prototype.clear = function () {
            this._dataLen = 0;
            this._data = undefined;
            for (var _i = 0, _a = this._list; _i < _a.length; _i++) {
                var render = _a[_i];
                render.data = undefined;
            }
            this._selectedIndex = -1;
            this._selectedItem = undefined;
        };
        MPageList.prototype.dispose = function () {
            for (var _i = 0, _a = this._list; _i < _a.length; _i++) {
                var render = _a[_i];
                render.off("touchTap" /* TOUCH_TAP */, this.onTouchItem, this);
            }
            this.clear();
        };
        return MPageList;
    }(jy.AbsPageList));
    jy.MPageList = MPageList;
    __reflect(MPageList.prototype, "jy.MPageList");
})(jy || (jy = {}));
//# sourceMappingURL=MPageList.js.map