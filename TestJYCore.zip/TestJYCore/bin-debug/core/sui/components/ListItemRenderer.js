var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var jy;
(function (jy) {
    var ListItemRenderer = (function (_super) {
        __extends(ListItemRenderer, _super);
        function ListItemRenderer() {
            var _this = _super.call(this) || this;
            _this._defaultWidth = 5;
            _this._defalutHeight = 5;
            _this._oldWidth = -1;
            _this._oldHeight = -1;
            _this.inited = false;
            _this._visible = true;
            return _this;
        }
        Object.defineProperty(ListItemRenderer.prototype, "index", {
            get: function () {
                return this._idx;
            },
            set: function (value) {
                this._idx = value;
                var v = this._skin;
                if (v) {
                    v.$_rndIdx = value;
                }
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(ListItemRenderer.prototype, "dataChange", {
            get: function () {
                return this._noCheckSame || this._dataChange;
            },
            set: function (value) {
                this._dataChange = value;
            },
            enumerable: true,
            configurable: true
        });
        /**
         * 子类重写
         * 初始化组件
         * 一定要super调一下
         */
        ListItemRenderer.prototype._bind = function () {
            if (!this._skin) {
                if (this.skinlib && this.skinClass) {
                    this.skin = jy.singleton(jy.SuiResManager).createDisplayObject(this.skinlib, this.skinClass);
                }
            }
            else {
                this.inited = true;
            }
            this.checkInject();
            this.bindComponent();
        };
        ListItemRenderer.prototype.bindComponent = function () { };
        ListItemRenderer.prototype.onTouchTap = function () {
            this.dispatch(-1001 /* ITEM_TOUCH_TAP */);
            this.dispatchEventWith("touchTap" /* TOUCH_TAP */);
        };
        ListItemRenderer.prototype.$setData = function (value) {
            this._data = value;
            if (!this.inited) {
                this._bind();
            }
        };
        Object.defineProperty(ListItemRenderer.prototype, "data", {
            get: function () {
                return this._data;
            },
            set: function (value) {
                if (this._noCheckSame || value != this._data) {
                    this.$setData(value);
                }
            },
            enumerable: true,
            configurable: true
        });
        /**
         * 设置容器
         *
         * @param {egret.DisplayObjectContainer} value
         *
         * @memberOf ListItemRenderer
         */
        ListItemRenderer.prototype.setContainer = function (value) {
            var old = this._container;
            this._container = value;
            var s = this._skin;
            if (s) {
                if (value) {
                    value.addChild(s);
                }
                else if (old && old.contains(s)) {
                    old.removeChild(s);
                }
            }
            return this;
        };
        Object.defineProperty(ListItemRenderer.prototype, "skin", {
            get: function () {
                return this._skin;
            },
            // /**
            //  * 设置已定位好的皮肤
            //  * (description)
            //  */
            // public set skinTemplete(value: S) {
            //     this._skinTemplete = value;
            //     // let parent = value.parent;
            //     this.skin = value;
            //     // parent.addChild(this);
            // }
            set: function (value) {
                if (value != this._skin) {
                    this.$setSkin(value);
                }
            },
            enumerable: true,
            configurable: true
        });
        ListItemRenderer.prototype.$setSkin = function (value) {
            var old = this._skin;
            if (old) {
                old.$_rndIdx = undefined; //置空
                //移除之前的事件监听
                this.removeSkinListener(old);
            }
            this._skin = value;
            value.$_rndIdx = this._idx;
            this.$setVisible(value.visible);
            value.touchEnabled = true;
            this.addSkinListener(this._skin);
            var c = this._container;
            if (c) {
                c.addChild(value);
            }
            this._bind();
        };
        /**
         * 根据数据处理视图
         *
         * 子类重写
         */
        ListItemRenderer.prototype.handleView = function () {
            if (!this._sizeChecked) {
                this._sizeChecked = true;
                this.checkViewSize();
            }
        };
        /**
         * force为true时无条件派发一次事件，通知更新坐标
         *
         * @protected
         * @ param {boolean} [force=false] 是否强制标记为尺寸变更
         */
        ListItemRenderer.prototype.checkViewSize = function (force) {
            this._sizeChecked = false;
            var view = this._skin;
            var w = view.width;
            var h = view.height;
            if (!force) {
                if (this._oldHeight != h || this._oldWidth != w) {
                    force = true;
                }
            }
            this._oldHeight = h;
            this._oldWidth = w;
            if (force) {
                this.dispatch(-1999 /* Resize */);
            }
        };
        Object.defineProperty(ListItemRenderer.prototype, "view", {
            /**
             *
             * 获取视图
             * @readonly
             */
            get: function () {
                return this._skin;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(ListItemRenderer.prototype, "visible", {
            get: function () {
                return this._visible;
            },
            set: function (value) {
                if (value != this._visible) {
                    this.$setVisible(value);
                }
            },
            enumerable: true,
            configurable: true
        });
        ListItemRenderer.prototype.$setVisible = function (value) {
            this._visible = value;
            var skin = this._skin;
            if (skin) {
                skin.visible = value;
            }
        };
        Object.defineProperty(ListItemRenderer.prototype, "selected", {
            get: function () {
                return this._selected;
            },
            set: function (value) {
                if (this._selected != value) {
                    this.$setSelected(value);
                }
            },
            enumerable: true,
            configurable: true
        });
        ListItemRenderer.prototype.setPos = function (x, y) {
            var v = this._skin;
            if (v) {
                if (typeof x == "object") {
                    v.x = x.x;
                    v.y = x.y;
                }
                else {
                    x != undefined && (v.x = x);
                    y != undefined && (v.y = y);
                }
            }
            return this;
        };
        ListItemRenderer.prototype.$setSelected = function (value) {
            this._selected = value;
            this.dispatch(-1000 /* CHOOSE_STATE_CHANGE */);
        };
        ListItemRenderer.prototype.dispatch = function (type, data) {
            var s = this._skin;
            if (s) {
                s.dispatch(type, data);
            }
            return _super.prototype.dispatch.call(this, type, data);
        };
        /**
         * 子类重写
         * 销毁组件
         */
        ListItemRenderer.prototype.dispose = function () {
            this.removeSkinListener(this._skin);
            //清理自身所有事件
            this.removeAllListeners();
        };
        ListItemRenderer.prototype.removeSkinListener = function (skin) {
            if (skin) {
                skin.off("touchTap" /* TOUCH_TAP */, this.onTouchTap, this);
                jy.ViewController.prototype.removeSkinListener.call(this, skin);
            }
        };
        ListItemRenderer.prototype.addSkinListener = function (skin) {
            if (skin) {
                skin.on("touchTap" /* TOUCH_TAP */, this.onTouchTap, this);
                jy.ViewController.prototype.addSkinListener.call(this, skin);
            }
        };
        /**
         * 绑定TOUCH_TAP的回调
         *
         * @template T
         * @param {{ (this: T, e?: egret.Event): any }} handler
         * @param {T} [thisObject]
         * @param {number} [priority]
         * @param {boolean} [useCapture]
         */
        ListItemRenderer.prototype.bindTouch = function (handler, thisObject, priority, useCapture) {
            this.skin.touchEnabled = true;
            this.on("touchTap" /* TOUCH_TAP */, handler, thisObject, useCapture, priority);
        };
        /**
         * 解除TOUCH_TAP的回调的绑定
         *
         * @param {Function} handler
         * @param {*} thisObject
         * @param {boolean} [useCapture]
         *
         * @memberOf Button
         */
        ListItemRenderer.prototype.looseTouch = function (handler, thisObject, useCapture) {
            this.off("touchTap" /* TOUCH_TAP */, handler, thisObject, useCapture);
        };
        Object.defineProperty(ListItemRenderer.prototype, "isReady", {
            get: function () {
                return false;
            },
            enumerable: true,
            configurable: true
        });
        ListItemRenderer.prototype.startSync = function () {
        };
        return ListItemRenderer;
    }(egret.EventDispatcher));
    jy.ListItemRenderer = ListItemRenderer;
    __reflect(ListItemRenderer.prototype, "jy.ListItemRenderer", ["jy.ListItemRender", "egret.EventDispatcher", "jy.SelectableComponents"]);
    jy.expand(ListItemRenderer, jy.ViewController, "addReadyExecute", "addDepend", "stageHandler", "interest", "checkInject", "checkInterest", "awakeTimer", "sleepTimer", "bindTimer", "looseTimer");
    // export abstract class AListItemRenderer<T, S extends egret.DisplayObject> extends ListItemRenderer<T, S> implements SuiDataCallback {
    //     /**
    //      * 子类重写设置皮肤
    //      * 
    //      * @protected
    //      * @abstract
    //      * 
    //      * @memberOf ListItemRenderer
    //      */
    //     protected abstract initSkin();
    //     protected $setSkin(value: S) {
    //         if (value instanceof View) {
    //             //检查SuiResManager是否已经加载了key
    //             singleton(SuiResManager).loadData(value.key, this.$setSkin)
    //             value.key
    //         } else {
    //             super.$setSkin(value);
    //         }
    //     }
    // }
})(jy || (jy = {}));
//# sourceMappingURL=ListItemRenderer.js.map