var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var jy;
(function (jy) {
    var Scroller = (function (_super) {
        __extends(Scroller, _super);
        function Scroller() {
            var _this = _super.call(this) || this;
            _this._scrollType = 0 /* Vertical */;
            /**鼠标每移动1像素，元件移动的像素 */
            _this.globalspeed = 1;
            /**最小的滑动速度，当前值低于此值后不再滚动 */
            _this.minEndSpeed = 0.08;
            /**速度递减速率 */
            _this.blockSpeed = 0.98;
            _this._moveSpeed = 0;
            _this._deriction = 0 /* Vertical */;
            _this._key = "y" /* Y */;
            _this._sizeKey = "height" /* Height */;
            _this._measureKey = "measuredHeight" /* Height */;
            return _this;
        }
        Object.defineProperty(Scroller.prototype, "scrollType", {
            /**
             * 滚动条方式 0：垂直，1：水平 defalut:0
             */
            get: function () {
                return this._scrollType;
            },
            /**
             * 滚动条方式 0：垂直，1：水平 defalut:0
             */
            set: function (value) {
                if (this._scrollType != value) {
                    this._scrollType = value;
                    var key = void 0, sizeKey = void 0, measureKey = void 0;
                    if (value == 0 /* Vertical */) {
                        key = "y" /* Y */;
                        sizeKey = "height" /* Height */;
                        measureKey = "measuredHeight" /* Height */;
                    }
                    else {
                        key = "x" /* X */;
                        sizeKey = "width" /* Width */;
                        measureKey = "measuredWidth" /* Width */;
                    }
                    this._sizeKey = sizeKey;
                    this._key = key;
                    this._measureKey = measureKey;
                    this.checkScrollBarView();
                }
            },
            enumerable: true,
            configurable: true
        });
        Scroller.prototype.checkScrollBarView = function () {
            var content = this._content;
            if (!content) {
                return;
            }
            var scrollbar = this._scrollbar;
            if (!scrollbar) {
                return;
            }
            var _a = this, _key = _a._key, _sizeKey = _a._sizeKey, _scrollType = _a._scrollType;
            scrollbar.scrollType = _scrollType;
            var rect = content.scrollRect;
            scrollbar.bgSize = rect[_sizeKey];
            scrollbar[_key] = content[_key];
        };
        Scroller.prototype.onScrollBarAdded = function () {
            this._scrollbar.alpha = ~~this.alwaysShowBar;
        };
        /**
         * 绑定目标与滚动条
         *
         * @ content (需要滚动的目标)
         * @ scrollRect (显示的区域大小)
         * @ scrollbar (可选，如果不想显示滚动条可不传)
         */
        Scroller.prototype.bindObj = function (content, scrollRect, scrollbar) {
            content.scrollRect = scrollRect;
            var old = this._content;
            if (old != content) {
                if (old) {
                    old.off("enterFrame" /* ENTER_FRAME */, this.onRender, this);
                    old.off(-1999 /* Resize */, this.onResize, this);
                    jy.looseDrag(old);
                    old.off(-1090 /* DragStart */, this.onDragStart, this);
                    old.off(-1089 /* DragMove */, this.onDragMove, this);
                    old.off(-1088 /* DragEnd */, this.onDragEnd, this);
                }
                this._content = content;
                if (content) {
                    jy.bindDrag(content);
                    content.on(-1090 /* DragStart */, this.onDragStart, this);
                    content.on(-1999 /* Resize */, this.onResize, this);
                }
                if ("scroller" in content) {
                    content["scroller"] = this;
                }
            }
            if (scrollbar) {
                this._scrollbar = scrollbar;
                this._useScrollBar = true;
                this.checkScrollBarView();
                this.scaleBar();
                if (scrollbar.stage) {
                    this.onScrollBarAdded();
                }
                else {
                    scrollbar.on("addedToStage" /* ADDED_TO_STAGE */, this.onScrollBarAdded, this);
                }
            }
            else {
                this._useScrollBar = false;
            }
            this.scrollToHead();
        };
        /**
         * 对content绘制鼠标触发区域
         * 将会对content的graphics先进行清理
         * 然后基于content的bounds进行绘制
         *
         */
        Scroller.prototype.drawTouchArea = function (content) {
            content = content || this._content;
            if (content) {
                var g = content.graphics;
                if (g) {
                    g.clear();
                    g.beginFill(0, 0);
                    var rect = jy.Temp.EgretRectangle;
                    content.getBounds(rect);
                    g.drawRectangle(rect);
                    g.endFill();
                }
            }
        };
        Scroller.prototype.bindObj2 = function (content, scrollRect, scrollbar) {
            content.x = scrollRect.x;
            content.y = scrollRect.y;
            scrollRect.x = 0;
            scrollRect.y = 0;
            this.bindObj(content, scrollRect, scrollbar);
        };
        Scroller.prototype.onResize = function () {
            if (this._useScrollBar) {
                this.scaleBar();
            }
        };
        Scroller.prototype.onDragStart = function (e) {
            var content = this._content;
            if (!content) {
                return;
            }
            if (content[this._measureKey] < content.scrollRect[this._sizeKey]) {
                return;
            }
            this._lastTargetPos = this._startPos = this.getDragPos(e);
            this._lastMoveTime = jy.Global.now;
            this.showBar();
            content.on(-1089 /* DragMove */, this.onDragMove, this);
            content.on(-1088 /* DragEnd */, this.onDragEnd, this);
            this.dispatch(-1051 /* ScrollerDragStart */);
        };
        Scroller.prototype.getDragPos = function (e) {
            return this._scrollType == 0 /* Vertical */ ? e.stageY : e.stageX;
        };
        Scroller.prototype.onDragMove = function (e) {
            var currentPos = this.getDragPos(e);
            var sub = currentPos - this._lastTargetPos;
            this._deriction = sub > 0 ? 1 : -1;
            sub = Math.abs(sub);
            var now = jy.Global.now;
            var subTime = now - this._lastMoveTime;
            this._lastMoveTime = now;
            this._lastTargetPos = currentPos;
            this._moveSpeed = subTime > 0 ? sub / subTime : 0;
            sub = sub * this.globalspeed * this._deriction;
            this.doScrollContent(sub);
        };
        Scroller.prototype.stopTouchTween = function () {
            this._moveSpeed = 0;
            this._content.off("enterFrame" /* ENTER_FRAME */, this.onRender, this);
        };
        Scroller.prototype.onRender = function () {
            var content = this._content;
            if (!content) {
                return;
            }
            if (this._moveSpeed == 0) {
                content.off("enterFrame" /* ENTER_FRAME */, this.onRender, this);
                this.hideBar();
                return;
            }
            var now = jy.Global.now;
            var subTime = now - this._lastFrameTime;
            var moveSpeed = this._moveSpeed;
            var sub = moveSpeed * this._deriction * subTime * this.globalspeed;
            this.doScrollContent(sub);
            this._lastFrameTime = now;
            moveSpeed *= this.blockSpeed;
            if (moveSpeed < this.minEndSpeed) {
                moveSpeed = 0;
            }
            this._moveSpeed = moveSpeed;
        };
        Scroller.prototype.onDragEnd = function (e) {
            var content = this._content;
            if (!content) {
                return;
            }
            var currentPos = this.getDragPos(e);
            var now = jy.Global.now;
            if (now - this._lastMoveTime < 150) {
                content.on("enterFrame" /* ENTER_FRAME */, this.onRender, this);
                this._lastFrameTime = this._lastMoveTime;
            }
            else {
                this.hideBar();
            }
            content.off(-1089 /* DragMove */, this.onDragMove, this);
            content.off(-1088 /* DragEnd */, this.onDragEnd, this);
            this.dispatch(-1050 /* ScrollerDragEnd */, currentPos - this._startPos);
        };
        Scroller.prototype.showBar = function () {
            if (this._useScrollBar && !this.alwaysShowBar) {
                jy.Global.getTween(this._scrollbar, null, null, true).to({ alpha: 1 }, 500);
            }
        };
        Scroller.prototype.hideBar = function () {
            if (this._useScrollBar && !this.alwaysShowBar) {
                jy.Global.getTween(this._scrollbar, null, null, true).to({ alpha: 0 }, 1000);
            }
        };
        /**
         * 执行滚动
         *
         * @ sub (滚动的距离)
         */
        Scroller.prototype.doScrollContent = function (sub) {
            var content = this._content;
            if (!content) {
                return;
            }
            var rect = content.scrollRect;
            var key = this._key;
            var old = rect[key];
            var pos = old;
            var scrollEnd = this.scrollEndPos;
            pos -= sub;
            var speed = this._moveSpeed;
            if (pos < 0) {
                pos = 0;
                speed = 0;
            }
            else if (pos > scrollEnd) {
                pos = scrollEnd;
                speed = 0;
            }
            this._moveSpeed = speed;
            if (old != pos) {
                rect[key] = pos;
                content.scrollRect = rect;
                content.dispatch(-1051 /* SCROLL_POSITION_CHANGE */);
            }
            this.doMoveScrollBar(sub);
        };
        Scroller.prototype.doMoveScrollBar = function (sub) {
            var scrollbar = this._scrollbar;
            if (!scrollbar) {
                return;
            }
            var bar = scrollbar.bar;
            var subPos = sub / this._piexlDistance;
            var key = this._key;
            var barPos = bar[key] - subPos;
            if (barPos <= 0) {
                barPos = 0;
            }
            else {
                var delta = scrollbar.bgSize - scrollbar.barSize;
                if (barPos >= delta) {
                    barPos = delta;
                }
            }
            bar[key] = barPos;
        };
        /**
         * 移动到指定位置
         *
         * @ pos (位置)
         */
        Scroller.prototype.scrollTo = function (pos) {
            if (pos <= 0) {
                this.scrollToHead();
            }
            else if (pos >= this.scrollEndPos) {
                this.scrollToEnd();
            }
            else {
                var curpos = this._content.scrollRect[this._key];
                this.doScrollContent(pos - curpos);
            }
        };
        /**移动至头 */
        Scroller.prototype.scrollToHead = function () {
            var content = this._content;
            if (!content) {
                return;
            }
            if (this._moveSpeed > 0) {
                this._moveSpeed = 0;
                content.off("enterFrame" /* ENTER_FRAME */, this.onRender, this);
            }
            var rect = content.scrollRect;
            var scrollbar = this._scrollbar;
            var bar;
            if (scrollbar) {
                bar = scrollbar.bar;
            }
            var key = this._key;
            rect[key] = 0;
            if (bar) {
                bar[key] = 0;
            }
            content.scrollRect = rect;
        };
        /**移动至尾 */
        Scroller.prototype.scrollToEnd = function () {
            var content = this._content;
            if (!content) {
                return;
            }
            var rect = content.scrollRect;
            var end = this.scrollEndPos;
            var scrollbar = this._scrollbar;
            var bar, delta;
            if (scrollbar) {
                delta = scrollbar.bgSize - scrollbar.barSize;
                bar = scrollbar.bar;
            }
            var key = this._key;
            rect[key] = end;
            if (bar) {
                bar[key] = delta;
            }
            content.scrollRect = rect;
        };
        Scroller.prototype.scaleBar = function () {
            var content = this._content;
            if (!content) {
                return;
            }
            var contentSize = content[this._measureKey];
            var scrollbar = this._scrollbar;
            var bgSize = scrollbar.bgSize;
            var scale = bgSize / contentSize;
            if (scale >= 1) {
                scale = 1;
            }
            scrollbar.barSize = bgSize * scale;
            this._piexlDistance = contentSize / bgSize;
            this.checkAndResetBarPos();
        };
        Object.defineProperty(Scroller.prototype, "scrollEndPos", {
            /**
             * 获取滚动到最后的起始点
             *
             * @readonly
             * @protected
             */
            get: function () {
                var content = this._content;
                if (!content) {
                    return 0;
                }
                var rect = content.scrollRect;
                var contentSize = content[this._measureKey];
                var scrollSize = rect[this._sizeKey];
                return contentSize - scrollSize;
            },
            enumerable: true,
            configurable: true
        });
        Scroller.prototype.checkAndResetBarPos = function () {
            var rect = this._content.scrollRect;
            var scrollbar = this._scrollbar;
            var bar = scrollbar.bar;
            var scrollEnd = this.scrollEndPos;
            var key = this._key;
            var tmp = rect[key] / scrollEnd;
            if (tmp <= 0) {
                tmp = 0;
            }
            else {
                tmp = scrollbar.bgSize * tmp - scrollbar.barSize;
            }
            bar[key] = tmp;
        };
        return Scroller;
    }(egret.EventDispatcher));
    jy.Scroller = Scroller;
    __reflect(Scroller.prototype, "jy.Scroller");
})(jy || (jy = {}));
//# sourceMappingURL=Scroller.js.map