var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var jy;
(function (jy) {
    /**
     * 简易的ToolTip
     * 只处理字符串类型的描述
     * @author 3tion
     */
    var SimToolTip = (function (_super) {
        __extends(SimToolTip, _super);
        function SimToolTip(maxWidth, maxHeight, corner, autoSize) {
            if (maxWidth === void 0) { maxWidth = 480; }
            if (maxHeight === void 0) { maxHeight = 800; }
            if (corner === void 0) { corner = 5; }
            var _this = _super.call(this) || this;
            _this._autoSize = autoSize;
            _this._corner = corner;
            _this.init(maxWidth, maxHeight, corner);
            return _this;
        }
        SimToolTip.prototype.init = function (maxWidth, maxHeight, corner) {
            var tf;
            this.tf = tf = new egret.TextField();
            var c2 = corner * 2;
            tf.width = maxWidth - c2;
            tf.height = maxHeight - c2;
            tf.size = 12;
            tf.x = corner;
            tf.y = corner;
            this.addChild(tf);
            this.drawRect(0, 0, maxWidth, maxHeight);
        };
        SimToolTip.prototype.setTipData = function (msg) {
            var tf = this.tf;
            if (msg != tf.text) {
                tf.text = msg;
                if (this._autoSize) {
                    var c2 = this._corner * 2;
                    var bgW = tf.textWidth + 2 * c2;
                    var bgH = tf.textHeight + 2 * c2;
                    this.drawRect(0, 0, bgW, bgH);
                }
            }
        };
        SimToolTip.prototype.drawRect = function (x, y, width, height) {
            var g = this.graphics;
            g.clear();
            g.lineStyle(1, 0xcccccc);
            g.beginFill(0, 0.7);
            g.drawRoundRect(x, y, width, height, this._corner);
            g.endFill();
        };
        SimToolTip.prototype.show = function (container, x, y) {
            if (x != undefined && y != undefined) {
                container.addChild(this);
                this.x = x;
                this.y = y;
            }
        };
        SimToolTip.prototype.hide = function () {
            jy.removeDisplay(this);
        };
        return SimToolTip;
    }(egret.Sprite));
    jy.SimToolTip = SimToolTip;
    __reflect(SimToolTip.prototype, "jy.SimToolTip", ["jy.IToolTip"]);
})(jy || (jy = {}));
//# sourceMappingURL=SimToolTip.js.map