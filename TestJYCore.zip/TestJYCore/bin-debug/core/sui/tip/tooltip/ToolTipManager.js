var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var jy;
(function (jy) {
    /**
     * 默认的Tip
     * 手指按下控件以后，弹出Tip进行显示
     * @author 3tion
     *
     */
    var ToolTipManager = (function () {
        function ToolTipManager() {
        }
        /**
         * 注册可视对象，消息和皮肤的绑定
         *
         * @static
         * @param {egret.DisplayObject} dis 添加Tip的目标
         * @param {*} msg 要显示的内容
         * @param {IToolTip} [tooltip] Tip的皮肤，如果不填，则使用默认皮肤
         * @return {boolean} true 注册成功  false注册失败
         */
        ToolTipManager.register = function (dis, msg, tooltip, container) {
            if (!tooltip) {
                tooltip = ToolTipManager.defaultTip;
                if (!tooltip) {
                    if (true) {
                        jy.ThrowError("没有注册ToolTip的皮肤，并且没有默认的ToolTip");
                    }
                    return false;
                }
            }
            var map = ToolTipManager._map;
            var data = map.get(dis);
            if (!data) {
                data = jy.recyclable(jy.ToolTipData);
                map.set(dis, data);
            }
            if (!container) {
                container = jy.GameEngine.instance.getLayer(9000 /* Tip */);
            }
            data.register(dis, msg, tooltip, container);
            return true;
        };
        /**
         * 显示Tip，如果msg有内容，刷新Tip上的内容
         *
         * @static
         * @param {egret.DisplayObject} dis
         * @param {*} [msg]
         */
        ToolTipManager.show = function (dis, msg, container) {
            var data = ToolTipManager._map.get(dis);
            if (msg) {
                data.data = msg;
            }
            var tooltip = data.tooltip;
            if (!tooltip) {
                tooltip = ToolTipManager.defaultTip;
            }
            if (tooltip) {
                tooltip.setTipData(data.data);
                if (!container) {
                    container = data.con;
                }
                tooltip.show(container);
                this._currentSkin = tooltip;
            }
        };
        /**
         * 刷新当前Tip绑定的内容，*`不改变显示状态`*
         * 如果要刷新并显示，请使用 ToolTipManager.show
         *
         * @static
         * @param {egret.DisplayObject} dis (description)
         * @param {*} msg (description)
         */
        ToolTipManager.refresh = function (dis, msg) {
            var data = ToolTipManager._map.get(dis);
            data.data = msg;
            var tooltip = data.tooltip;
            if (!tooltip) {
                tooltip = ToolTipManager.defaultTip;
            }
            if (tooltip) {
                tooltip.setTipData(data.data);
            }
        };
        /**
         * 移除视图和ToolTip的绑定
         *
         * @static
         * @param {egret.DisplayObject} dis 可视对象
         */
        ToolTipManager.remove = function (dis) {
            var data = ToolTipManager._map.get(dis);
            data.recycle();
        };
        /**
         * 按住多少毫秒后显示Tip
         *
         * @static
         * @type {number}
         */
        ToolTipManager.touchTime = 500;
        ToolTipManager._map = new Map();
        return ToolTipManager;
    }());
    jy.ToolTipManager = ToolTipManager;
    __reflect(ToolTipManager.prototype, "jy.ToolTipManager");
})(jy || (jy = {}));
//# sourceMappingURL=ToolTipManager.js.map