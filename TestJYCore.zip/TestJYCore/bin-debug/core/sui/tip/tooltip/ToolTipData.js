var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var jy;
(function (jy) {
    /**
     * ToolTip的数据
     * @author 3tion
     */
    var ToolTipData = (function () {
        function ToolTipData() {
        }
        ToolTipData.prototype.register = function (dis, msg, tooltip, container) {
            this.data = msg;
            this.con = container;
            if (this.tooltip != tooltip) {
                this.tooltip = tooltip;
            }
            if (this.target != dis) {
                this.clearDisListener(this.target);
                jy.Global.clearCallLater(this.showTip, this);
                dis.on("touchBegin" /* TOUCH_BEGIN */, this.checkTouch, this);
            }
        };
        ToolTipData.prototype.clearDisListener = function (dis) {
            dis.off("touchBegin" /* TOUCH_BEGIN */, this.checkTouch, this);
            dis.off("touchEnd" /* TOUCH_END */, this.touchEnd, this);
        };
        ToolTipData.prototype.onRecycle = function () {
            if (this.target) {
                this.clearDisListener(this.target);
                this.target = undefined;
            }
            jy.Global.clearCallLater(this.showTip, this);
            this.data = undefined;
            this.tooltip = undefined;
        };
        ToolTipData.prototype.checkTouch = function (e) {
            this.target.on("touchEnd" /* TOUCH_END */, this.touchEnd, this);
            jy.Global.callLater(this.showTip, jy.ToolTipManager.touchTime, this);
        };
        ToolTipData.prototype.showTip = function () {
            this.target.off("touchEnd" /* TOUCH_END */, this.touchEnd, this);
            this.tooltip.show(this.con);
        };
        ToolTipData.prototype.touchEnd = function (e) {
            this.target.off("touchEnd" /* TOUCH_END */, this.touchEnd, this);
            jy.Global.clearCallLater(this.showTip, this);
        };
        return ToolTipData;
    }());
    jy.ToolTipData = ToolTipData;
    __reflect(ToolTipData.prototype, "jy.ToolTipData", ["jy.IRecyclable"]);
})(jy || (jy = {}));
//# sourceMappingURL=ToolTipData.js.map