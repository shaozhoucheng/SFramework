var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var jy;
(function (jy) {
    /**
     * 错误提示
     * @author pb
     */
    var ErrorTips = (function () {
        function ErrorTips(parent) {
            this._parent = parent;
        }
        ErrorTips.prototype.show = function (msg, color, duration, delay) {
            if (color === void 0) { color = 0xffffff; }
            if (duration === void 0) { duration = 1000; }
            if (delay === void 0) { delay = 1000; }
            var txt = new egret.TextField();
            txt.textAlign = egret.HorizontalAlign.CENTER;
            if (/<[^>]+>/.test(msg)) {
                txt.setHtmlText(msg);
            }
            else {
                txt.text = msg;
            }
            txt.alpha = 1;
            jy.Layout.layout(txt, 10 /* MIDDLE_CENTER */);
            txt.textColor = color;
            this._parent.addChild(txt);
            var tween = jy.Global.getTween(txt);
            tween.to({ y: txt.y - 100 }, duration).to({ alpha: 0 }, delay).call(this.txtComplete, this, [tween, txt]);
        };
        ErrorTips.prototype.txtComplete = function (arg) {
            var tween = arg[0];
            var txt = arg[1];
            if (tween) {
                tween.paused = true;
                tween.onRecycle();
            }
            if (txt)
                jy.removeDisplay(txt);
        };
        return ErrorTips;
    }());
    jy.ErrorTips = ErrorTips;
    __reflect(ErrorTips.prototype, "jy.ErrorTips");
})(jy || (jy = {}));
//# sourceMappingURL=ErrorTips.js.map