var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var jy;
(function (jy) {
    var View = (function (_super) {
        __extends(View, _super);
        function View(key, className) {
            var _this = _super.call(this) || this;
            _this.suiClass = className;
            _this.suiLib = key;
            jy.singleton(jy.SuiResManager).createComponents(key, className, _this);
            return _this;
        }
        return View;
    }(egret.Sprite));
    jy.View = View;
    __reflect(View.prototype, "jy.View");
    ;
    jy.addEnable(View);
})(jy || (jy = {}));
//# sourceMappingURL=View.js.map