var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var jy;
(function (jy) {
    /**
     * 图片字字库
     * Key为图片文字文件名（不带扩展名）
     * Value为egret.Texture
     *
     * @export
     * @class ArtWord
     * @author 3tion
     */
    var ArtWord = (function () {
        function ArtWord(name) {
            this._txs = {};
            this.name = name;
        }
        /**
         * 获取纹理数据
         *
         * @param {Key} key
         * @returns
         *
         * @memberOf ArtWord
         */
        ArtWord.prototype.getTexture = function (key) {
            return this._txs[key];
        };
        ArtWord.prototype.parseData = function (data, suiData) {
            this._suiData = suiData;
            // const imgs = suiData.pngtexs;
            var txs = this._txs;
            for (var i = 0, len = data.length; i < len; i++) {
                var dat = data[i];
                var key = dat[0];
                txs[key] = suiData.getTexture(dat[1]); //imgs[dat[1]];
            }
            jy.refreshTexs(suiData, this);
        };
        return ArtWord;
    }());
    jy.ArtWord = ArtWord;
    __reflect(ArtWord.prototype, "jy.ArtWord");
})(jy || (jy = {}));
//# sourceMappingURL=ArtWord.js.map