var jy;
(function (jy) {
    /**
     * 给ArtText和ArtWord刷新纹理使用
     *
     * @export
     * @param {SuiData} suiData
     * @param {{ refreshBMD?: { (): void } }} thisObj
     */
    function refreshTexs(suiData, thisObj) {
        var bmds = suiData.pngbmd;
        // let bmdState = bmds.bmdState;
        if (!("refreshBMD" in thisObj)) {
            thisObj.refreshBMD = function () {
                //刷新纹理中的数据
                var txs = this._txs;
                var bmd = bmds.bmd;
                for (var key in txs) {
                    txs[key]._bitmapData = bmd;
                }
            };
        }
        suiData.checkRefreshBmp(thisObj);
    }
    jy.refreshTexs = refreshTexs;
})(jy || (jy = {}));
//# sourceMappingURL=refreshTexs.js.map