var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var jy;
(function (jy) {
    /**
     *
     * 用于处理SuiData中的纹理加载
     * @export
     * @class SuiBmd
     * @author gushuai
     */
    var SuiBmd = (function () {
        function SuiBmd(uri, url) {
            this.textures = [];
            this.bmdState = 0 /* UNREQUEST */;
            /**
             * 使用计数
             */
            this.using = 0;
            this.lastUseTime = 0;
            /**
             * 未加载的时候，请求的位图
             */
            this.loading = [];
            this.uri = uri;
            this.url = url;
        }
        Object.defineProperty(SuiBmd.prototype, "isStatic", {
            get: function () {
                return this.using > 0;
            },
            enumerable: true,
            configurable: true
        });
        SuiBmd.prototype.loadBmd = function () {
            if (this.bmdState <= 0 /* UNREQUEST */) {
                jy.Res.load(this.uri, this.url, jy.CallbackInfo.get(this.checkBitmap, this));
                this.bmdState = 1 /* REQUESTING */;
            }
        };
        SuiBmd.prototype.checkBitmap = function (item) {
            var uri = item.uri, data = item.data;
            if (this.uri == uri) {
                if (!data) {
                    jy.dispatch(-1070 /* SuiBmdLoadFailed */, this.uri);
                    if (true) {
                        data = ErrorTexture;
                    }
                    else {
                        return;
                    }
                }
                var bmd = data.bitmapData;
                var imgs = this.textures;
                this.bmd = bmd;
                for (var _i = 0, imgs_1 = imgs; _i < imgs_1.length; _i++) {
                    var tex = imgs_1[_i];
                    tex.$bitmapData = bmd;
                }
                var loading = this.loading;
                if (loading) {
                    //将绑定的位图，全部重新设置一次
                    for (var _a = 0, loading_1 = loading; _a < loading_1.length; _a++) {
                        var bmp = loading_1[_a];
                        bmp.refreshBMD();
                    }
                    loading.length = 0;
                }
                this.bmdState = 2 /* COMPLETE */;
            }
        };
        SuiBmd.prototype.dispose = function () {
            var bmd = this.bmd;
            this.bmdState = 0 /* UNREQUEST */;
            if (bmd) {
                bmd.$dispose();
                this.bmd = undefined;
                jy.Res.remove(this.uri);
            }
        };
        return SuiBmd;
    }());
    jy.SuiBmd = SuiBmd;
    __reflect(SuiBmd.prototype, "jy.SuiBmd", ["jy.IResource"]);
})(jy || (jy = {}));
//# sourceMappingURL=SuiBmd.js.map