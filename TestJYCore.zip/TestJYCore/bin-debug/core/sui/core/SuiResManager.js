var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var jy;
(function (jy) {
    var Texture = egret.Texture;
    function getSuiDataUri(key) {
        return "$SuiData$_" + key;
    }
    jy.getSuiDataUri = getSuiDataUri;
    /**
     * 用于管理位图和数据
     * @author 3tion
     *
     */
    var SuiResManager = (function () {
        function SuiResManager() {
            this._suiDatas = {};
            this._urlKey = {};
            this.initInlineCreators();
            // ResourceManager.addChecker(this);
        }
        SuiResManager.prototype.initInlineCreators = function () {
            this._creators = (_a = {},
                _a[3 /* Button */] = jy.ButtonCreator,
                _a[6 /* ShapeNumber */] = jy.ArtTextCreator,
                _a[5 /* ScaleBitmap */] = jy.ScaleBitmapCreator,
                _a[7 /* NumericStepper */] = jy.NumericStepperCreator,
                _a[8 /* Slider */] = jy.SliderCreator,
                _a[9 /* ScrollBar */] = jy.ScrollBarCreator,
                _a[10 /* ProgressBar */] = jy.ProgressBarCreator,
                _a[11 /* SlotBg */] = jy.ScaleBitmapCreator,
                _a[12 /* ShareBmp */] = jy.ShareBitmapCreator,
                _a[13 /* Slot */] = jy.SlotCreator,
                _a[19 /* MovieClip */] = jy.MovieClipCreator,
                _a[20 /* MCButton */] = jy.MCButtonCreator,
                _a[21 /* MCProgress */] = jy.MCProgressCreator,
                _a);
            this.sharedTFCreator = new jy.TextFieldCreator();
            var _a;
        };
        SuiResManager.prototype.getData = function (key) {
            return this._suiDatas[key];
        };
        /**
         * 加载数据
         */
        SuiResManager.prototype.loadData = function (key, callback, qid) {
            var suiData = this._suiDatas[key];
            if (!suiData) {
                suiData = this.createSuiData(key);
            }
            var state = suiData.state;
            if (state == -1 /* FAILED */) {
                callback && callback.suiDataFailed(suiData);
            }
            else if (state == 2 /* COMPLETE */) {
                callback && callback.suiDataComplete(suiData);
            }
            else {
                var callbacks = suiData.callbacks;
                if (!callbacks) {
                    suiData.callbacks = callbacks = [];
                }
                callback && callbacks.pushOnce(callback);
                if (state == 0 /* UNREQUEST */) {
                    suiData.state = 1 /* REQUESTING */;
                    //先加载配置
                    jy.Res.load(suiData.uri, suiData.url, jy.CallbackInfo.get(this.checkData, this), qid);
                }
            }
        };
        /**
         * 数据加载完成
         */
        SuiResManager.prototype.checkData = function (item) {
            var uri = item.uri, data = item.data;
            var suiData = this._urlKey[uri];
            if (!data) {
                suiData.state = 0 /* UNREQUEST */;
                var callbacks = suiData.callbacks;
                if (callbacks) {
                    for (var i = 0; i < callbacks.length; i++) {
                        var callback = callbacks[i];
                        callback.suiDataFailed(suiData);
                    }
                    delete suiData.callbacks;
                }
                return;
            }
            this._initSuiData(data, suiData);
        };
        /**
         *
         * 直接将已经加载好的内置数据，和key进行绑定
         * @param {string} key
         * @param {any} data
         * @param {string} [skinUri] 皮肤标识
         */
        SuiResManager.prototype.setInlineData = function (key, data, skinUri) {
            var uri = getSuiDataUri(key);
            var suiData = this._urlKey[uri];
            if (!suiData) {
                suiData = this.createSuiData(key);
            }
            suiData.skinUri = skinUri;
            this._initSuiData(data, suiData);
        };
        SuiResManager.prototype.createSuiData = function (key) {
            var suiData = new jy.SuiData(key);
            this._suiDatas[key] = suiData;
            this._urlKey[suiData.uri] = suiData;
            return suiData;
        };
        /**
         *
         * 初始化数据
         * @private
         * @param {*} data
         * @param {SuiData} suiData
         */
        SuiResManager.prototype._initSuiData = function (data, suiData) {
            //  data的数据结构：
            //  lib[
            //     [ //图片
            // 		[128,32,12,33],//图片1   索引0
            //        [224,210,33,66],//图片2  索引1
            //         ......
            //        [48,62,133,400],//图片21 索引20
            //      ],{
            //        "btn":[ //按钮类型/页签/单选框/多选框 3帧或者4帧  0弹起 1选中 2禁用(未选中的样子) 3禁用(选中)
            //             //存放导出名字,
            //           ["ui.btn.Button1", //索引0
            //             "ui.tab.Tab1"],   //索引1
            // 			//存放数据
            //             [{...},
            //             {...}]
            //        ],
            //        "scroll":[//滚动条 track bar
            // 		],
            //        "progress":[//进度条
            //        ]
            //        },{
            //          "panel":[
            //    
            //          ]
            //        }
            //     ]
            //解析img节点
            var pngs = data[0];
            if (pngs) {
                this.parseTextureData(pngs, suiData, true);
            }
            var jpgs = data[2];
            if (jpgs) {
                this.parseTextureData(jpgs, suiData);
            }
            //处理控件
            this.parseComponentData(data[1], suiData);
            var panelsData;
            var panelNames = data[4];
            if (panelNames) {
                var list = data[3];
                panelsData = {};
                for (var i = 0; i < list.length; i++) {
                    var pdata = list[i];
                    var className = panelNames[pdata[0]];
                    panelsData[className] = pdata.slice(1);
                }
                suiData.panelNames = panelNames;
            }
            else {
                panelsData = data[3];
            }
            if (panelsData) {
                suiData.panelsData = panelsData;
            }
            //数据已经完成，未加载位图
            suiData.state = 2 /* COMPLETE */;
            var callbacks = suiData.callbacks;
            if (callbacks) {
                for (var i = 0; i < callbacks.length; i++) {
                    var callback = callbacks[i];
                    callback.suiDataComplete(suiData);
                }
                delete suiData.callbacks;
            }
        };
        /**
         * 处理控件数据
         */
        SuiResManager.prototype.parseComponentData = function (allComData, suiData) {
            suiData.sourceComponentData = allComData;
            for (var type in allComData) {
                var comsData = allComData[type];
                var nameData = comsData[0]; //["ui.btn.Button1", "ui.tab.Tab1"] 
                var comData = comsData[1]; //[{...},{...}]//组件的数据
                var sizeData = comsData[2];
                var len = nameData.length;
                if (type == 15 /* ArtWord */) {
                    var fonts = suiData.fonts;
                    for (var i = 0; i < len; i++) {
                        var linkName = nameData[i];
                        var dat = comData[i];
                        var fontLib = new jy.ArtWord(linkName);
                        fontLib.parseData(dat, suiData);
                        if (!fonts) {
                            suiData.fonts = fonts = {};
                        }
                        fonts[linkName] = fontLib;
                    }
                }
                else {
                    var ref = this._creators[type];
                    if (ref) {
                        var lib = suiData.lib;
                        for (var i = 0; i < len; i++) {
                            var name_1 = nameData[i];
                            var dat = comData[i];
                            var creator = new ref;
                            creator.parseData(null, suiData);
                            if (dat) {
                                creator.parseSelfData(dat);
                                creator.parseSize(sizeData[i]);
                            }
                            lib[name_1] = creator;
                        }
                    }
                }
            }
        };
        /**
         * 解析图片数据
         *  0 图片宽  1图片高度   2偏移X   3偏移Y
         */
        SuiResManager.prototype.parseTextureData = function (data, suiData, ispng) {
            if (data) {
                var imgs = [];
                var bcs = suiData.bmplibs;
                if (!bcs) {
                    suiData.bmplibs = bcs = {};
                }
                suiData.createBmpLoader(ispng, imgs);
                for (var i = 0, len = data.length; i < len; i++) {
                    var imgData = data[i];
                    var tex = new Texture();
                    var width = imgData[0];
                    var height = imgData[1];
                    var sx = imgData[2];
                    var sy = imgData[3];
                    tex.$initData(sx, sy, width, height, 0, 0, width, height, width, height);
                    imgs[i] = tex;
                    var bc = new jy.BitmapCreator(suiData);
                    var idx = ispng ? i : -1 - i;
                    bc.parseSelfData(idx);
                    bcs[idx] = bc;
                }
            }
        };
        /**
         * 创建可视控件
         * @param uri           皮肤标识
         * @param className     类名字
         * @param baseData      基础数据
         */
        SuiResManager.prototype.createDisplayObject = function (uri, className, baseData) {
            var suiData = this._suiDatas[uri];
            if (suiData) {
                var creator = suiData.lib[className];
                if (creator) {
                    creator.setBaseData(baseData);
                    var disp = creator.get();
                    disp.suiClass = className;
                    disp.suiLib = uri;
                    return disp;
                }
                else if (true) {
                    jy.ThrowError("\u6CA1\u6709\u5728[" + suiData.key + "]\u627E\u5230\u5BF9\u5E94\u7EC4\u4EF6[" + className + "]");
                }
            }
            // //[3,["btn2",14.5,139,79,28,0],0,0]
            // return;
        };
        /**
         * 处理元素数据
         * 对应 https://github.com/eos3tion/ExportUIFromFlash  项目中
         * Solution.ts -> getElementData的元素数据的解析
         * @param {string} uri 库标识
         * @param {ComponentData} data 长度为4的数组
         * 0 导出类型
         * 1 基础数据 @see Solution.getEleBaseData
         * 2 对象数据 不同类型，数据不同
         * 3 引用的库 0 当前库  1 lib  字符串 库名字
         * @memberOf BaseCreator
         */
        SuiResManager.prototype.createElement = function (uri, data) {
            var suiData = typeof uri === "string" ? this._suiDatas[uri] : uri;
            if (suiData) {
                var cRef = this._creators[+data[0]];
                if (cRef) {
                    var creator = new cRef();
                    creator.parseData(data, suiData);
                    var dis = creator.get();
                    dis.suiLib = suiData.key;
                    return dis;
                }
                else if (true) {
                    jy.ThrowError("createElement\u65F6\uFF0C\u6CA1\u6709\u627E\u5230\u5BF9\u5E94\u7EC4\u4EF6\uFF0C\u7D22\u5F15\uFF1A[" + +data[0] + "]");
                }
            }
        };
        /**
         * 创建位图对象
         * @param uri       皮肤标识
         * @param index     位图索引 data[2]
         * @param baseData  基础数据 data[1]
         */
        SuiResManager.prototype.createBitmap = function (uri, index, baseData) {
            var suiData = this._suiDatas[uri];
            if (suiData) {
                var bcs = suiData.bmplibs;
                var bc = bcs[index];
                if (bc) {
                    bc.setBaseData(baseData);
                    return bc.get();
                }
            }
        };
        /**
         * 获取美术字
         *
         * @param {string} uri          皮肤标识
         * @param {string} artword      美术字
         * @returns
         *
         * @memberOf SuiResManager
         */
        SuiResManager.prototype.getArtWord = function (uri, artword) {
            var suiData = this._suiDatas[uri];
            if (suiData) {
                var fonts = suiData.fonts;
                if (fonts) {
                    return fonts[artword];
                }
            }
        };
        /**
         * 获取美术字的纹理
         *
         * @param {string} uri          皮肤标识
         * @param {string} artword      美术字
         * @param {Key} font         指定的文字
         * @returns
         *
         * @memberOf SuiResManager
         */
        SuiResManager.prototype.getArtWordTexture = function (uri, artword, font) {
            var fonts = this.getArtWord(uri, artword);
            if (fonts) {
                return fonts.getTexture(font);
            }
        };
        /**
         *  创建位图对象
         * @param uri       皮肤标识
         * @param data      JSON的数据
         */
        SuiResManager.prototype.createBitmapByData = function (uri, data) {
            return this.createBitmap(uri, data[2], data[1]);
        };
        /**
         * 创建文本框
         * @param uri       皮肤标识
         * @param data      私有数据 data[2]
         * @param baseData  基础数据 data[1]
         */
        SuiResManager.prototype.createTextField = function (uri, data, baseData) {
            var tfCreator = this.sharedTFCreator;
            tfCreator.parseSelfData(data);
            tfCreator.setBaseData(baseData);
            return tfCreator.get();
        };
        /**
        *  创建文本框
        * @param uri       皮肤标识
        * @param data      JSON的数据
        */
        SuiResManager.prototype.createTextFieldByData = function (uri, data) {
            return this.createTextField(uri, data[2], data[1]);
        };
        SuiResManager.initBaseData = function (dis, data) {
            var name = data[0], x = data[1], y = data[2], w = data[3], h = data[4], rot = data[5], alpha = data[6], adjustColors = data[7];
            if (name) {
                dis.name = name;
            }
            dis.suiRawRect = new egret.Rectangle(x, y, w, h);
            if (Array.isArray(rot)) {
                var a = rot[0], b = rot[1], c = rot[2], d = rot[3];
                var matrix = dis.matrix;
                matrix.setTo(a, b, c, d, x, y);
                dis.$setMatrix(matrix, true);
            }
            else {
                dis.width = w;
                dis.height = h;
                dis.x = x;
                dis.y = y;
                if (rot) {
                    dis.rotation = rot;
                }
            }
            if (alpha != undefined) {
                dis.alpha = alpha;
            }
            if (adjustColors) {
                dis.filters = [jy.FilterUtils.adjustColorFilter(adjustColors[0], adjustColors[1], adjustColors[2], adjustColors[3])];
            }
        };
        /**
         * 创建子控件
         *
         * @param {string} key
         * @param {string} className
         * @param {egret.DisplayObjectContainer} view
         */
        SuiResManager.prototype.createComponents = function (key, className, view) {
            var suiData = this._suiDatas[key];
            if (suiData) {
                var panelsData = suiData.panelsData;
                if (panelsData) {
                    var panelData = panelsData[className];
                    if (panelData) {
                        var sizeData = panelData[0], compsData = panelData[1];
                        view.suiRawRect = new egret.Rectangle(sizeData[0], sizeData[1], sizeData[2], sizeData[3]);
                        view.suiClass = className;
                        view.suiLib = key;
                        this._createComponents(suiData, view, compsData);
                    }
                }
            }
        };
        SuiResManager.prototype._createComponents = function (suiData, view, compsData) {
            if (!compsData) {
                return;
            }
            for (var i = 0; i < compsData.length; i++) {
                this.createComponent(compsData[i], suiData, view);
            }
        };
        SuiResManager.prototype.createComponent = function (data, suiData, view) {
            var ele;
            var baseData = data[1];
            var type = data[0];
            if (type == 14 /* Rectangle */) {
                ele = new egret.Rectangle(baseData[1], baseData[2], baseData[3], baseData[4]);
            }
            else {
                if (type == 2 /* Container */) {
                    ele = new egret.Sprite();
                    SuiResManager.initBaseData(ele, baseData);
                    this._createComponents(suiData, ele, data[2]);
                }
                else {
                    ele = this.getElement(suiData, data);
                }
                if (ele) {
                    view.addChild(ele);
                }
                else if (true) {
                    jy.ThrowError("\u6CA1\u6709\u6B63\u786E\u521B\u5EFA\u539F\u4EF6\uFF0C\u7C7B\u578B\uFF1A" + type + "\uFF0C\u6570\u636E\uFF1A" + JSON.stringify(data));
                }
            }
            var name = baseData[0];
            if (name) {
                view[name] = ele;
            }
            return ele;
        };
        SuiResManager.prototype.getElement = function (suiData, data) {
            var type = data[0], bd = data[1], sd = data[2], lib = data[3];
            switch (type) {
                case 1 /* Text */:
                    var tc = new jy.TextFieldCreator();
                    tc.setBaseData(bd);
                    tc.parseSelfData(sd);
                    return tc.get();
                case 0 /* Image */:
                    var bg = new jy.BitmapCreator(suiData);
                    bg.parseData(data, suiData);
                    return bg.get();
                case 16 /* Sprite */:
                    var sp = new egret.Sprite();
                    SuiResManager.initBaseData(sp, bd);
                    return sp;
                case 17 /* ImageLoader */:
                    var il = new jy.Image();
                    SuiResManager.initBaseData(il, bd);
                    return il;
                default:
                    if (lib == undefined)
                        lib = 0;
                    var libKey = void 0;
                    switch (lib) {
                        case 0:
                            libKey = suiData.key;
                            break;
                        case 1:
                            libKey = "lib";
                            break;
                        default:
                            libKey = lib;
                            break;
                    }
                    if (type == 18 /* ExportedContainer */) {
                        var className = suiData.panelNames[~~sd];
                        var v = new jy.View(libKey, className);
                        SuiResManager.initBaseData(v, bd);
                        return v;
                    }
                    else {
                        var source = suiData.sourceComponentData;
                        if (source) {
                            var sourceData = source[type];
                            if (sourceData) {
                                var names = sourceData[0]; //名字列表
                                if (names) {
                                    var idx = sd;
                                    var name_2 = names[idx];
                                    if (name_2) {
                                        return this.createDisplayObject(libKey, name_2, bd);
                                    }
                                }
                            }
                        }
                        return this.createElement(libKey, data);
                    }
            }
        };
        /**
         * 获取控件尺寸
         *
         * @param {string} key
         * @param {string} className
         * @param {egret.Rectangle} [outRect]
         * @returns
         */
        SuiResManager.prototype.getSize = function (key, className, outRect) {
            var suiData = this._suiDatas[key];
            if (suiData) {
                var panelsData = suiData.panelsData;
                if (panelsData) {
                    var panelData = panelsData[className];
                    if (panelData) {
                        var sizeData = panelData[0];
                        outRect = outRect || new egret.Rectangle();
                        outRect.setTo(sizeData[0], sizeData[1], sizeData[2], sizeData[3]);
                        return outRect;
                    }
                }
            }
        };
        return SuiResManager;
    }());
    jy.SuiResManager = SuiResManager;
    __reflect(SuiResManager.prototype, "jy.SuiResManager");
})(jy || (jy = {}));
//# sourceMappingURL=SuiResManager.js.map