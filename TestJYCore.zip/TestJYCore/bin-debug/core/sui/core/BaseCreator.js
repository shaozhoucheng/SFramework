var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var jy;
(function (jy) {
    /**
     * 基础创建器
     * @author 3tion
     *
     */
    var BaseCreator = (function () {
        function BaseCreator() {
        }
        Object.defineProperty(BaseCreator.prototype, "suiData", {
            get: function () {
                return this._suiData;
            },
            enumerable: true,
            configurable: true
        });
        BaseCreator.prototype.bindSuiData = function (suiData) {
            this._suiData = suiData;
        };
        BaseCreator.prototype.parseData = function (data, suiData) {
            if (!this._parsed) {
                this._parsed = true;
                this.bindSuiData(suiData);
                if (data) {
                    this.setBaseData(data[1]);
                    this.parseSelfData(data[2]);
                }
            }
        };
        /**
         * 处理尺寸
         *
         * @param {SizeData} data
         *
         * @memberOf BaseCreator
         */
        BaseCreator.prototype.parseSize = function (data) {
            if (data) {
                this.size = new egret.Rectangle(data[0], data[1], data[2], data[3]);
            }
        };
        /**
         * 处理元素数据
         * 对应 https://github.com/eos3tion/ExportUIFromFlash  项目中
         * Solution.ts -> getElementData的元素数据的解析
         * @param {ComponentData} data 长度为4的数组
         * 0 导出类型
         * 1 基础数据 @see Solution.getEleBaseData
         * 2 对象数据 不同类型，数据不同
         * 3 引用的库 0 当前库  1 lib  字符串 库名字
         * @memberOf BaseCreator
         */
        BaseCreator.prototype.createElement = function (data) {
            return jy.singleton(jy.SuiResManager).getElement(this._suiData, data);
        };
        BaseCreator.prototype.setBaseData = function (data) {
            this._baseData = data;
        };
        BaseCreator.prototype.parseSelfData = function (data) {
        };
        /**
         * 获取实例
         */
        BaseCreator.prototype.get = function () {
            var t = this._createT();
            t.suiRawRect = this.size;
            if (t instanceof jy.Component) {
                t.init(this);
            }
            if (this._baseData) {
                jy.SuiResManager.initBaseData(t, this._baseData);
            }
            return t;
        };
        return BaseCreator;
    }());
    jy.BaseCreator = BaseCreator;
    __reflect(BaseCreator.prototype, "jy.BaseCreator");
})(jy || (jy = {}));
//# sourceMappingURL=BaseCreator.js.map