var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var jy;
(function (jy) {
    /**
     * 用于加载和存储fla导出的ui数据和位图
     * @author 3tion
     *
     */
    var SuiData = (function () {
        function SuiData(key) {
            /**
             * 数据加载状态
             * 0 未加载
             * 1 加载中
             * 2 数据加载完成
             */
            this.state = 0 /* UNREQUEST */;
            /**
             * 库数据
             * key      fla中设置的导出名<br/>
             * value    皮肤数据<br/>
             */
            this.lib = {};
            this.key = key;
            this.url = jy.ConfigUtils.getSkinFile(key, "s.json" /* DataFile */);
            this.uri = jy.getSuiDataUri(key);
        }
        SuiData.prototype.createBmpLoader = function (ispng, textures) {
            var file = "d" + (ispng ? ".png" /* PNG */ : ".jpg" /* JPG */);
            //增加一个skin前缀
            var uri = this.skinUri || "skin/" + jy.ConfigUtils.getSkinPath(this.key, file);
            var tmp = jy.ResManager.get(uri, this.noRes, this, uri, file, textures);
            ispng ? this.pngbmd = tmp : this.jpgbmd = tmp;
        };
        SuiData.prototype.noRes = function (uri, file, textures) {
            var url = jy.ConfigUtils.getSkinFile(this.key, file) + jy.Global.webp;
            var tmp = new jy.SuiBmd(uri, url);
            tmp.textures = textures;
            return tmp;
        };
        /**
         * 刷新位图
         *
         * @param {SuiBmdCallback} bmp  要刷新的位图
         * @param {boolean} [isjpg]     是否为jpg纹理，默认为png
         */
        SuiData.prototype.checkRefreshBmp = function (bmp, isjpg) {
            var tmp = isjpg ? this.jpgbmd : this.pngbmd;
            if (tmp) {
                tmp.using++;
                if (tmp.bmdState == 2 /* COMPLETE */) {
                    if (bmp.refreshBMD) {
                        bmp.refreshBMD();
                    }
                    return true;
                }
                else {
                    tmp.loading.pushOnce(bmp);
                    tmp.loadBmd();
                    return false;
                }
            }
        };
        /**获取对应索引位置的texture */
        SuiData.prototype.getTexture = function (index) {
            var inx = index;
            var bmd = this.pngbmd;
            if (index < 0) {
                inx = -1 - index;
                bmd = this.jpgbmd;
            }
            var txts = bmd.textures;
            if (txts) {
                return txts[inx];
            }
        };
        SuiData.prototype.loadBmd = function (callback) {
            var bin = jy.recyclable(CallbackBin);
            var count = 0;
            //检查bmd状态
            this.jpgbmd && !this.checkRefreshBmp(bin, true) && count++;
            this.pngbmd && !this.checkRefreshBmp(bin) && count++;
            if (count) {
                bin.count = count;
                bin.callback = callback;
            }
            else {
                bin.recycle();
                callback && callback.execute(true);
            }
        };
        return SuiData;
    }());
    jy.SuiData = SuiData;
    __reflect(SuiData.prototype, "jy.SuiData");
    var CallbackBin = (function () {
        function CallbackBin() {
        }
        CallbackBin.prototype.refreshBMD = function () {
            var count = this.count;
            if (!--count) {
                var callback = this.callback;
                if (callback) {
                    this.callback = undefined;
                    callback.execute(true);
                }
            }
            else {
                this.count = count;
            }
        };
        return CallbackBin;
    }());
    __reflect(CallbackBin.prototype, "CallbackBin");
})(jy || (jy = {}));
//# sourceMappingURL=SuiData.js.map