var jy;
(function (jy) {
    var TouchEvent = egret.TouchEvent;
    var Event = egret.Event;
    var key = "$__$Drag";
    function dispatchTouchEvent(target, type, e, deltaX, deltaY, deltaTime) {
        if (!target.hasEventListener(type)) {
            return true;
        }
        var event = Event.create(TouchEvent, type, true, true);
        event.$initTo(e.stageX, e.stageY, e.touchPointID);
        event.touchDown = e.touchDown;
        event.deltaX = deltaX;
        event.deltaY = deltaY;
        event.deltaTime = deltaTime;
        var result = target.dispatchEvent(event);
        Event.release(event);
        event.deltaX = undefined;
        event.deltaY = undefined;
        event.deltaTime = undefined;
        return result;
    }
    var stage;
    function onStart(e) {
        this.lt = Date.now();
        this.lx = e.stageX;
        this.ly = e.stageY;
        stage.on("touchMove" /* TOUCH_MOVE */, onMove, this);
        stage.on("touchEnd" /* TOUCH_END */, onEnd, this);
    }
    function onMove(e) {
        if (!e.touchDown) {
            return onEnd.call(this, e);
        }
        var nx = e.stageX;
        var ny = e.stageY;
        var dx = nx - this.lx;
        var dy = ny - this.ly;
        var now = Date.now();
        var delta = now - this.lt;
        var _a = this, dragStart = _a.dragStart, host = _a.host;
        if (dragStart) {
            if (this.isCon) {
                host.touchChildren = false;
            }
            dispatchTouchEvent(host, -1089 /* DragMove */, e, dx, dy, delta);
        }
        else {
            if (delta > this.minDragTime) {
                dragStart = true;
            }
            else {
                var dist = dx * dx + dy * dy;
                if (dist > this.minSqDist) {
                    dragStart = true;
                }
            }
            if (dragStart) {
                dispatchTouchEvent(host, -1090 /* DragStart */, e, dx, dy, delta);
            }
            this.dragStart = dragStart;
        }
        if (dragStart) {
            this.lx = nx;
            this.ly = ny;
            this.lt = now;
        }
    }
    function onEnd(e) {
        if (this.dragStart) {
            e.preventDefault(); //阻止普通点击事件发生
            e.stopImmediatePropagation();
            var host = this.host;
            if (this.isCon) {
                host.touchChildren = true;
            }
            dispatchTouchEvent(host, -1088 /* DragEnd */, e);
        }
        this.dragStart = false;
        stage.off("touchMove" /* TOUCH_MOVE */, onMove, this);
        stage.off("touchEnd" /* TOUCH_END */, onEnd, this);
    }
    /**
     *
     * @param {egret.DisplayObject} host 要被拖拽的对象
     * @param {boolean} [stopChildren=true] 是否屏蔽子控件的
     * @param {number} [minDragTime=300] 最小拖拽事件
     * @param {number} [minSqDist=400] 最小
     */
    function bindDrag(host, stopChildren, minDragTime, minSqDist) {
        if (stopChildren === void 0) { stopChildren = true; }
        if (minDragTime === void 0) { minDragTime = 300; }
        if (minSqDist === void 0) { minSqDist = 400; }
        stage = stage || egret.sys.$TempStage;
        var isCon = stopChildren && host instanceof egret.DisplayObjectContainer;
        host.touchEnabled = true;
        var dele = { host: host, isCon: isCon, minDragTime: minDragTime, minSqDist: minSqDist };
        host.on("touchBegin" /* TOUCH_BEGIN */, onStart, dele);
        host[key] = dele;
    }
    jy.bindDrag = bindDrag;
    function looseDrag(host) {
        var dele = host[key];
        if (dele) {
            stage.off("touchMove" /* TOUCH_MOVE */, onMove, dele);
            stage.off("touchEnd" /* TOUCH_END */, onEnd, dele);
            dele.host.off("touchBegin" /* TOUCH_BEGIN */, onStart, dele);
            if (dele.isCon) {
                host.touchChildren = true;
            }
            delete host[key];
        }
    }
    jy.looseDrag = looseDrag;
})(jy || (jy = {}));
//# sourceMappingURL=Drag.js.map