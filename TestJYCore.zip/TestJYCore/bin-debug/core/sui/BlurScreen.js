var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var jy;
(function (jy) {
    /**
     *
     * 用于弹出窗口，并将下层模糊的工具类
     * @export
     * @class BlurScreen
     * @author gushuai
     */
    var BlurScreen = (function () {
        function BlurScreen() {
            this._engine = jy.GameEngine.instance;
            this._bmp = new egret.Bitmap();
            this._stage = egret.sys.$TempStage;
            this._con = new egret.Sprite();
            this._tex = new egret.RenderTexture();
            this._dic = {};
        }
        BlurScreen.prototype.regModuleLayers = function (moduleid) {
            var _this = this;
            var ids = [];
            for (var _i = 1; _i < arguments.length; _i++) {
                ids[_i - 1] = arguments[_i];
            }
            var _a = this, _dic = _a._dic, _engine = _a._engine;
            var layers = ids.map(function (id) { return _this._engine.getLayer(id); });
            layers.doSort("id");
            _dic[moduleid] = layers;
        };
        BlurScreen.prototype.checkShowBlur = function (id) {
            var dic = this._dic;
            var layers = dic[id];
            this._current = id;
            if (layers && layers.length) {
                this._stage.on("resize" /* RESIZE */, this.drawBlur, this);
                this.drawBlur();
            }
        };
        BlurScreen.prototype.checkHideBlur = function (id) {
            this._current = id;
            var dic = this._dic;
            var layers = dic[id];
            if (layers && layers.length) {
                this.hideBlur();
            }
        };
        BlurScreen.prototype.drawBlur = function (e) {
            if (e) {
                jy.dispatch(-1998 /* ReLayout */);
            }
            var tex = this._tex;
            var bmp = this._bmp;
            var stage = this._stage;
            var layers = this._dic[this._current];
            if (layers) {
                var con = this._con;
                var len = layers.length;
                for (var i = 0; i < len; i++) {
                    var layer = layers[i];
                    con.addChild(layer);
                }
                tex.drawToTexture(con);
                con.removeChildren();
                bmp.texture = tex;
                bmp.refreshBMD();
                bmp.filters = jy.FilterUtils.blur;
                stage.addChildAt(bmp, 0);
            }
        };
        BlurScreen.prototype.hideBlur = function () {
            this._stage.off("resize" /* RESIZE */, this.drawBlur, this);
            jy.removeDisplay(this._bmp);
            this._tex.$renderBuffer.resize(0, 0);
            var layers = this._dic[this._current];
            if (layers) {
                var len = layers.length;
                var engine = this._engine;
                for (var i = 0; i < len; i++) {
                    var layer = layers[i];
                    engine.awakeLayer(layer.id);
                }
            }
        };
        return BlurScreen;
    }());
    jy.BlurScreen = BlurScreen;
    __reflect(BlurScreen.prototype, "jy.BlurScreen");
})(jy || (jy = {}));
//# sourceMappingURL=BlurScreen.js.map