var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var jy;
(function (jy) {
    /**
     * 模块面板
     * @author 3tion
     *
     */
    var Panel = (function (_super) {
        __extends(Panel, _super);
        function Panel() {
            var _this = _super.call(this) || this;
            _this._readyState = 0 /* UNREQUEST */;
            _this.init();
            return _this;
        }
        Panel.prototype.stageResize = function () {
        };
        Object.defineProperty(Panel.prototype, "isReady", {
            get: function () {
                return this._readyState == 2 /* COMPLETE */;
            },
            enumerable: true,
            configurable: true
        });
        Panel.prototype.init = function () {
            //this._key=xxxx
            //this._className=xxxx
            //this._otherDepends=[other...];
        };
        Panel.prototype.bind = function (key, className) {
            var otherDepends = [];
            for (var _i = 2; _i < arguments.length; _i++) {
                otherDepends[_i - 2] = arguments[_i];
            }
            this.suiLib = key;
            this.suiClass = className;
            this._otherDepends = otherDepends;
        };
        Panel.prototype.startSync = function () {
            if (this._readyState <= 0 /* UNREQUEST */) {
                if (this._otherDepends) {
                    this._depends = this._otherDepends.concat();
                }
                else {
                    this._depends = [];
                }
                this._depends.push(this.suiLib);
                this._readyState = 1 /* REQUESTING */;
                this.loadNext();
            }
        };
        Panel.prototype.loadNext = function () {
            if (this._depends.length) {
                var key = this._depends.pop();
                var suiManager = jy.singleton(jy.SuiResManager);
                suiManager.loadData(key, this);
            }
            else {
                this.skinDataComplete();
            }
        };
        Panel.prototype.suiDataComplete = function (suiData) {
            if (this.preloadImage) {
                suiData.loadBmd(jy.CallbackInfo.get(this.loadNext, this));
            }
            else {
                this.loadNext();
            }
        };
        Panel.prototype.suiDataFailed = function (_) {
            this._readyState = -1 /* FAILED */;
            this.readyNow(true);
        };
        Panel.prototype.readyNow = function (failed) {
            var asyncHelper = this._asyncHelper;
            if (asyncHelper) {
                asyncHelper.readyNow();
                if (failed) {
                    asyncHelper.isReady = false;
                }
            }
        };
        /**
         * 绑定皮肤
         */
        Panel.prototype.bindComponent = function () {
            jy.singleton(jy.SuiResManager).createComponents(this.suiLib, this.suiClass, this);
        };
        /**
         * 皮肤数据加载完成
         */
        Panel.prototype.skinDataComplete = function () {
            this.bindComponent();
            var bg = this.bg;
            if (!bg && this.numChildren) {
                bg = this.getChildAt(0);
            }
            if (bg) {
                bg.touchEnabled = true;
            }
            this._readyState = 2 /* COMPLETE */;
            this.readyNow();
        };
        Panel.prototype.modalToStage = function () {
            if (this._isModal) {
                this.addModal();
            }
        };
        Object.defineProperty(Panel.prototype, "isModal", {
            get: function () {
                return this._isModal;
            },
            set: function (value) {
                if (this._isModal != value) {
                    this._isModal = value;
                    if (value) {
                        this.setModalTouchClose(true); //默认为true
                        if (this.stage) {
                            this.addModal();
                        }
                        else {
                            this.once("addedToStage" /* ADDED_TO_STAGE */, this.modalToStage, this);
                        }
                    }
                    else {
                        this.removeModal();
                        this.off("addedToStage" /* ADDED_TO_STAGE */, this.modalToStage, this);
                    }
                }
            },
            enumerable: true,
            configurable: true
        });
        /**
         * 设置模式窗口的灰色区域是否可以点击关闭面板
         *
         * @param {boolean} value
         */
        Panel.prototype.setModalTouchClose = function (value) {
            if (this._mTouchClose != value) {
                this._mTouchClose = value;
                var m = this.getModal();
                if (value) {
                    m.on("touchTap" /* TOUCH_TAP */, this.hide, this);
                }
                else {
                    m.off("touchTap" /* TOUCH_TAP */, this.hide, this);
                }
            }
        };
        Panel.prototype.getModal = function () {
            var m = this.modal;
            if (!m) {
                this.modal = m = new egret.Bitmap();
                m.texture = jy.ColorUtil.getTexture();
                m.touchEnabled = true;
            }
            return m;
        };
        /**
         * 加模态
         *
         * @public
         */
        Panel.prototype.addModal = function (width, height) {
            var m = this.getModal();
            var rect = this.suiRawRect;
            var stage = egret.sys.$TempStage;
            stage.on("resize" /* RESIZE */, this.onModalResize, this);
            width = width || stage.stageWidth;
            height = height || stage.stageHeight;
            var _a = this, scaleX = _a.scaleX, scaleY = _a.scaleY;
            var sx = rect.x - (width - rect.width >> 1);
            var sy = rect.y - (height - rect.height >> 1);
            m.x = sx / scaleX;
            m.y = sy / scaleY;
            m.width = width / scaleX;
            m.height = height / scaleY;
            this.addChildAt(m, 0);
            this.x = -sx;
            this.y = -sy;
            if (this._mTouchClose) {
                m.on("touchTap" /* TOUCH_TAP */, this.hide, this);
            }
        };
        Panel.prototype.onModalResize = function () {
            this.addModal();
        };
        /**
         * 移除模态
         *
         * @public
         */
        Panel.prototype.removeModal = function () {
            if (this.modal) {
                this.modal.off("touchTap" /* TOUCH_TAP */, this.hide, this);
                jy.removeDisplay(this.modal);
            }
            egret.sys.$TempStage.off("resize" /* RESIZE */, this.onModalResize, this);
        };
        /**
         * 关闭
         *
         * @protected
         */
        Panel.prototype.hide = function () {
            jy.toggle(this.moduleID, -1 /* HIDE */);
        };
        Object.defineProperty(Panel.prototype, "isShow", {
            get: function () {
                return this.stage != undefined && this.visible == true;
            },
            enumerable: true,
            configurable: true
        });
        Panel.prototype.show = function () {
            jy.toggle(this.moduleID, 1 /* SHOW */);
        };
        return Panel;
    }(egret.Sprite));
    jy.Panel = Panel;
    __reflect(Panel.prototype, "jy.Panel", ["jy.SuiDataCallback", "jy.IAsyncPanel", "jy.IAsync", "jy.IModulePanel", "egret.DisplayObject"]);
    jy.expand(Panel, jy.FHost, "addReadyExecute");
    jy.addEnable(Panel);
})(jy || (jy = {}));
//# sourceMappingURL=Panel.js.map