var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var jy;
(function (jy) {
    /**
     * @author gushuai
     * (description)
     *
     * @export
     * @class Menu
     * @extends {egret.Sprite}
     */
    var Menu = (function (_super) {
        __extends(Menu, _super);
        function Menu(style, maxRendercount) {
            var _this = _super.call(this) || this;
            _this.style = style;
            _this.uiManager = jy.singleton(jy.SuiResManager);
            _this.maxRenderCount = maxRendercount;
            _this.bindComponent();
            return _this;
        }
        /**
         * (description)
         *
         * @static
         * @ param {egret.DisplayObject} target (Menu所在的父容器)
         * @ param {Menu} menu (menu实例)
         * @ param {Function} callBack (menu的displayMenuDatas具体实现函数（回调参数，第1位是绑定的target 第2位是Menu）)
         */
        Menu.bind = function (target, menu, menuinit) {
            var dic = Menu.dic;
            if (!dic) {
                Menu.dic = dic = new Map();
            }
            if (!dic.has(target)) {
                dic.set(target, menu);
            }
            menu.menuinitFunc = menuinit;
            target.on(-1000 /* CHOOSE_STATE_CHANGE */, Menu.onShowOrHideMenu, this);
        };
        Menu.unBind = function (target) {
            var dic = Menu.dic;
            if (!dic)
                return;
            if (dic.has(target)) {
                var dis = dic.get(target);
                dis.menuinitFunc = undefined;
                jy.removeDisplay(dis);
                dic.delete(target);
            }
            target.off(-1000 /* CHOOSE_STATE_CHANGE */, Menu.onShowOrHideMenu, this);
        };
        Menu.onShowOrHideMenu = function (e) {
            var target = e.target;
            var b = target.selected;
            var dis = Menu.dic.get(target);
            var v = target.view;
            if (b) {
                if (v instanceof egret.DisplayObjectContainer) {
                    v.addChild(dis);
                    var init = dis.menuinitFunc;
                    if (init) {
                        init.call(target, target, dis);
                    }
                }
                this.currentShow = target;
            }
            else {
                jy.removeDisplay(dis);
                this.currentShow = undefined;
            }
            target.dispatch(-1999 /* Resize */);
        };
        Menu.prototype.bindComponent = function () {
            var manager = this.uiManager;
            var uri = this.style.uikey;
            var rec = this.style.possize;
            var rendercls = this.style.renderClass;
            var bguri = this.style.scalebg;
            var bg = manager.createDisplayObject(uri, bguri);
            this.addChild(bg);
            bg.width = rec.width;
            bg.height = rec.height;
            this.renders = [];
            for (var i = 0; i < this.maxRenderCount; i++) {
                var render = new rendercls();
                this.renders[i] = render;
                this.addChild(render.view);
            }
        };
        /**
         * 显示菜单操作项
         */
        Menu.prototype.displayMenuDatas = function (vos) {
            var len = vos.length;
            var blen = this.renders.length;
            var style = this.style;
            var tmp = [];
            for (var i = 0; i < len; i++) {
                var render = this.renders[i];
                render.data = vos[i];
                this.addChild(render.view);
                tmp[i] = render;
            }
            if (len < blen) {
                for (var i = len; i < blen; i++) {
                    jy.removeDisplay(this.renders[i].view);
                }
            }
            var rec = style.possize;
            var gap;
            var tmpSize = tmp[0].getSize();
            if (!style.align) {
                gap = (rec.width - rec.x * 2 - len * tmpSize.width) / (len - 1);
                for (var i = 0; i < len; i++) {
                    var render = tmp[i];
                    tmpSize = render.getSize();
                    var v = render.view;
                    v.x = ~~(rec.x + (gap + tmpSize.width) * i);
                    v.y = ~~rec.y;
                }
            }
            else {
                gap = (rec.height - rec.y * 2 - len * tmpSize.height) / (len - 1);
                for (var i = 0; i < len; i++) {
                    var render = tmp[i];
                    tmpSize = render.getSize();
                    var v = render.view;
                    v.x = ~~rec.x;
                    v.y = ~~(rec.y + (gap + tmpSize.height) * i);
                }
            }
        };
        return Menu;
    }(egret.Sprite));
    jy.Menu = Menu;
    __reflect(Menu.prototype, "jy.Menu");
})(jy || (jy = {}));
//# sourceMappingURL=Menu.js.map