var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var jy;
(function (jy) {
    /**
     * 按钮形式的菜单
     * @author gushuai
     * (description)
     *
     * @export
     * @class SkillItemMenuRender
     * @extends {MenuBaseRender<MenuBaseVO>}
     */
    var ButtonMenuRender = (function (_super) {
        __extends(ButtonMenuRender, _super);
        function ButtonMenuRender(key, className) {
            if (key === void 0) { key = "lib"; }
            if (className === void 0) { className = "ui.btn.MenuBtn"; }
            var _this = _super.call(this) || this;
            var btn = jy.singleton(jy.SuiResManager).createDisplayObject(key, className);
            _this.skin = btn;
            _this.btn = btn;
            return _this;
        }
        ButtonMenuRender.prototype.$setData = function (val) {
            _super.prototype.$setData.call(this, val);
            this.btn.label = val.label;
        };
        return ButtonMenuRender;
    }(jy.MenuBaseRender));
    jy.ButtonMenuRender = ButtonMenuRender;
    __reflect(ButtonMenuRender.prototype, "jy.ButtonMenuRender");
})(jy || (jy = {}));
//# sourceMappingURL=ButtonMenuRender.js.map