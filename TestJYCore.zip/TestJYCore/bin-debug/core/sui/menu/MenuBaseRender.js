var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var jy;
(function (jy) {
    /**
     * @author gushuai
     * (description)
     *
     * @export
     * @class MenuBaseRender
     * @extends {egret.Sprite}
     * @template T
     */
    var MenuBaseRender = (function () {
        function MenuBaseRender() {
        }
        MenuBaseRender.prototype.itemClick = function () {
            var data = this._data;
            if (data) {
                var callBack = data.callBack;
                if (callBack) {
                    callBack.call(jy.Menu.currentShow, data);
                }
            }
        };
        MenuBaseRender.prototype.getSize = function () {
            return this._size;
        };
        Object.defineProperty(MenuBaseRender.prototype, "data", {
            get: function () {
                return this._data;
            },
            set: function (value) {
                this.$setData(value);
            },
            enumerable: true,
            configurable: true
        });
        /**
         * 只允许子类重写
         * @protected
         */
        MenuBaseRender.prototype.$setData = function (val) {
            this._data = val;
        };
        Object.defineProperty(MenuBaseRender.prototype, "skin", {
            get: function () {
                return this._skin;
            },
            set: function (value) {
                if (value != this._skin) {
                    this.$setSkin(value);
                }
            },
            enumerable: true,
            configurable: true
        });
        MenuBaseRender.prototype.$setSkin = function (value) {
            this._skin = value;
            this._size = value.getBounds();
            value.on("touchTap" /* TOUCH_TAP */, this.itemClick, this);
            this.bindComponent();
        };
        MenuBaseRender.prototype.bindComponent = function () {
        };
        Object.defineProperty(MenuBaseRender.prototype, "view", {
            get: function () {
                return this._skin;
            },
            enumerable: true,
            configurable: true
        });
        return MenuBaseRender;
    }());
    jy.MenuBaseRender = MenuBaseRender;
    __reflect(MenuBaseRender.prototype, "jy.MenuBaseRender");
})(jy || (jy = {}));
//# sourceMappingURL=MenuBaseRender.js.map