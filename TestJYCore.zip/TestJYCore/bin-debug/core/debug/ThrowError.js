var jy;
(function (jy) {
    /**
     * 错误前缀
     */
    jy.errorPrefix = "";
    if (false) {
        /**
         * 内存中存储的错误数据信息
         *
         */
        var errorMsg = [];
        /**
         * 在内存中存储报错数据
         * @param msg
         * @param atWho
         *
         */
        var pushMsg = function (msg) {
            if (errorMsg.length > jy.ThrowError.MaxCount) {
                errorMsg.shift();
            }
            var msg = getMsg(msg);
            errorMsg.push(msg);
            return msg;
        };
    }
    if (true) {
        jy.Log = function () {
            var msg = "%c";
            for (var i = 0; i < arguments.length; i++) {
                msg += arguments[i];
            }
            console.log(msg, "color:red");
        };
    }
    /**
    * 在内存中存储报错数据
    * @param msg
    * @private
    */
    function getMsg(msg) {
        return new Date().format("[yyyy-MM-dd HH:mm:ss]", true) + "[info:]" + msg;
    }
    /**
     * 抛错
     * @param {string | Error}  msg 描述
     **/
    jy.ThrowError = function (msg, err, alert) {
        if (true && alert) {
            window.alert(msg);
        }
        msg = jy.errorPrefix + msg;
        msg += "%c";
        if (err) {
            msg += "\nError:\n[name]:" + err.name + ",[message]:" + err.message;
        }
        else {
            err = new Error();
        }
        msg += "\n[stack]:\n" + err.stack;
        if (true) {
            msg = getMsg(msg);
        }
        else if (false) {
            msg = pushMsg(msg);
        }
        console.log(msg, "color:red");
    };
    if (false) {
        jy.ThrowError.MaxCount = 50;
        jy.ThrowError.errorMsg = errorMsg;
    }
})(jy || (jy = {}));
//# sourceMappingURL=ThrowError.js.map