var jy;
(function (jy) {
    /**
     * 客户端检测
     * @author 3tion
     *
     */
    jy.ClientCheck = {
        /**
         * 是否做客户端检查
         */
        isClientCheck: true
    };
})(jy || (jy = {}));
//# sourceMappingURL=ClientCheck.js.map