var jy;
(function (jy) {
    /**
     * 将Mediator转换为IStateSwitcher
     *
     * @export
     * @param {Mediator} mediator
     * @returns {(Mediator & IStateSwitcher & AwakeCheck)}
     */
    function transformToStateMediator(mediator, awakeBy, sleepBy) {
        var stateMed = mediator;
        if (stateMed.awakeBy === undefined) {
            stateMed.awakeBy = awakeBy || function (id) {
                if (typeof stateMed.awakeCheck === "function") {
                    if (!stateMed.awakeCheck()) {
                        return;
                    }
                }
                var view = this._view;
                if (view instanceof jy.Panel) {
                    view.show();
                }
            };
        }
        if (stateMed.sleepBy === undefined) {
            stateMed.sleepBy = sleepBy || function (id) {
                var view = this._view;
                if (view instanceof jy.Panel) {
                    view.hide();
                }
            };
        }
        return stateMed;
    }
    jy.transformToStateMediator = transformToStateMediator;
})(jy || (jy = {}));
//# sourceMappingURL=StateMediatorHelper.js.map