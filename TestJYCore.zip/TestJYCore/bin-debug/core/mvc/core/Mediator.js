var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var jy;
(function (jy) {
    /**
     * 视图控制器，持有视图<br/>
     * 持有Proxy，主要监听视图和Proxy的事件，变更面板状态<br/>
     * @author 3tion
     *
     */
    var Mediator = (function (_super) {
        __extends(Mediator, _super);
        /**
         * Creates an instance of Mediator.
         *
         * @param {string | number} moduleID 模块ID
         */
        function Mediator(moduleID) {
            var _this = _super.call(this, moduleID) || this;
            _this.init && _this.init();
            return _this;
        }
        Object.defineProperty(Mediator.prototype, "view", {
            /**
             *  获取视图
             */
            get: function () {
                return this.$view;
            },
            set: function (value) {
                var old = this.$view;
                if (old != value) {
                    this.removeSkinListener(old);
                    this.$view = value;
                    this.addSkinListener(value);
                    value.moduleID = this._name;
                    if (jy.isIAsync(value)) {
                        value.addReadyExecute(this.viewComplete, this);
                    }
                    else {
                        this.viewComplete();
                    }
                }
            },
            enumerable: true,
            configurable: true
        });
        /**
         * 开始尝试同步
         */
        Mediator.prototype.startSync = function () {
            if (jy.isIAsync(this.$view)) {
                var async = this.$view;
                if (async.isReady) {
                    this.viewComplete();
                }
                else {
                    async.addReadyExecute(this.viewComplete, this);
                    async.startSync();
                }
            }
        };
        /**
         *
         * 视图加载完毕
         * @protected
         */
        Mediator.prototype.viewComplete = function () {
            var viewReady = true;
            var $view = this.$view;
            if (jy.isIAsync($view)) {
                viewReady = $view.isReady;
            }
            this.viewReady = viewReady;
            if (!this.viewCheck(viewReady)) {
                return;
            }
            if (this._dependerHelper) {
                this._dependerHelper.check();
            }
            else {
                this.dependerReadyCheck();
            }
        };
        Mediator.prototype.viewCheck = function (viewReady) {
            return viewReady;
        };
        /**
         *
         * 依赖项完毕后检查
         * @protected
         * @returns
         */
        Mediator.prototype.dependerReadyCheck = function () {
            if (!this.viewReady) {
                return;
            }
            if (!this._ready) {
                this._ready = true;
                this.afterAllReady();
                if (this._asyncHelper) {
                    this._asyncHelper.readyNow();
                }
            }
        };
        Mediator.prototype.hide = function () {
            jy.toggle(this._name, -1 /* HIDE */);
        };
        return Mediator;
    }(jy.ViewController));
    jy.Mediator = Mediator;
    __reflect(Mediator.prototype, "jy.Mediator");
})(jy || (jy = {}));
//# sourceMappingURL=Mediator.js.map