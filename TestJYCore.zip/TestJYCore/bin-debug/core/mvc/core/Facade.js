var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var jy;
(function (jy) {
    /**
     * 代码构建类，用于注册代码
     * @author 3tion
     */
    var Facade = (function (_super) {
        __extends(Facade, _super);
        function Facade() {
            var _this = _super.call(this) || this;
            _this._mediators = {};
            _this._scripts = {};
            _this._proxys = {};
            _this._indecting = [];
            return _this;
        }
        /**
         *
         * 获取内部注册的Proxy或者Mediator用于全局注册的名字
         * @static
         * @param {{ new (): any }} inlineRef inlineRef 内部注册的Proxy或者Mediator
         * @param {string} [className]  类名
         * @returns string  内部注册的Proxy或者Mediator用于全局注册的名字
         *
         * @memberOf Facade
         */
        Facade.getNameOfInline = function (inlineRef, className) {
            className = className || egret.getQualifiedClassName(inlineRef);
            var name;
            if ("NAME" in inlineRef) {
                name = inlineRef["NAME"];
            }
            else {
                name = className.substr(className.lastIndexOf(".") + 1);
            }
            return name;
        };
        /**
         * 绑定模块管理器
         */
        Facade.prototype.bindModuleManager = function (mm) {
            mm.init();
            this._mm = mm;
        };
        Object.defineProperty(Facade.prototype, "mm", {
            /**
             * 模块管理器
             *
             * @readonly
             *
             * @memberOf Facade
             */
            get: function () {
                return this._mm;
            },
            enumerable: true,
            configurable: true
        });
        Facade.prototype._removeHost = function (name, dict) {
            var dele = dict[name];
            var host;
            if (dele) {
                delete dict[name];
                host = dele.host;
                if (host) {
                    host.onRemove();
                }
            }
            return host;
        };
        /**
         * 移除面板控制器
         */
        Facade.prototype.removeMediator = function (mediatorName) {
            return this._removeHost(mediatorName, this._mediators);
        };
        /**
         * 移除模块
         * 如果模块被其他模块依赖，此方法并不能清楚依赖引用
         */
        Facade.prototype.removeProxy = function (proxyName) {
            var proxy = this._proxys[proxyName];
            if (proxy.host._$isDep) {
                true && jy.ThrowError("\u6A21\u5757[" + proxyName + "]\u88AB\u4F9D\u8D56\uFF0C\u4E0D\u5141\u8BB8\u79FB\u9664", null, true);
                return;
            }
            return this._removeHost(proxyName, this._proxys);
        };
        /**
         *
         * 注册内部模块
         * @param {{ new (): Proxy }} ref Proxy创建器
         * @param {string} [proxyName] 模块名称
         * @param {boolean} [async=false] 是否异步初始化，默认直接初始化
         */
        Facade.prototype.registerInlineProxy = function (ref, proxyName, async) {
            if (!ref) {
                if (true) {
                    jy.ThrowError("registerInlineProxy时,没有ref");
                }
                return;
            }
            var className = egret.getQualifiedClassName(ref);
            if (!proxyName) {
                proxyName = Facade.getNameOfInline(ref, className);
            }
            this.registerProxyConfig(className, proxyName);
            if (!async) {
                var dele = this._proxys[proxyName];
                var host = new ref();
                dele.host = host;
                jy.facade.inject(host);
                host.onRegister();
            }
        };
        /**
         *
         * 注册内部Mediator模块
         * @param {{ new (): Mediator }} ref Mediator创建器
         * @param {string} [mediatorName]   注册的模块名字
         */
        Facade.prototype.registerInlineMediator = function (ref, mediatorName) {
            if (!ref) {
                if (true) {
                    jy.ThrowError("registerInlineMediator\u65F6,\u6CA1\u6709ref");
                }
                return;
            }
            var className = egret.getQualifiedClassName(ref);
            if (!mediatorName) {
                mediatorName = Facade.getNameOfInline(ref, className);
            }
            this.registerMediatorConfig(className, mediatorName);
        };
        /**
         * 注册Proxy的配置
         * @param className     类名字，完整名字
         * @param name     模块名称
         * @param scriptid      要加载的脚本ID，用于加载脚本代码，空的id表示是主脚本
         */
        Facade.prototype.registerProxyConfig = function (className, proxyName, url, scriptid) {
            var dele;
            if (true) {
                dele = this._proxys[proxyName];
                if (dele) {
                    jy.ThrowError("模块定义重复:" + name);
                }
            }
            dele = {};
            dele.scriptid = scriptid;
            dele.className = className;
            dele.name = proxyName;
            dele.url = url;
            this._proxys[proxyName] = dele;
        };
        /**
         * 注册模块的配置
         * @param className
         * @param name
         * @param scriptid      要加载的脚本ID，用于加载脚本代码
         */
        Facade.prototype.registerMediatorConfig = function (className, moduleID, url, scriptid) {
            var dele;
            if (true) {
                dele = this._mediators[moduleID];
                if (dele) {
                    jy.ThrowError("模块定义重复:" + name);
                }
            }
            dele = {};
            dele.scriptid = scriptid;
            dele.className = className;
            dele.name = moduleID;
            dele.url = url;
            this._mediators[moduleID] = dele;
        };
        Facade.prototype.getOrCreateScript = function (dele) {
            var scriptid = dele.scriptid;
            var script = this._scripts[scriptid];
            if (!script) {
                script = new jy.ModuleScript;
                script.id = scriptid;
                script.url = dele.url;
                this._scripts[scriptid] = script;
            }
            return script;
        };
        /**
         * 获取Proxy
         *
         * @param {Key} proxyName proxy的名字
         * @param {{ (proxy: Proxy, args?: any[]) }} callback 回调函数
         * @param {*} thisObj 回调函数的this对象
         * @param args 回调函数的参数列表
         */
        Facade.prototype.getProxy = function (proxyName, callback, thisObj) {
            var args = [];
            for (var _i = 3; _i < arguments.length; _i++) {
                args[_i - 3] = arguments[_i];
            }
            var dele = this._proxys[proxyName];
            if (!dele) {
                if (true) {
                    jy.ThrowError("没有注册proxy的关系");
                }
                return;
            }
            var bin = {};
            bin.dele = dele;
            bin.callback = callback;
            bin.thisObj = thisObj;
            bin.args = args;
            return this._solveScriptCallback(bin);
        };
        /**
         * 以同步方式获取proxy，不会验证proxy是否加载完毕
         * 有可能无法取到proxy
         *
         * @param {Key} proxyName
         * @returns
         *
         * @memberOf Facade
         */
        Facade.prototype.getProxySync = function (proxyName) {
            var dele = this._proxys[proxyName];
            if (dele) {
                return dele.host;
            }
        };
        /**
         * 获取Mediator
         *
         * @param {Key} moduleID 模块ID
         * @param {{ (proxy: Proxy, args?: any[]) }} callback 回调函数
         * @param {*} thisObj 回调函数的this对象
         * @param args 回调函数的参数列表
         */
        Facade.prototype.getMediator = function (moduleID, callback, thisObj) {
            var args = [];
            for (var _i = 3; _i < arguments.length; _i++) {
                args[_i - 3] = arguments[_i];
            }
            var dele = this._mediators[moduleID];
            if (!dele) {
                if (true) {
                    jy.ThrowError("没有注册Mediator的关系");
                }
                return;
            }
            var bin = {};
            bin.dele = dele;
            bin.callback = callback;
            bin.thisObj = thisObj;
            bin.args = args;
            return this._solveScriptCallback(bin);
        };
        /**
         * 以同步方式获取Mediator，不会验证Mediator是否加载完毕
         * 有可能无法取到Mediator
         *
         * @param {Key} moduleID
         * @returns
         *
         * @memberOf Facade
         */
        Facade.prototype.getMediatorSync = function (moduleID) {
            var dele = this._mediators[moduleID];
            if (dele) {
                return dele.host;
            }
        };
        Facade.prototype._solveScriptCallback = function (bin) {
            if (bin.dele.scriptid) {
                var script = this.getOrCreateScript(bin.dele);
                if (script.state != 2 /* COMPLETE */) {
                    script.callbacks.push(jy.CallbackInfo.get(this._getHost, this, bin));
                    script.load();
                    return;
                }
            }
            //直接回调
            return this._getHost(bin);
        };
        Facade.prototype._getHost = function (bin) {
            var dele = bin.dele;
            var host = dele.host;
            if (!host) {
                var ref = egret.getDefinitionByName(dele.className);
                dele.host = host = new ref();
                jy.facade.inject(host);
                host.onRegister();
            }
            var callback = bin.callback;
            if (host.isReady) {
                callback && callback.call.apply(callback, [bin.thisObj, host].concat(bin.args));
            }
            else {
                callback && host.addReadyExecute.apply(host, [callback, bin.thisObj, host].concat(bin.args));
                host.startSync();
            }
            return host;
        };
        /**
         *
         * 打开/关闭指定模块
         * @param {(Key)} moduleID      模块id
         * @param {ToggleState} [toggleState]      0 自动切换(默认)<br/>  1 打开模块<br/> -1 关闭模块<br/>
         * @param {boolean} [showTip=true]          是否显示Tip
         * @param {ModuleParam} [param] 模块参数
         *
         * @memberOf Facade
         */
        Facade.prototype.toggle = function (moduleID, toggleState, showTip, param) {
            if (showTip === void 0) { showTip = true; }
            if (this._mm) {
                this._mm.toggle(moduleID, toggleState, showTip, param);
            }
        };
        /**
         *
         * 执行某个模块的方法
         * @param {string} moduleID     模块id
         * @param {boolean} showTip     是否显示Tip，如果无法执行，是否弹出提示
         * @param {string} handlerName  执行的函数名
         * @param {boolean} [show]      执行时，是否将模块显示到舞台
         * @param {any[]} args            函数的参数列表
         * @returns
         */
        Facade.prototype.executeMediator = function (moduleID, showTip, handlerName, show) {
            var args = [];
            for (var _i = 4; _i < arguments.length; _i++) {
                args[_i - 4] = arguments[_i];
            }
            if (this._mm && this._mm.isModuleOpened(moduleID, showTip)) {
                var hander = show ? this._executeAndShowMediator : this._executeMediator;
                return this.getMediator.apply(this, [moduleID, hander, this, handlerName].concat(args));
            }
        };
        /**
         * 不做验证，直接执行mediator的方法
         * 此方法只允许ModuleHandler使用
         * @private
         * @param name          模块id
         * @param showTip       如果无法执行，是否弹出提示
         * @param handlerName   执行的函数名
         * @param args
         */
        Facade.prototype.$executeMediator = function (moduleID, handlerName) {
            var args = [];
            for (var _i = 2; _i < arguments.length; _i++) {
                args[_i - 2] = arguments[_i];
            }
            return this.getMediator(moduleID, this._executeMediator, this, args);
        };
        Facade.prototype._executeMediator = function (mediator, handlerName) {
            var args = [];
            for (var _i = 2; _i < arguments.length; _i++) {
                args[_i - 2] = arguments[_i];
            }
            if (typeof mediator[handlerName] === "function") {
                mediator[handlerName].apply(mediator, args);
            }
            else if (true) {
                jy.ThrowError("无法在Mediator：" + mediator.name + "中找到方法[" + handlerName + "]");
            }
        };
        Facade.prototype._executeAndShowMediator = function (mediator, handlerName) {
            var args = [];
            for (var _i = 2; _i < arguments.length; _i++) {
                args[_i - 2] = arguments[_i];
            }
            this.toggle(mediator.name, 1 /* SHOW */, false); //showTip为 false是不用再次提示，executeMediator已经执行过模块是否开启的检查
            this._executeMediator.apply(//showTip为 false是不用再次提示，executeMediator已经执行过模块是否开启的检查
            this, [mediator, handlerName].concat(args));
        };
        /**
         * 执行Proxy的方法
         * @param name     proxy名字
         * @param handlerName   函数名字
         * @param args          参数列表
         */
        Facade.prototype.executeProxy = function (proxyName, handlerName) {
            var args = [];
            for (var _i = 2; _i < arguments.length; _i++) {
                args[_i - 2] = arguments[_i];
            }
            return this.getProxy.apply(this, [proxyName, this._executeProxy, this, handlerName].concat(args));
        };
        Facade.prototype._executeProxy = function (proxy, handlerName) {
            var args = [];
            for (var _i = 2; _i < arguments.length; _i++) {
                args[_i - 2] = arguments[_i];
            }
            if (typeof proxy[handlerName] === "function") {
                proxy[handlerName].apply(proxy, args);
            }
            else if (true) {
                jy.ThrowError("无法在Proxy：" + proxy.name + "中找到方法[" + handlerName + "]");
            }
        };
        /**
         * 注入数据
         */
        Facade.prototype.inject = function (obj) {
            //锁定对象，防止循环注入
            var _indecting = this._indecting;
            if (!~_indecting.indexOf(obj)) {
                _indecting.push(obj);
                this.doInject(obj);
                var idx = _indecting.indexOf(obj);
                _indecting.splice(idx, 1);
            }
        };
        /**
         * 用于子项目扩展
         * @param obj
         */
        Facade.prototype.doInject = function (obj) {
            //to be override
        };
        /**
         * 模块脚本的加载路径
         */
        Facade.Script = "modules/{0}.js";
        return Facade;
    }(egret.EventDispatcher));
    jy.Facade = Facade;
    __reflect(Facade.prototype, "jy.Facade");
    jy.facade = new Facade();
    function proxyCall() {
        return jy.facade.getProxy.apply(jy.facade, arguments);
    }
    jy.proxyCall = proxyCall;
    function proxyExec() {
        return jy.facade.executeProxy.apply(jy.facade, arguments);
    }
    jy.proxyExec = proxyExec;
    function mediatorCall() {
        return jy.facade.getMediator.apply(jy.facade, arguments);
    }
    jy.mediatorCall = mediatorCall;
    function mediatorExec() {
        return jy.facade.executeMediator.apply(jy.facade, arguments);
    }
    jy.mediatorExec = mediatorExec;
    /**
     * 全局抛事件
     *
     * @export
     * @param {Key} type     事件类型
     * @param {*} [data]        数据
     */
    function dispatch(type, data) {
        jy.facade.dispatch(type, data);
    }
    jy.dispatch = dispatch;
    /**
     *
     * 打开/关闭指定模块
     * @param {(Key)} moduleID      模块id
     * @param {ToggleState} [toggleState]      0 自动切换(默认)<br/>  1 打开模块<br/> -1 关闭模块<br/>
     * @param {boolean} [showTip=true]          是否显示Tip
     * @param {ModuleParam} [param] 模块参数
     *
     * @memberOf Facade
     */
    function toggle(moduleID, toggleState, showTip, param) {
        if (showTip === void 0) { showTip = true; }
        jy.facade.toggle(moduleID, toggleState, showTip, param);
    }
    jy.toggle = toggle;
    /**
     *
     * 添加事件监听
     * @export
     * @param {(Key)} type
     * @param {Function} listener
     * @param {*} thisObj
     * @param {number} [priority]
     */
    function on(type, listener, thisObj, priority) {
        jy.facade.on(type, listener, thisObj, false, priority);
    }
    jy.on = on;
    /**
     * 单次监听事件
     *
     * @export
     * @template T
     * @param {Key} type
     * @param {{ (this: T, e?: egret.Event) }} listener
     * @param {T} [thisObj]
     * @param {number} [priority]
     */
    function once(type, listener, thisObj, priority) {
        jy.facade.once(type, listener, thisObj, false, priority);
    }
    jy.once = once;
    /**
     *
     * 移除事件监听
     * @static
     * @param {Key} type
     * @param {Function} listener
     * @param {*} [thisObject]
     */
    function off(type, listener, thisObject) {
        jy.facade.off(type, listener, thisObject, false);
    }
    jy.off = off;
    /**
     * 检查是否有全局监听
     *
     * @export
     * @param {Key} type
     * @returns
     */
    function hasListen(type) {
        return jy.facade.hasListen(type);
    }
    jy.hasListen = hasListen;
})(jy || (jy = {}));
//# sourceMappingURL=Facade.js.map