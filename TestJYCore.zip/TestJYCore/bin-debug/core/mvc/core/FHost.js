var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var jy;
(function (jy) {
    /**
     * Mediator和Proxy的基类
     * @author 3tion
     *
     */
    var FHost = (function () {
        function FHost(name) {
            this._name = name;
            this.checkInject();
            if (true) {
                var classes = $gm.$;
                if (!classes) {
                    $gm.$ = classes = {};
                }
                classes[this["constructor"]["name"]] = this;
            }
        }
        Object.defineProperty(FHost.prototype, "name", {
            /**
             * 唯一标识
             */
            get: function () {
                return this._name;
            },
            enumerable: true,
            configurable: true
        });
        /**
         * 检查依赖注入的数据
         *
         * @protected
         *
         * @memberOf FHost
         */
        FHost.prototype.checkInject = function () {
            //此注入是对原型进行的注入，无法直接删除，也不要直接做清理
            var idp = this._injectProxys;
            if (idp) {
                var proxyName = void 0;
                //检查Proxy
                for (var key in idp) {
                    var ref = idp[key].ref;
                    if (typeof ref === "function") {
                        proxyName = jy.Facade.getNameOfInline(ref);
                    }
                    else {
                        proxyName = ref;
                    }
                    var proxy = jy.proxyCall(proxyName);
                    this[key] = proxy;
                    proxy._$isDep = true;
                    this.addDepend(proxy);
                }
            }
        };
        FHost.prototype.addReadyExecute = function (handle, thisObj) {
            var args = [];
            for (var _i = 2; _i < arguments.length; _i++) {
                args[_i - 2] = arguments[_i];
            }
            var _asyncHelper = this._asyncHelper;
            if (!_asyncHelper) {
                this._asyncHelper = _asyncHelper = new jy.AsyncHelper();
                _asyncHelper.isReady = this.isReady;
            }
            _asyncHelper.addReadyExecute.apply(_asyncHelper, [handle, thisObj].concat(args));
        };
        Object.defineProperty(FHost.prototype, "isReady", {
            get: function () {
                return false;
            },
            enumerable: true,
            configurable: true
        });
        FHost.prototype.startSync = function () {
        };
        /**
         * 添加依赖项
         */
        FHost.prototype.addDepend = function (async) {
            if (!this._dependerHelper) {
                this._dependerHelper = new jy.DependerHelper(this, this.dependerReadyCheck);
            }
            this._dependerHelper.addDepend(async);
        };
        /**
         * 依赖项，加载完成后的检查
         */
        FHost.prototype.dependerReadyCheck = function () {
        };
        /**
         * 模块在Facade注册时执行
         */
        FHost.prototype.onRegister = function () {
        };
        /**
         * 模块从Facade注销时
         */
        FHost.prototype.onRemove = function () {
        };
        /**
         * 全部加载好以后要处理的事情<br/>
         * 包括依赖项加载完毕
         */
        FHost.prototype.afterAllReady = function () {
            // to be override
        };
        return FHost;
    }());
    jy.FHost = FHost;
    __reflect(FHost.prototype, "jy.FHost", ["jy.IDepender", "jy.IAsync"]);
    /**
     *
     * 附加依赖的Proxy
     * @export
     * @param {({ new (): IAsync } | string)} ref 如果注册的是Class，必须是Inline方式注册的Proxy
     * @returns
     */
    function d_dependProxy(ref, isPri) {
        var pKey = "_injectProxys";
        return function (target, key) {
            var _injectProxys;
            if (target.hasOwnProperty(pKey)) {
                _injectProxys = target[pKey];
            }
            else {
                //未赋值前，先取值，可取到父级数据，避免使用  Object.getPrototypeOf(target)，ES5没此方法
                var inherit = target[pKey];
                target[pKey] = _injectProxys = {};
                if (inherit) {
                    for (var k in inherit) {
                        var bin = inherit[k];
                        if (!bin.isPri) {
                            _injectProxys[k] = bin;
                        }
                    }
                }
            }
            _injectProxys[key] = { ref: ref, isPri: isPri };
        };
    }
    jy.d_dependProxy = d_dependProxy;
})(jy || (jy = {}));
//# sourceMappingURL=FHost.js.map