var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var jy;
(function (jy) {
    /**
     * 可以调用 @d_interest 的视图
     * 可以进行关注facade中的事件
     *
     * @export
     * @class ViewController
     * @extends {FHost}
     */
    var ViewController = (function (_super) {
        __extends(ViewController, _super);
        function ViewController() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        /**
         * 用于内部增加关注
         *
         * @param {Key} eventType
         * @param {{ (e?: egret.Event): void }} handler
         * @param {boolean} [triggerOnStage]
         * @param {number} [priority]
         */
        ViewController.prototype.interest = function (eventType, handler, triggerOnStage, priority) {
            var ins = {};
            ins.handler = handler;
            ins.priority = priority || 0;
            ins.trigger = triggerOnStage;
            this._interests[eventType] = ins;
            if (triggerOnStage) {
                var _awakeCallers = this._awakeCallers;
                if (!_awakeCallers) {
                    this._awakeCallers = _awakeCallers = [];
                }
                _awakeCallers.pushOnce(handler);
            }
        };
        ViewController.prototype.removeSkinListener = function (skin) {
            if (skin) {
                skin.off("removedFromStage" /* REMOVED_FROM_STAGE */, this.stageHandler, this);
                skin.off("addedToStage" /* ADDED_TO_STAGE */, this.stageHandler, this);
            }
        };
        ViewController.prototype.addSkinListener = function (skin) {
            if (skin) {
                skin.on("removedFromStage" /* REMOVED_FROM_STAGE */, this.stageHandler, this);
                skin.on("addedToStage" /* ADDED_TO_STAGE */, this.stageHandler, this);
            }
        };
        /**
         * 绑定定时处理的回调函数
         *
         * @param {Function} callback 执行回调函数
         * @param {boolean} [trigger=true] 是否理解执行
         * @param {number} [time=Time.ONE_SECOND]
         * @param {any} [thisObj=this]
         * @param {any} args
         * @memberof ViewController
         */
        ViewController.prototype.bindTimer = function (callback, trigger, time, thisObj) {
            if (trigger === void 0) { trigger = true; }
            if (time === void 0) { time = 1000 /* ONE_SECOND */; }
            if (thisObj === void 0) { thisObj = this; }
            var args = [];
            for (var _i = 4; _i < arguments.length; _i++) {
                args[_i - 4] = arguments[_i];
            }
            var _tList = this._tList;
            if (!_tList) {
                this._tList = _tList = [];
            }
            var info = jy.CallbackInfo.addToList.apply(jy.CallbackInfo, [_tList, callback, thisObj].concat(args));
            info.time = time;
            jy.TimerUtil.add(time, info);
            if (trigger) {
                info.execute(false);
            }
        };
        /**
         * 解除定时回调函数的绑定
         * @param callback
         * @param time
         * @param thisObj
         */
        ViewController.prototype.looseTimer = function (callback, time, thisObj) {
            if (time === void 0) { time = 1000 /* ONE_SECOND */; }
            if (thisObj === void 0) { thisObj = this; }
            var list = this._tList;
            if (list) {
                var info = jy.CallbackInfo.removeFromList(list, callback, thisObj);
                if (info) {
                    jy.TimerUtil.remove(time, info);
                    info.recycle();
                }
            }
        };
        /**
         * 添加到舞台时，自动添加定时回调
         */
        ViewController.prototype.awakeTimer = function () {
            var list = this._tList;
            if (list) {
                for (var i = 0; i < list.length; i++) {
                    var cb = list[i];
                    jy.TimerUtil.add(cb.time, cb);
                }
            }
        };
        /**
         * 从舞台移除时候，自动移除定时回调
         */
        ViewController.prototype.sleepTimer = function () {
            var list = this._tList;
            if (list) {
                for (var i = 0; i < list.length; i++) {
                    var cb = list[i];
                    jy.TimerUtil.remove(cb.time, cb);
                }
            }
        };
        Object.defineProperty(ViewController.prototype, "isReady", {
            get: function () {
                return this._ready;
            },
            enumerable: true,
            configurable: true
        });
        ViewController.prototype.stageHandler = function (e) {
            var type, ins;
            var _interests = this._interests;
            this.checkInterest();
            if (e.type == "addedToStage" /* ADDED_TO_STAGE */) {
                //加入关注的事件
                for (type in _interests) {
                    ins = _interests[type];
                    jy.on(type, ins.handler, this, ins.priority);
                }
                var _awakeCallers = this._awakeCallers;
                for (var i = 0; i < _awakeCallers.length; i++) {
                    _awakeCallers[i].call(this);
                }
                //检查timer绑定
                this.awakeTimer();
                if (this.awake) {
                    this.awake();
                }
            }
            else {
                for (type in _interests) {
                    ins = _interests[type];
                    jy.off(type, ins.handler, this);
                }
                this.sleepTimer();
                if (this.sleep) {
                    this.sleep();
                }
            }
        };
        ViewController.prototype.checkInterest = function () {
            if (!this.interestChecked) {
                var _awakeCallers = this._awakeCallers;
                if (!_awakeCallers) {
                    this._awakeCallers = _awakeCallers = [];
                }
                var _interests = this._interests;
                for (var type in _interests) {
                    var ins = _interests[type];
                    if (ins.trigger) {
                        _awakeCallers.pushOnce(ins.handler);
                    }
                }
                this.interestChecked = true;
            }
        };
        return ViewController;
    }(jy.FHost));
    jy.ViewController = ViewController;
    __reflect(ViewController.prototype, "jy.ViewController");
    /**
     * 使用@d_interest 注入 添加关注
     * 关注为事件处理回调，只会在awake时，添加到事件监听列表
     * 在sleep时，从事件监听列表中移除
     * @param {Key} type                         关注的事件
     * @param {(e?: Event) => void} handler          回调函数
     * @param {boolean} [triggerOnStage=false]      添加到舞台的时候，会立即执行一次，`<font color="#f00">`注意，处理回调必须能支持不传event的情况`
     * @param {boolean} [isPrivate=false]           是否为私有方法，如果标记为私有方法，则不会被子类的关注继承
     * @param {number} [priority=0]                 优先级，默认为0
     */
    function d_interest(eventType, triggerOnStage, isPrivate, priority) {
        var pKey = "_interests";
        return function (target, _, value) {
            var _interests;
            if (target.hasOwnProperty(pKey)) {
                _interests = target[pKey];
            }
            else {
                //未赋值前，先取值，可取到父级数据，避免使用  Object.getPrototypeOf(target)，ES5没此方法
                var inherit = target[pKey];
                target[pKey] = _interests = {};
                if (inherit) {
                    for (var k in inherit) {
                        var int = inherit[k];
                        if (!int.isPri) {
                            _interests[k] = int;
                        }
                    }
                }
            }
            _interests[eventType] = { handler: value.value, priority: priority, trigger: triggerOnStage, isPri: isPrivate };
        };
    }
    jy.d_interest = d_interest;
})(jy || (jy = {}));
//# sourceMappingURL=ViewController.js.map