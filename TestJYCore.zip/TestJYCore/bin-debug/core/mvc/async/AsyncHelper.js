var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var jy;
(function (jy) {
    /**
     * 异步工具类，用于加方法兼听
     * @author 3tion
     *
     */
    var AsyncHelper = (function () {
        function AsyncHelper() {
            /**
             * 是否已经处理完成
             */
            this.isReady = false;
        }
        /**
         * 异步数据已经加载完毕
         */
        AsyncHelper.prototype.readyNow = function () {
            if (!this.isReady) {
                this.isReady = true;
                var _readyExecutes = this._cbs;
                if (_readyExecutes) {
                    var temp = _readyExecutes.concat();
                    _readyExecutes.length = 0;
                    for (var i = 0; i < temp.length; i++) {
                        var callback = temp[i];
                        callback.execute();
                    }
                }
            }
        };
        /**
         * 检查是否完成,并让它回调方法
         *
         * @param {Function} handle 处理函数
         * @param {*} thisObj this对象
         * @param {any[]} args 函数的参数
         */
        AsyncHelper.prototype.addReadyExecute = function (handle, thisObj) {
            var args = [];
            for (var _i = 2; _i < arguments.length; _i++) {
                args[_i - 2] = arguments[_i];
            }
            if (this.isReady) {
                return handle.apply(thisObj, args);
            }
            var _readyExecutes = this._cbs;
            if (!_readyExecutes) {
                this._cbs = _readyExecutes = [];
            }
            jy.CallbackInfo.addToList.apply(jy.CallbackInfo, [_readyExecutes, handle, thisObj].concat(args));
        };
        return AsyncHelper;
    }());
    jy.AsyncHelper = AsyncHelper;
    __reflect(AsyncHelper.prototype, "jy.AsyncHelper");
})(jy || (jy = {}));
//# sourceMappingURL=AsyncHelper.js.map