var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var jy;
(function (jy) {
    /**
     * 功能配置的基类
     * @author 3tion
     */
    var BaseMCfg = (function () {
        function BaseMCfg() {
            /**
             * 当前显示状态
             */
            this.showState = 0 /* HIDE */;
            /**
             * 服务器认为此功能开放
             */
            this.serverOpen = true;
        }
        BaseMCfg.prototype.init = function (from) {
            from = from || this;
            //解析显示限制
            jy.DataUtils.parseDatas(this, from, 0, 3, "showlimit", "showlimits");
            //解析功能使用限制
            jy.DataUtils.parseDatas(this, from, 0, 3, "limit", "limits");
        };
        return BaseMCfg;
    }());
    jy.BaseMCfg = BaseMCfg;
    __reflect(BaseMCfg.prototype, "jy.BaseMCfg");
})(jy || (jy = {}));
//# sourceMappingURL=BaseMCfg.js.map