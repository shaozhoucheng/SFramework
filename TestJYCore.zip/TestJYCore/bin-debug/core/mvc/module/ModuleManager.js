var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var jy;
(function (jy) {
    /**
     * 模块管理器
     * 用于管理模块的开启/关闭
     * @author 3tion
     *
     */
    var ModuleManager = (function () {
        function ModuleManager() {
            /**
             * 需要检查
             */
            this._needCheck = false;
            /**
             * 需要检查显示/开启
             */
            this._needCheckShow = false;
        }
        ModuleManager.prototype.init = function () {
            this._bindedIOById = [];
            this._hByType = [];
            this._checkers = [];
            this._allById = {};
            this._unshowns = [];
            this._unopens = [];
            this._hById = {};
            this._ioBind = new Map();
            jy.on(-993 /* MODULE_NEED_CHECK_SHOW */, this.check, this);
        };
        /**
         * 设置模块配置数据
         * @param { [index: string]: ModuleCfg }    cfgs
         */
        ModuleManager.prototype.setCfgs = function (cfgs) {
            this._allById = cfgs;
            this.doCheckLimits();
        };
        /**
         * 根据配置类型，注册模块处理器
         * @param type
         * @param handler
         *
         */
        ModuleManager.prototype.registerHandler = function (type, handler) {
            this._hByType[type] = handler;
        };
        /**
         * 根据模块ID注册处理函数
         * @param id
         * @param handler
         *
         */
        ModuleManager.prototype.registerHandlerById = function (id, handler) {
            var cfg = this._allById[id];
            if (cfg) {
                this._hById[id] = handler;
            }
            else {
                jy.ThrowError("ModuleManager 注册模块处理函数时，没有找到对应的模块配置，模块id:" + id);
            }
        };
        Object.defineProperty(ModuleManager.prototype, "checkers", {
            /**
             * 设置限制检查器
             * @param value	一个字典<br/>
             * Key  	{number}            限制器(showtype,limittype)类型<br/>
             * Value	{IModuleChecker}	    模块限制检查器
             *
             */
            set: function (value) {
                this._checkers = value;
                this.doCheckLimits();
            },
            enumerable: true,
            configurable: true
        });
        ModuleManager.prototype.doCheckLimits = function () {
            this._needCheck = true;
            egret.callLater(this.checkLimits, this);
        };
        /**
         * 检查限制
         */
        ModuleManager.prototype.checkLimits = function () {
            if (this._needCheck) {
                this._needCheck = false;
                var _checks = this._checkers;
                var _allById = this._allById;
                if (_checks) {
                    if (true) {
                        var errString = "";
                        var limitWarn = "";
                        var unsolve = "";
                    }
                    var checker = void 0;
                    for (var id in _allById) {
                        var cfg = _allById[id];
                        var showtype = cfg.showtype;
                        if (showtype) {
                            checker = _checks[showtype];
                            if (true) {
                                if (!checker) {
                                    unsolve += cfg.id + "的显示限制 ";
                                }
                            }
                        }
                        var limittype = cfg.limittype;
                        if (limittype) {
                            checker = _checks[limittype];
                            if (true) {
                                if (!checker) {
                                    unsolve += cfg.id + "的使用限制 ";
                                }
                            }
                        }
                        if (showtype == limittype) {
                            if (showtype) {
                                if (checker) {
                                    if (false) {
                                        checker.adjustLimitDatas(cfg.showlimits, cfg.limits);
                                    }
                                    if (true) {
                                        if (checker.adjustLimitDatas(cfg.showlimits, cfg.limits)) {
                                            errString += cfg.id + " ";
                                        }
                                    }
                                }
                            }
                        }
                        else {
                            if (true) {
                                limitWarn += cfg.id + " ";
                            }
                        }
                        if (!this.isModuleShow(cfg)) {
                            var id_1 = cfg.id;
                            this._unshowns.push(id_1);
                            var displays = this._bindedIOById[id_1];
                            if (displays) {
                                for (var i = 0; i < displays.length; i++) {
                                    displays[i].visible = false;
                                }
                            }
                        }
                        if (!this.isModuleOpened(cfg)) {
                            this._unopens.push(id);
                        }
                    }
                    if (true) {
                        if (limitWarn) {
                            jy.ThrowError("id为：" + limitWarn + "的功能配置，showtype和limittype不一致，请确认是否要这样，这种配置将无法通过程序的方式确认当可以使用功能的时候，是否一定看得见功能入口");
                        }
                        if (errString) {
                            jy.ThrowError("id为:" + errString + "的功能配置使用限制和显示限制配置有误，自动进行修正");
                        }
                        if (unsolve) {
                            jy.ThrowError("有功能配置的限制类型并未实现：");
                        }
                    }
                    jy.dispatch(-998 /* MODULE_CHECKER_INITED */);
                }
            }
        };
        /**
         * 模块是否已经显示
         * @param module    {string | number | IModuleCfg}    模块或者模块配置
         */
        ModuleManager.prototype.isModuleShow = function (module) {
            var cfg = this.getCfg(module);
            if (true) {
                if (!cfg) {
                    jy.ThrowError("\u6CA1\u6709\u627E\u5230\u5BF9\u5E94\u7684\u529F\u80FD\u914D\u7F6E[" + module + "]");
                }
            }
            var flag = cfg && cfg.close != 2 /* Closed */;
            if (flag && this._checkers) {
                var checker = this._checkers[cfg.showtype];
                if (checker) {
                    flag = checker.check(cfg.showlimits, false);
                }
            }
            return flag;
        };
        /**
         * 模块是否已经开启
         * @param module    {string | number | IModuleCfg}    模块或者模块配置
         * @param showtip   是否显示Tip
         */
        ModuleManager.prototype.isModuleOpened = function (module, showtip) {
            var cfg = this.getCfg(module);
            if (true) {
                if (!cfg) {
                    jy.ThrowError("\u6CA1\u6709\u627E\u5230\u5BF9\u5E94\u7684\u529F\u80FD\u914D\u7F6E[" + module + "]");
                }
            }
            if (false || jy.ClientCheck.isClientCheck) {
                var flag = cfg && !cfg.close && cfg.serverOpen;
                if (flag) {
                    if (this._checkers) {
                        var checker = this._checkers[cfg.limittype];
                        if (checker) {
                            flag = checker.check(cfg.limits, showtip);
                        }
                    }
                }
                else {
                    if (showtip && this.showTip) {
                        this.showTip(1 /* ComingSoon */);
                    }
                }
                return flag;
            }
            else {
                return true;
            }
        };
        /**
         * 将交互对象和功能id进行绑定，当交互对象抛出事件后，会执行功能对应的处理器
         * @param id					功能id
         * @param io					交互对象
         * @param eventType		事件
         *
         */
        ModuleManager.prototype.bindButton = function (id, io, eventType) {
            if (eventType === void 0) { eventType = "touchTap" /* TOUCH_TAP */; }
            if (this._ioBind.has(io)) {
                jy.ThrowError("ModuleManager 注册按钮时候，重复注册了按钮");
                return;
            }
            var cfg = this._allById[id];
            if (!cfg) {
                jy.ThrowError("ModuleManager 注册按钮时候，没有找到对应的模块配置，模块id:" + id);
                return;
            }
            var arr = this._bindedIOById[id];
            if (!arr) {
                this._bindedIOById[id] = arr = [];
            }
            arr.push(io);
            this._ioBind.set(io, id);
            io.on(eventType, this.ioHandler, this);
            if (this.createToolTip) {
                var toolTips = this.createToolTip(cfg);
                if (toolTips) {
                    jy.ToolTipManager.register(io, toolTips);
                }
            }
            var _unshowns = this._unshowns;
            if (!this.isModuleShow(id)) {
                io.visible = false;
                _unshowns.pushOnce(id);
            }
            else {
                _unshowns.remove(id);
            }
        };
        /**
         * 交互事件的处理
         * @param event
         *
         */
        ModuleManager.prototype.ioHandler = function (event) {
            this.toggle(this._ioBind.get(event.currentTarget));
        };
        /**
         * 检查显示/开启
         * @param event
         *
         */
        ModuleManager.prototype.check = function () {
            this._needCheckShow = true;
            egret.callLater(this._check, this);
        };
        ModuleManager.prototype._check = function () {
            if (!this._needCheckShow) {
                return;
            }
            this._needCheckShow = false;
            var changed = false;
            var _a = this, _allById = _a._allById, _unshowns = _a._unshowns, _unopens = _a._unopens;
            var j = 0;
            for (var i = 0; i < _unshowns.length; i++) {
                var id = _unshowns[i];
                var cfg = _allById[id];
                if (this.isModuleShow(cfg)) {
                    var onShow = cfg.onShow;
                    if (onShow) {
                        cfg.onShow = undefined;
                        for (var d = 0; d < onShow.length; d++) {
                            var callback = onShow[d];
                            callback.execute();
                        }
                    }
                    var displays = this._bindedIOById[id];
                    if (displays) {
                        for (var _i = 0, displays_1 = displays; _i < displays_1.length; _i++) {
                            var dis = displays_1[_i];
                            dis.visible = true;
                        }
                    }
                    changed = true;
                }
                else {
                    _unshowns[j++] = id;
                }
            }
            _unshowns.length = j;
            j = 0;
            for (var i = 0; i < _unopens.length; i++) {
                var id = _unopens[i];
                var cfg = _allById[id];
                if (this.isModuleOpened(cfg)) {
                    var onOpen = cfg.onOpen;
                    if (onOpen) {
                        cfg.onOpen = undefined;
                        for (var d = 0; d < onOpen.length; d++) {
                            var callback = onOpen[d];
                            callback.execute();
                        }
                    }
                }
                else {
                    _unopens[j++] = id;
                }
            }
            _unopens.length = j;
            if (changed) {
                jy.dispatch(-994 /* MODULE_SHOW_CHANGED */, _unshowns.length);
            }
        };
        /**
         *
         * 打开/关闭指定模块
         * @param {(string | number)} moduleID      模块id
         * @param {ToggleState} [toggleState]      0 自动切换(默认)<br/>  1 打开模块<br/> -1 关闭模块<br/>
         * @param {boolean} [showTip=true]          是否显示Tip
         * @return true   可以正常打开
         *         false  被模块配置拦截，无法打开
         */
        ModuleManager.prototype.toggle = function (moduleID, show, showtip, param) {
            if (showtip === void 0) { showtip = true; }
            var cfg = this._allById[moduleID];
            if (!cfg) {
                true && jy.ThrowError("ModuleManager execute时，无法找到对应模块配置,ModuleID为:" + moduleID);
                return;
            }
            jy.dispatch(-997 /* MODULE_TRY_TOGGLE */, moduleID);
            var needShow;
            show = ~~show;
            switch (show) {
                case 0 /* AUTO */:
                    switch (cfg.showState) {
                        case 0 /* HIDE */:
                        case 3 /* HIDING */:
                            needShow = true;
                            break;
                    }
                    break;
                case 1 /* SHOW */:
                    needShow = true;
                    break;
            }
            if (needShow && !this.isModuleOpened(cfg, showtip)) {
                return;
            }
            var moduleHandler = this._hById[moduleID];
            if (!moduleHandler) {
                moduleHandler = this._hByType[cfg.type];
            }
            if (needShow) {
                moduleHandler.show(cfg, param);
            }
            else {
                moduleHandler.hide(cfg, param);
            }
            return true;
        };
        /**
         * 获取模块
         * @param module
         */
        ModuleManager.prototype.getCfg = function (module) {
            return typeof module === "object" ? module : this._allById[module];
        };
        /**
         * 改变服务器模块状态
         *
         * @param {string | number}  mid    服务器模块id
         * @param {boolean} state       模块状态
         */
        ModuleManager.prototype.serverChangeModuleState = function (mid, state) {
            var mcfg = this._allById[mid];
            if (mcfg) {
                if (state != mcfg.serverOpen) {
                    mcfg.serverOpen = state;
                    jy.dispatch(state ? -995 /* MODULE_SERVER_OPEN */ : -996 /* MODULE_SERVER_CLOSE */, mid);
                }
            }
        };
        /**
         * 注册模块开启的回调函数，如果模块已经开启，则直接执行回调
         *
         * @param {Key} mid
         * @param {$CallbackInfo} callback
         */
        ModuleManager.prototype.regModuleOpen = function (mid, callback) {
            var cfg = this._allById[mid];
            if (cfg) {
                if (this.isModuleOpened(cfg)) {
                    callback.execute();
                }
                else {
                    var onOpen = cfg.onOpen;
                    if (!onOpen) {
                        cfg.onOpen = onOpen = [];
                    }
                    onOpen.pushOnce(callback);
                }
            }
        };
        /**
         * 注册模块显示的回调函数，如果模块已经开启，则直接执行回调
         *
         * @param {Key} mid
         * @param {$CallbackInfo} callback
         */
        ModuleManager.prototype.regModuleShow = function (mid, callback) {
            var cfg = this._allById[mid];
            if (cfg) {
                if (this.isModuleShow(cfg)) {
                    callback.execute();
                }
                else {
                    var onShow = cfg.onShow;
                    if (!onShow) {
                        cfg.onShow = onShow = [];
                    }
                    onShow.pushOnce(callback);
                }
            }
        };
        return ModuleManager;
    }());
    jy.ModuleManager = ModuleManager;
    __reflect(ModuleManager.prototype, "jy.ModuleManager");
})(jy || (jy = {}));
//# sourceMappingURL=ModuleManager.js.map