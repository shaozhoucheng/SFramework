var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var $nl_nc;
var jy;
(function (jy) {
    /**
     * 姓 集合
     * 对应配置中 姓 列
     */
    var A = [];
    /**
     * 符号 集合
     * 对应配置中 符号 列
     */
    var B = [];
    /**
     * 名 集合
     * 对应配置中 男名，女名 列
     * index（0：男名，1：女名）
     */
    var C = [, [], []];
    var inited;
    function setLib(data) {
        var a = data.a, b = data.b, c1 = data.c1, c2 = data.c2;
        var split = ";";
        a && (A = a.split(split));
        b && (B = b.split(split));
        c1 && (C[1 /* Male */] = c1.split(split));
        c2 && (C[2 /* Female */] = c2.split(split));
        inited = true;
    }
    var NameUtils = (function () {
        /**
         *
         * @param randomFunc	随机算法
         *
         */
        function NameUtils(randomFunc) {
            this.setRandom(randomFunc);
        }
        NameUtils.loadNameLib = function (url, callback) {
            if (inited) {
                return callback && callback.execute();
            }
            loadScript(url, function (err) {
                if (!err) {
                    if ($nl_nc) {
                        setLib($nl_nc);
                        $nl_nc = undefined;
                        inited = true;
                        return callback && callback.execute();
                    }
                }
            });
        };
        /**
         * 设置随机算法
         * @param randomFunc
         *
         */
        NameUtils.prototype.setRandom = function (randomFunc) {
            if (randomFunc != null) {
                this._random = randomFunc;
            }
            else {
                this._random = Math.random;
            }
        };
        /**
         * 获取名字
         * @param sex 1 男  2 女
         * @return
         *
         */
        NameUtils.prototype.getName = function (sex) {
            if (sex === void 0) { sex = 1 /* Male */; }
            var name = "";
            var SC = C[sex];
            if (!SC) {
                if (true) {
                    jy.ThrowError("性别必须为1或者2");
                }
                return;
            }
            var aLen = A.length;
            var bLen = B.length;
            var cLen = SC.length;
            var random = this._random;
            if (aLen)
                name += A[aLen * random() >> 0];
            if (bLen)
                name += (Date.now() & 1) ? "" : B[bLen * random() >> 0];
            if (cLen)
                name += SC[cLen * random() >> 0];
            return name;
        };
        NameUtils.prototype.dispose = function () {
            this._random = null;
        };
        /**
         * 设置名字库的数据
         *
         * @static
         * @memberof NameUtils
         */
        NameUtils.setLib = setLib;
        return NameUtils;
    }());
    jy.NameUtils = NameUtils;
    __reflect(NameUtils.prototype, "jy.NameUtils");
})(jy || (jy = {}));
//# sourceMappingURL=NameUtils.js.map