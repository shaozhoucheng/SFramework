var jy;
(function (jy) {
    var copyDiv = document.createElement("div");
    var doc = document;
    var de = doc.documentElement;
    /**
     * 拷贝到剪贴板中
     *
     * @author gushuai
     * @export
     * @param {string} str
     * @returns
     */
    function doCopy(str) {
        de.appendChild(copyDiv);
        copyDiv.innerText = str;
        var selection = getSelection();
        var range = doc.createRange();
        range.selectNodeContents(copyDiv);
        selection.removeAllRanges();
        selection.addRange(range);
        var val = doc.execCommand("copy");
        de.removeChild(copyDiv);
        return val;
    }
    jy.doCopy = doCopy;
})(jy || (jy = {}));
//# sourceMappingURL=CopyUtil.js.map