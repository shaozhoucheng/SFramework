var jy;
(function (jy) {
    var seed = 1;
    var callbacks = {};
    var Timeout = "RPCTimeout";
    var count = 0;
    var start;
    var willDel = [];
    jy.RPC = {
        Timeout: Timeout,
        callback: callback,
        registerCallback: registerCallback,
        /**
         * 注册回调函数，成功和失败，均使用该方法
         * 成功则data为返回的数据
         * 失败则data为Error
         * @param {{ (data?: any, ...args) }} callback
         * @param {*} [thisObj]
         * @param {any} any
         */
        registerCallbackFunc: function (callback, withError, timeout, thisObj) {
            if (timeout === void 0) { timeout = 2000 /* DefaultTimeout */; }
            var args = [];
            for (var _i = 4; _i < arguments.length; _i++) {
                args[_i - 4] = arguments[_i];
            }
            var success = jy.CallbackInfo.get.apply(jy.CallbackInfo, [callback, thisObj].concat(args));
            var error = jy.CallbackInfo.get.apply(jy.CallbackInfo, [withError ? callback : noErrorCallback(callback, thisObj), thisObj].concat(args));
            return registerCallback(success, error, timeout);
        },
        /**
        * 根据id移除回调函数
        *
        * @param {number} id
        */
        removeCallback: function (id) {
            var callback = callbacks[id];
            deleteCallback(id);
            if (callback) {
                var success = callback.success, error = callback.error;
                if (success) {
                    success.recycle();
                }
                if (error) {
                    error.recycle();
                }
            }
        }
    };
    function noErrorCallback(callback, thisObj) {
        return function (err) {
            var args = [];
            for (var _i = 1; _i < arguments.length; _i++) {
                args[_i - 1] = arguments[_i];
            }
            callback.call.apply(callback, [thisObj, undefined].concat(args));
        };
    }
    /**
     * 注册回调函数
     *
     * @param {Recyclable<CallbackInfo<{ (data?: any, ...args) }>>} success     成功的函数回调
     * @param {Recyclable<CallbackInfo<{ (error?: Error, ...args) }>>} [error]    发生错误的函数回调
     * @param {number} [timeout=2000] 超时时间，默认2000，实际超时时间会大于此时间，超时后，如果有错误回调，会执行错误回调，`Error(RPC.Timeout)`
     * @returns
     */
    function registerCallback(success, error, timeout) {
        if (timeout === void 0) { timeout = 2000 /* DefaultTimeout */; }
        var id = seed++;
        callbacks[id] = { id: id, expired: jy.Global.now + timeout, success: success, error: error };
        count++;
        if (!start) {
            jy.TimerUtil.addCallback(1000 /* ONE_SECOND */, check);
            start = true;
        }
        return id;
    }
    function deleteCallback(id) {
        if (id in callbacks) {
            delete callbacks[id];
            count--;
            if (count == 0) {
                jy.TimerUtil.removeCallback(1000 /* ONE_SECOND */, check);
                start = false;
            }
        }
    }
    /**
       * 执行回调
       *
       * @param {number} id 执行回调的id
       * @param {*} [data] 成功返回的数据
       * @param {(Error | string)} [err] 错误
       */
    function callback(id, data, err) {
        var callback = callbacks[id];
        if (!callback) {
            return;
        }
        deleteCallback(id);
        var success = callback.success, error = callback.error;
        var result;
        if (err) {
            if (typeof err === "string") {
                err = new Error(err);
            }
            if (error) {
                result = error.call(err);
                error.recycle();
            }
            if (success) {
                success.recycle();
            }
        }
        else {
            if (error) {
                error.recycle();
            }
            if (success) {
                result = success.call(data);
                success.recycle();
            }
        }
        return result;
    }
    function check() {
        var del = willDel;
        var i = 0;
        var now = jy.Global.now;
        for (var id in callbacks) {
            var callback_1 = callbacks[id];
            if (now > callback_1.expired) {
                del[i++] = id;
            }
        }
        for (var j = 0; j < i; j++) {
            var id = del[j];
            callback(id, null, Timeout);
        }
    }
})(jy || (jy = {}));
//# sourceMappingURL=RPC.js.map