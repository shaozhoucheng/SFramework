var jy;
(function (jy) {
    var _timeobj = {};
    var tmpList = [];
    var willDeleted = [];
    function tick(now) {
        var d = 0;
        for (var key in _timeobj) {
            var timer = _timeobj[key];
            if (timer.nt < now) {
                timer.nt = now + timer.tid;
                var list = timer.list;
                var len = list.length;
                if (len > 0) {
                    for (var i = 0; i < len; i++) {
                        tmpList[i] = list[i];
                    }
                    for (var i = 0; i < len; i++) {
                        tmpList[i].execute(false);
                    }
                }
                len = list.length;
                if (len == 0) {
                    willDeleted[d++] = key;
                }
            }
        }
        for (var i = 0; i < d; i++) {
            delete _timeobj[willDeleted[i]];
        }
    }
    function getInterval(time) {
        return Math.ceil(time / 10) * 10;
    }
    /**
     *
     * 注册回调  会对在同一个时间区间的 `callback`和`thisObj`相同的回调函数进行去重
     * @static
     * @param {number} time 回调的间隔时间，间隔时间会处理成30的倍数，向上取整，如 设置1ms，实际间隔为30ms，32ms，实际间隔会使用60ms
     * @param {Function} callback 回调函数，没有加this指针是因为做移除回调的操作会比较繁琐，如果函数中需要使用this，请通过箭头表达式()=>{}，或者将this放arg中传入
     * @param {any} [thisObj] 回调函数的`this`对象，不传值则使用全局上下文即window
     * @param {any} args 回调函数的参数
     */
    function addCallback(time, callback, thisObj) {
        var args = [];
        for (var _i = 3; _i < arguments.length; _i++) {
            args[_i - 3] = arguments[_i];
        }
        time = getInterval(time);
        var timer = _timeobj[time];
        if (!timer) {
            var list = [];
            timer = { tid: time, nt: jy.Global.now + time, list: list };
            _timeobj[time] = timer;
            list.push(jy.CallbackInfo.get.apply(jy.CallbackInfo, [callback, thisObj].concat(args)));
        }
        else {
            jy.CallbackInfo.addToList.apply(jy.CallbackInfo, [timer.list, callback, thisObj].concat(args));
        }
    }
    /**
     * 注册回调 会对在同一个时间区间的 `callback`相同的情况下，才会去重
     * @param time
     * @param callback
     */
    function add(time, callback) {
        time = getInterval(time);
        var timer = _timeobj[time];
        if (!timer) {
            timer = { tid: time, nt: jy.Global.now + time, list: [] };
            _timeobj[time] = timer;
        }
        timer.list.pushOnce(callback);
    }
    /**
     * 移除回调
     * 不回收`CallbackInfo`
     * @param {number} time
     * @param {$CallbackInfo} callback
     */
    function remove(time, callback) {
        time = getInterval(time);
        var timer = _timeobj[time];
        if (timer) {
            timer.list.remove(callback);
        }
    }
    /**
     * 移除回调
     * @static
     * @param {number} time         回调的间隔时间，间隔时间会处理成30的倍数，向上取整，如 设置1ms，实际间隔为30ms，32ms，实际间隔会使用60ms
     * @param {Function} callback   回调函数，没有加this指针是因为做移除回调的操作会比较繁琐，如果函数中需要使用this，请通过箭头表达式()=>{}，或者将this放arg中传入
     * @param {*} [thisObj]         回调函数的`this`对象
     */
    function removeCallback(time, callback, thisObj) {
        time = getInterval(time);
        var timer = _timeobj[time];
        if (timer) {
            var list = timer.list;
            var info = jy.CallbackInfo.removeFromList(list, callback, thisObj);
            if (info) {
                info.recycle();
            }
        }
    }
    jy.TimerUtil = { addCallback: addCallback, removeCallback: removeCallback, tick: tick, add: add, remove: remove };
})(jy || (jy = {}));
//# sourceMappingURL=TimerUtil.js.map