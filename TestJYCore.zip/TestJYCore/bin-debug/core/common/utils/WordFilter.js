/**
 * 脏字内容
 */
var $dirty;
var jy;
(function (jy) {
    /**
     * 初始化屏蔽字
     * @param str   使用特定符号分隔的脏字列表
     * @param split 分隔符
     *
     */
    function initFilterstring(str, split) {
        var arr = str.split(split);
        _len = arr.length;
        //每个正则，至少会增加 (?: )|，如果出现  \/*().?|+\-$\^=:!@| 这些字符，还会增加[]，如果出现\还会增加更多
        //按每个长度  5 + 2来处理
        var guessedLength = str.length + _len * 7;
        var p = /([\/*().?|+\-$\^=:!@])/g;
        var p2 = /([\\\[\]])/g;
        var t, i;
        if (guessedLength < 32768) {
            var l = _len - 1;
            var s = "(?:"; //必须加?:作为非捕获分组，否则分组会超过99个上限，最终导致无法replace
            for (i = 0; i < l; i++) {
                t = arr[i];
                if (t) {
                    t = t.replace(p2, "[\\$1]");
                    t = t.replace(p, "[$1]");
                    s += t + ")|(?:";
                }
            }
            t = arr[l];
            t = t.replace(p2, "[\\$1]");
            t = t.replace(p, "[$1]");
            s += t + ")|[|]";
            if (s.length < 32768) {
                filterWords = new RegExp(s, "g");
                jy.WordFilter.wordCensor = wordCensor1;
                jy.WordFilter.checkWord = checkWord1;
                return;
            }
        } //超过长度的采用方案2
        _filterList = new Array(_len + 1);
        for (i = 0; i < _len; i++) {
            t = arr[i];
            t = t.replace(p2, "[\\$1]");
            t = t.replace(p, "[$1]");
            _filterList[i] = new RegExp(t, "g");
        }
        //| 一般我们特殊用途，也加入屏蔽字符
        _filterList[i] = new RegExp("[|]", "g");
        _len = _len + 1;
        jy.WordFilter.wordCensor = wordCensor2;
        jy.WordFilter.checkWord = checkWord2;
    }
    //正常版
    function wordCensor1(msg) {
        return msg.replace(filterWords, replaceDirty);
    }
    function checkWord1(msg) {
        filterWords.lastIndex = 0;
        return filterWords.test(msg);
    }
    //_filterList 版
    function wordCensor2(msg) {
        for (var i = 0; i < _len; i++) {
            msg = msg.replace(_filterList[i], replaceDirty);
        }
        return msg;
    }
    function checkWord2(msg) {
        for (var i = 0; i < _len; i++) {
            _filterList[i].lastIndex = 0;
            if (_filterList[i].test(msg)) {
                return true;
            }
        }
    }
    /**
     * 将字符替换成*
     * @param substring 子字符串
     * @return
     *
     */
    var replaceDirty = function (substring) {
        var len = substring.length;
        var result = "";
        while (len--) {
            result += "*";
        }
        return result;
    };
    /**
     * 如果超过正则表达式长度，使用的数组
     */
    var _filterList;
    /**
     * 昵称的过滤数组，没有加载到数据时使用
     */
    var filterWords = /卐|妓|婊|尻|屄|屌|睾|肏|[|]/g;
    /**
     * 长度
     */
    var _len;
    /**
     * 文字过滤
     * @author 3tion
     */
    jy.WordFilter = {
        /**
         * 由于脏字文件使用ajax读取，可能存在跨域问题，所以在H5中使用javascript方式加载
         */
        loadDirtyWord: function (url, split) {
            if (split === void 0) { split = ";"; }
            loadScript(url, function () {
                if ($dirty) {
                    initFilterstring($dirty, split);
                    // 清理脏字原始数据
                    $dirty = undefined;
                }
            });
        },
        /**
         * 初始化屏蔽字
         * @param str   使用特定符号分隔的脏字列表
         * @param split 分隔符
         *
         */
        initFilterstring: initFilterstring,
        /**
         * 将敏感词替换为**
         * @param msg	要检测的文字
         * @return
         *
         */
        wordCensor: wordCensor1,
        /**
         * 设置 将字符替换成* 的函数
         * @param substring 子字符串
         * @return
         *
         */
        setDirtyHandler: function (handler) {
            replaceDirty = handler;
        },
        /**
         * 是否有敏感词
         * @param msg	要检测的文字
         * @return 		true为有敏感词，false为没有敏感词
         *
         */
        checkWord: checkWord1,
    };
})(jy || (jy = {}));
//# sourceMappingURL=WordFilter.js.map