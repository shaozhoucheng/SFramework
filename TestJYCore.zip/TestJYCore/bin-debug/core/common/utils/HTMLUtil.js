var jy;
(function (jy) {
    /**
     * HTML工具类
     * @author 3tion
     */
    var unescChars = { "&lt;": "<", "&gt;": ">", "&quot;": "\"", "&apos;": "\'", "&amp;": "&", "&nbsp;": " ", "&#x000A;": "\n" };
    var escChars = { "<": "&lt;", ">": "&gt;", "'": "&apos;", "\"": "&quot;", "&": "&amp;" };
    function escFun(substring) {
        return escChars[substring];
    }
    function unescFun(substring) {
        return unescChars[substring];
    }
    jy.HTMLUtil = {
        /**
         * 字符着色
         *
         * @param {string | number} value       内容
         * @param {(string | number)} color     颜色
         * @returns
         */
        createColorHtml: function (value, color) {
            var c;
            if (typeof color == "number") {
                c = jy.ColorUtil.getColorString(color);
            }
            else if (color.charAt(0) != "#") {
                c = "#" + color;
            }
            else {
                c = color;
            }
            return "<font color=\'" + c + "\'>" + value + "</font>";
        },
        /**
         * 清理html;
         * @value value
         * @return
         *
         */
        clearHtml: function (value) {
            return value.replace(/<[^><]*?>/g, "");
        },
        /**
         * 将特殊字符串处理为HTML转义字符
         *
         * @param {string} content
         */
        escHTML: function (content) {
            return content.replace(/<|>|"|'|&/g, escFun);
        },
        /**
         * 将HTML特殊符号，恢复成正常字符串
         *
         * @param {string} content
         * @returns
         */
        unescHTML: function (content) {
            return content.replace(/&lt;|&gt;|&quot;|&apos;|&amp;|&nbsp;|&#x000A;/g, unescFun);
        }
    };
})(jy || (jy = {}));
//# sourceMappingURL=HTMLUtil.js.map