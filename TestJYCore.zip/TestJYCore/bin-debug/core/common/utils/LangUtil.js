var jy;
(function (jy) {
    var _msgDict;
    if (typeof $lang === "object") {
        _msgDict = $lang;
        $lang = undefined; //将全局变量清除，只保留闭包
    }
    else {
        _msgDict = {};
    }
    /**
     * 用于处理语言/文字显示
     */
    jy.LangUtil = {
        /**
         * 获取显示的信息
         *
         * @static
         * @param {Key} code code码
         * @param {any} args 其他参数  替换字符串中{0}{1}{2}{a} {b}这样的数据，用obj对应key替换，或者是数组中对应key的数据替换
         * @returns 显示信息
         */
        getMsg: function () {
            var argus = arguments;
            var code = argus[0];
            var len = argus.length;
            var args;
            if (len == 2) {
                args = argus[1];
            }
            else if (len > 2) {
                args = [];
                var j = 0;
                for (var i = 1; i < len; i++) {
                    args[j++] = argus[i];
                }
            }
            if (code in _msgDict) {
                return _msgDict[code].substitute(args);
            }
            return typeof code === "string" ? code.substitute(args) : code + "";
        },
        has: function (code) {
            return code in _msgDict;
        },
        /**
         *
         * 注册语言字典
         * @static
         * @param { { [index: string]: string }} data
         */
        regMsgDict: function (data) {
            _msgDict = data;
        }
    };
})(jy || (jy = {}));
//# sourceMappingURL=LangUtil.js.map