var jy;
(function (jy) {
    var _texture;
    jy.DataUrlUtils = {
        /**
         * 根据dataUrl获取 base64字符串
         *
         * @param {string} dataUrl
         * @returns
         */
        getBase64: getBase64,
        /**
         * 根据dataUrl获取Uint8Array
         *
         * @param {string} dataUrl
         * @returns
         */
        getBytes: getBytes,
        /**
         * 获取白鹭可视对象的dataUrl
         *
         * @param {egret.DisplayObject} dis
         * @param {string} type
         * @param {egret.Rectangle} [rect]
         * @param {any} [encodeOptions]
         * @returns
         */
        getDisplayDataURL: getDisplayDataURL,
        /**
         * 获取可视对象的Base64字符串
         *
         * @param {egret.DisplayObject} dis
         * @param {string} type
         * @param {egret.Rectangle} [rect]
         * @param {any} [encodeOptions]
         * @returns
         */
        getDisplayBase64: function (dis, type, rect, encodeOptions, scale) {
            return getBase64(getDisplayDataURL(dis, type, rect, encodeOptions, scale));
        },
        /**
         * 获取可视对象的Uint8字节流
         *
         * @param {egret.DisplayObject} dis
         * @param {string} type
         * @param {egret.Rectangle} [rect]
         * @param {any} [encodeOptions]
         * @returns
         */
        getDisplayBytes: function (dis, type, rect, encodeOptions, scale) {
            return getBytes(getDisplayDataURL(dis, type, rect, encodeOptions, scale));
        }
    };
    function getDisplayDataURL(dis, type, rect, encodeOptions, scale) {
        if (!_texture) {
            _texture = new egret.RenderTexture;
        }
        rect = rect || dis.getBounds();
        _texture.drawToTexture(dis, rect, scale);
        return _texture.toDataURL(type, null, encodeOptions);
    }
    function getBase64(dataUrl) {
        return dataUrl.substr(dataUrl.indexOf(",") + 1);
    }
    function getBytes(dataUrl) {
        var b64 = this.getBase64(dataUrl);
        var binaryString = window.atob(b64);
        var len = binaryString.length;
        var bytes = new Uint8Array(len);
        for (var i = 0; i < len; i++) {
            bytes[i] = binaryString.charCodeAt(i);
        }
        return bytes;
    }
})(jy || (jy = {}));
//# sourceMappingURL=DataUrlUtils.js.map