var jy;
(function (jy) {
    function getColorString(c) {
        return "#" + c.toString(16).zeroize(6);
    }
    var textureCaches = {};
    /**
     * 颜色工具
     * @author 3tion
     *
     */
    jy.ColorUtil = {
        /**
         * 获取颜色字符串 #a1b2c3
         * @param c
         * @return 获取颜色字符串 #a1b2c3
         *
         */
        getColorString: getColorString,
        /**
         * 将#a1b2c3这样#开头的颜色字符串，转换成颜色数值
         */
        getColorValue: function (c) {
            if (/#[0-9a-f]{6}/i.test(c)) {
                return +("0x" + c.substring(1));
            }
            else {
                if (true) {
                    jy.ThrowError("\u4F7F\u7528\u7684\u989C\u8272" + c + "\u6709\u8BEF");
                }
                return 0;
            }
        },
        /**
         * 获取一个纯色的纹理
         */
        getTexture: function (color, alpha) {
            if (color === void 0) { color = 0; }
            if (alpha === void 0) { alpha = 0.8; }
            var key = color + "_" + alpha;
            var tex = textureCaches[key];
            if (!tex) {
                var canvas = document.createElement("canvas");
                canvas.height = canvas.width = 1;
                var ctx = canvas.getContext("2d");
                ctx.globalAlpha = alpha;
                ctx.fillStyle = getColorString(color);
                ctx.fillRect(0, 0, 1, 1);
                tex = new egret.Texture();
                tex.bitmapData = new egret.BitmapData(canvas);
            }
            return tex;
        }
    };
})(jy || (jy = {}));
//# sourceMappingURL=ColorUtil.js.map