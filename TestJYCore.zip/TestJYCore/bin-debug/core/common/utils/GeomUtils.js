var jy;
(function (jy) {
    /**
     * 获取多个点的几何中心点
     *
     * @export
     * @param {Point[]} points 点集
     * @param {Point} result 结果
     * @returns {Point} 点集的几何中心点
     * @author gushuai
     */
    function getCenter(points, result) {
        result = result || {};
        var len = points.length;
        var x = 0;
        var y = 0;
        for (var i = 0; i < len; i++) {
            var point = points[i];
            x += point.x;
            y += point.y;
        }
        result.x = x / len;
        result.y = y / len;
        return result;
    }
    jy.getCenter = getCenter;
    /**
     * 检查类矩形 a 和 b 是否相交
     * @export
     * @param {Rect} a   类矩形a
     * @param {Rect} b   类矩形b
     * @returns {boolean} true     表示两个类似矩形的物体相交
     *         false    表示两个类似矩形的物体不相交
     */
    function intersects(a, b) {
        var aright = a.x + a.width;
        var abottom = a.y + a.height;
        var bright = b.x + b.width;
        var bbottom = b.y + b.height;
        return Math.max(a.x, b.x) <= Math.min(aright, bright)
            && Math.max(a.y, b.y) <= Math.min(abottom, bbottom);
    }
    jy.intersects = intersects;
    /**
     * 获取点集围成的区域的面积
     * S=（（X2-X1）*  (Y2+Y1)+（X2-X2）*  (Y3+Y2)+（X4-X3）*  (Y4+Y3)+……+（Xn-Xn-1）*  (Yn+Yn-1)+（X1-Xn）*  (Y1+Yn)）/2
     * @export
     * @param {Point[]} points 点集
     * @returns {number}
     */
    function getArea(points) {
        var p0 = points[0];
        var s = 0;
        var last = p0;
        for (var i = 1; i < length; i++) {
            var p = points[i];
            s += (p.x - last.x) * (p.y + last.y);
            last = p;
        }
        s += (p0.x - last.x) * (p0.y + last.y);
        return s * .5;
    }
    jy.getArea = getArea;
})(jy || (jy = {}));
//# sourceMappingURL=GeomUtils.js.map