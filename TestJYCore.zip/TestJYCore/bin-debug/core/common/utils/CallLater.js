var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var jy;
(function (jy) {
    /**
     * 延迟执行
     * @author 3tion
     */
    var CallLater = (function () {
        function CallLater() {
            this._callLaters = [];
            this._temp = [];
        }
        CallLater.prototype.tick = function (now) {
            var i = 0, j = 0, k = 0, callLaters = this._callLaters, temp = this._temp;
            // 检查callLater，执行时间够的calllater调用
            for (var len = callLaters.length; i < len; i++) {
                var cb = callLaters[i];
                if (now > cb.time) {
                    temp[j++] = cb;
                }
                else {
                    callLaters[k++] = cb;
                }
            }
            callLaters.length = k;
            for (i = 0; i < j; i++) {
                temp[i].execute();
            }
        };
        /**
         * 增加延迟执行的函数
         *
         * @param {Function} callback (description)
         * @param {number} now (description)
         * @param {number} [time] (description)
         * @param {*} [thisObj] (description)
         * @param args (description)
         */
        CallLater.prototype.callLater = function (callback, now, time, thisObj) {
            var args = [];
            for (var _i = 4; _i < arguments.length; _i++) {
                args[_i - 4] = arguments[_i];
            }
            var cInfo = jy.CallbackInfo.addToList.apply(jy.CallbackInfo, [this._callLaters, callback, thisObj].concat(args));
            cInfo.time = now + (time || 0);
        };
        /**
         * 清理延迟执行的函数
         *
         * @param {Function} callback (description)
         * @param {*} [thisObj] (description)
         */
        CallLater.prototype.clearCallLater = function (callback, thisObj) {
            var callLaters = this._callLaters;
            for (var i = callLaters.length - 1; i >= 0; --i) {
                var cInfo = callLaters[i];
                if (cInfo.checkHandle(callback, thisObj)) {
                    callLaters.splice(i, 1);
                    return cInfo.recycle();
                }
            }
        };
        CallLater.prototype.callLater2 = function (callback, now, time) {
            if (time === void 0) { time = 0; }
            this._callLaters.pushOnce(callback);
            callback.time = now + (time || 0);
        };
        CallLater.prototype.clearCallLater2 = function (callback) {
            this._callLaters.remove(callback);
            return callback.recycle();
        };
        return CallLater;
    }());
    jy.CallLater = CallLater;
    __reflect(CallLater.prototype, "jy.CallLater");
})(jy || (jy = {}));
//# sourceMappingURL=CallLater.js.map