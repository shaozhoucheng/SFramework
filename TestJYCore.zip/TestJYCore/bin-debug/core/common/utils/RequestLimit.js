var jy;
(function (jy) {
    var _dic = {};
    /**
     * 请求限制
     * @author 3tion
     *
     */
    jy.RequestLimit = {
        /**
         *
         *
         * @param {Key} o 锁定的对像(可以是任何类型,它会被当做一个key)
         * @param {number} [time=500] 锁定对像 毫秒数
         * @returns 是否已解锁 true为没有被限制,false 被限制了
         */
        check: function (o, time) {
            if (time === void 0) { time = 500; }
            time = time | 0;
            if (time <= 0) {
                return true;
            }
            var t = _dic[o];
            var now = jy.Global.now;
            if (!t) {
                _dic[o] = time + now;
                return true;
            }
            var i = t - now;
            if (i > 0) {
                return false;
            }
            _dic[o] = time + now;
            return true;
        },
        /**
         * 删除
         * @param o
         *
         */
        remove: function (o) {
            delete _dic[o];
        }
    };
})(jy || (jy = {}));
//# sourceMappingURL=RequestLimit.js.map