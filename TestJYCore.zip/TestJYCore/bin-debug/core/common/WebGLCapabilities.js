var jy;
(function (jy) {
    function isPowerOfTwo(n) {
        return (n !== 0) && ((n & (n - 1)) === 0);
    }
    function getAngle(getParameter) {
        var _a = getParameter(33902 /* ALIASED_LINE_WIDTH_RANGE */), min = _a[0], max = _a[1];
        // Heuristic: ANGLE is only on Windows, not in IE, and not in Edge, and does not implement line width greater than one.
        var angle = ((navigator.platform === 'Win32') || (navigator.platform === 'Win64')) &&
            (getParameter(7937 /* RENDERER */) !== 'Internet Explorer') &&
            (getParameter(7937 /* RENDERER */) !== 'Microsoft Edge') &&
            (min === 0 && max === 1);
        if (angle) {
            // Heuristic: D3D11 backend does not appear to reserve uniforms like the D3D9 backend, e.g.,
            // D3D11 may have 1024 uniforms per stage, but D3D9 has 254 and 221.
            //
            // We could also test for WEBGL_draw_buffers, but many systems do not have it yet
            // due to driver bugs, etc.
            if (isPowerOfTwo(getParameter(36347 /* MAX_VERTEX_UNIFORM_VECTORS */)) && isPowerOfTwo(getParameter(36349 /* MAX_FRAGMENT_UNIFORM_VECTORS */))) {
                return 2 /* D3D11 */;
            }
            else {
                return 1 /* D3D9 */;
            }
        }
        return 0 /* No */;
    }
    function getMaxAnisotropy(g) {
        var e = g.getExtension('EXT_texture_filter_anisotropic')
            || g.getExtension('WEBKIT_EXT_texture_filter_anisotropic')
            || g.getExtension('MOZ_EXT_texture_filter_anisotropic');
        if (e) {
            var max = g.getParameter(34047 /* MAX_TEXTURE_MAX_ANISOTROPY_EXT */);
            if (max === 0) {
                max = 2;
            }
            return max;
        }
    }
    function getMaxDrawBuffers(g) {
        var maxDrawBuffers = 1;
        var ext = g.getExtension("WEBGL_draw_buffers");
        if (ext != null) {
            maxDrawBuffers = g.getParameter(34852 /* MAX_DRAW_BUFFERS_WEBGL */);
        }
        return maxDrawBuffers;
    }
    function getWebGLCaps(g) {
        if (!g) {
            var canvas = document.createElement("canvas");
            var webglAttr = {
                stencil: true,
                failIfMajorPerformanceCaveat: true
            };
            g = canvas.getContext("webgl", webglAttr) || canvas.getContext("experimental-webgl", webglAttr);
        }
        if (!g) {
            return;
        }
        var getParameter = g.getParameter.bind(g);
        var unmaskedRenderer, unmaskedVendor;
        var dbgRenderInfo = g.getExtension("WEBGL_debug_renderer_info");
        if (dbgRenderInfo) {
            unmaskedVendor = getParameter(37445 /* UNMASKED_VENDOR_WEBGL */);
            unmaskedRenderer = getParameter(37446 /* UNMASKED_RENDERER_WEBGL */);
        }
        return {
            unmaskedRenderer: unmaskedRenderer,
            unmaskedVendor: unmaskedVendor,
            version: getParameter(7938 /* VERSION */),
            shaderVersion: getParameter(35724 /* SHADING_LANGUAGE_VERSION */),
            vendor: getParameter(7936 /* VENDOR */),
            renderer: getParameter(7937 /* RENDERER */),
            antialias: g.getContextAttributes().antialias,
            angle: getAngle(getParameter),
            maxVertAttr: getParameter(34921 /* MAX_VERTEX_ATTRIBS */),
            maxVertTextureCount: getParameter(35660 /* MAX_VERTEX_TEXTURE_IMAGE_UNITS */),
            maxVertUniforms: getParameter(36347 /* MAX_VERTEX_UNIFORM_VECTORS */),
            maxVaryings: getParameter(36348 /* MAX_VARYING_VECTORS */),
            aliasedLineWidth: getParameter(33902 /* ALIASED_LINE_WIDTH_RANGE */),
            aliasedPointSize: getParameter(33901 /* ALIASED_POINT_SIZE_RANGE */),
            maxFragUniform: getParameter(36349 /* MAX_FRAGMENT_UNIFORM_VECTORS */),
            maxTextureCount: getParameter(34930 /* MAX_TEXTURE_IMAGE_UNITS */),
            maxTextureSize: getParameter(3379 /* MAX_TEXTURE_SIZE */),
            maxCubeMapTextureSize: getParameter(34076 /* MAX_CUBE_MAP_TEXTURE_SIZE */),
            maxCombinedTextureCount: getParameter(35661 /* MAX_COMBINED_TEXTURE_IMAGE_UNITS */),
            maxAnisotropy: getMaxAnisotropy(g),
            maxDrawBuffers: getMaxDrawBuffers(g),
            redBits: getParameter(3410 /* RED_BITS */),
            greenBits: getParameter(3411 /* GREEN_BITS */),
            blueBits: getParameter(3412 /* BLUE_BITS */),
            alphaBits: getParameter(3413 /* ALPHA_BITS */),
            depthBits: getParameter(3414 /* DEPTH_BITS */),
            stencilBits: getParameter(3415 /* STENCIL_BITS */),
            maxRenderBufferSize: getParameter(34024 /* MAX_RENDERBUFFER_SIZE */),
            maxViewportSize: getParameter(3386 /* MAX_VIEWPORT_DIMS */),
        };
    }
    jy.getWebGLCaps = getWebGLCaps;
})(jy || (jy = {}));
//# sourceMappingURL=WebGLCapabilities.js.map