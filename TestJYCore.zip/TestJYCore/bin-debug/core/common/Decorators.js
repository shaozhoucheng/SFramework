var jy;
(function (jy) {
    /**
     * 绑定属性名，当属性值发生改变时，可自动对外抛eventType事件
     *
     * @export
     * @param {Key} eventType     事件类型
     * @param {boolean} [selfDispatch]          默认false，使用Facade抛事件，event.data为实例本身
     *                                          如果为true，需要为EventDispatcher的实现，会使用自身抛事件
     * @returns
     */
    function d_fire(eventType, selfDispatch) {
        return function (host, property) {
            var data = host.getPropertyDescriptor(property);
            if (data && !data.configurable) {
                return true && jy.ThrowError("\u65E0\u6CD5\u7ED1\u5B9A" + host + "," + property + ",\u8BE5\u5C5E\u6027\u4E0D\u53EF\u8BBE\u7F6E");
            }
            var key = "$d_fire_e$" + property;
            var events = host[key];
            var needSet;
            if (!events) {
                host[key] = events = [];
                needSet = true;
            }
            events.push(eventType, selfDispatch);
            if (needSet) {
                if (data && data.set && data.get) {
                    var orgSet_1 = data.set;
                    data.set = function (value) {
                        if (this[property] != value) {
                            orgSet_1.call(this, value);
                            fire(this, events);
                        }
                    };
                }
                else if (!data || (!data.get && !data.set)) {
                    var newProp_1 = "$d_fire_p$" + property;
                    host[newProp_1] = data && data.value;
                    data = { enumerable: true, configurable: true };
                    data.get = function () {
                        return this[newProp_1];
                    };
                    data.set = function (value) {
                        if (this[newProp_1] != value) {
                            this[newProp_1] = value;
                            fire(this, events);
                        }
                    };
                }
                else {
                    return true && jy.ThrowError("\u65E0\u6CD5\u7ED1\u5B9A" + host + "," + property);
                }
                Object.defineProperty(host, property, data);
            }
        };
        function fire(host, events) {
            for (var i = 0; i < events.length; i += 2) {
                var eventType_1 = events[i];
                if (events[i + 1]) {
                    if (typeof host.dispatch === "function") {
                        host.dispatch(eventType_1);
                    }
                }
                else {
                    jy.dispatch(eventType_1, host);
                }
            }
        }
    }
    jy.d_fire = d_fire;
    /**
     * 使用微软vs code中使用的代码
     * 用于一些 lazy 的调用
     * https://github.com/Microsoft/vscode/blob/master/src/vs/base/common/decorators.ts
     *
     * @export
     * @param {*} target
     * @param {string} key
     * @param {*} descriptor
     */
    function d_memoize(target, key, descriptor) {
        var fnKey = null;
        var fn = null;
        if (typeof descriptor.value === 'function') {
            fnKey = 'value';
            fn = descriptor.value;
        }
        else if (typeof descriptor.get === 'function') {
            fnKey = 'get';
            fn = descriptor.get;
        }
        if (!fn) {
            throw new Error('not supported');
        }
        var memoizeKey = "$memoize$" + key;
        descriptor[fnKey] = function () {
            var args = [];
            for (var _i = 0; _i < arguments.length; _i++) {
                args[_i] = arguments[_i];
            }
            if (!this.hasOwnProperty(memoizeKey)) {
                Object.defineProperty(this, memoizeKey, {
                    configurable: false,
                    enumerable: false,
                    writable: false,
                    value: fn.apply(this, args)
                });
            }
            return this[memoizeKey];
        };
    }
    jy.d_memoize = d_memoize;
})(jy || (jy = {}));
//# sourceMappingURL=Decorators.js.map