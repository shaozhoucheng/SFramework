var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var jy;
(function (jy) {
    /**
     * 状态机
     * @author 3tion
     */
    var StateMachine = (function () {
        function StateMachine() {
            this.swis = {};
            this.liss = [];
            this._stas = [];
        }
        Object.defineProperty(StateMachine.prototype, "states", {
            /**
             * 获取当前已有的状态列表
             *
             * @readonly
             */
            get: function () {
                return this._stas;
            },
            enumerable: true,
            configurable: true
        });
        StateMachine.prototype.add = function (value) {
            if (!value) {
                true && jy.ThrowError("addStateListener没有设置正确!");
            }
            this.liss.pushOnce(value);
        };
        StateMachine.prototype.remove = function (value) {
            this.liss.remove(value);
        };
        StateMachine.prototype.addToStates = function () {
            var args = arguments;
            var value = args[0];
            if (!value) {
                true && jy.ThrowError("addToStateList没有设置正确!");
            }
            for (var i = 1; i < args.length; i++) {
                this.addToState(args[i], value);
            }
        };
        /**
         * 从所有状态中删除侦听;
         * @param value
         *
         */
        StateMachine.prototype.removeAllState = function (value) {
            if (!value) {
                return;
            }
            var states = this._stas;
            for (var i = 0; i < states.length; i++) {
                this.removeFromState(states[i], value);
            }
        };
        /**
         * 从单个状态中,删了一个具体侦听;
         * @param type
         * @param value
         * @return
         *
         */
        StateMachine.prototype.removeFromState = function (state, value) {
            var list = this.swis[state];
            return list && list.remove(value);
        };
        /**
         * 单个状态中加入一个侦听;
         * @param value
         * @param list
         *
         */
        StateMachine.prototype.addToState = function (state, value) {
            if (!value) {
                jy.ThrowError("addToState没有设置正确!");
            }
            var list = this.swis[state];
            if (list) {
                if (~list.indexOf(value))
                    return;
            }
            else {
                this.swis[state] = list = [];
                this._stas.push(state);
            }
            list.push(value);
            if (this.current == state) {
                value.awakeBy(this.current);
            }
        };
        /**
         *  清理状态机;
         *
         */
        StateMachine.prototype.clear = function () {
            this.swis = {};
            this.liss.length = 0;
            this.current = undefined;
        };
        /**
         * 设置当前的状态
         * @param value
         *
         */
        StateMachine.prototype.setState = function (value) {
            var old = this.current;
            if (old == value) {
                return;
            }
            this.current = value;
            var states = this.swis;
            var oldList = states[old];
            var newList = states[value];
            var newLen = newList && newList.length || 0;
            //新的开启
            if (this.checkBeforeSleep) {
                for (var i = 0; i < newLen; i++) {
                    var item = newList[i];
                    item.beforeLastSleep && item.beforeLastSleep(value);
                }
            }
            //旧的关闭
            if (oldList) {
                for (var i = 0; i < oldList.length; i++) {
                    var item = oldList[i];
                    if (!newList || !~newList.indexOf(item)) {
                        item.sleepBy && item.sleepBy(value);
                    }
                }
            }
            //新的开启
            for (var i = 0; i < newLen; i++) {
                var item = newList[i];
                item.awakeBy && item.awakeBy(value);
            }
            var aways = this.liss;
            if (aways) {
                for (var i = 0; i < aways.length; i++) {
                    aways[i].setState(value);
                }
            }
        };
        /**
         * 检查状态实现(switcher)是否添加到某个状态中
         *
         * @param {IStateSwitcher} switcher    某个状态实现
         * @param {Key} [type] 状态
         * @returns {boolean}
         */
        StateMachine.prototype.isInState = function (switcher, type) {
            type == void 0 && (type = this.current);
            var list = this.swis[type];
            if (list) {
                return list.indexOf(switcher) > -1;
            }
        };
        return StateMachine;
    }());
    jy.StateMachine = StateMachine;
    __reflect(StateMachine.prototype, "jy.StateMachine", ["jy.IStateListener"]);
})(jy || (jy = {}));
//# sourceMappingURL=StateMachine.js.map