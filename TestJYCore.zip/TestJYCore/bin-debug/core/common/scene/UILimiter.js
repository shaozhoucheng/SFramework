var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var jy;
(function (jy) {
    /**
    * 限制列队
    * @author 3tion
    */
    var LimitQueue = (function () {
        function LimitQueue() {
            this._queue = [];
            this.listener = new jy.StateMachine();
        }
        LimitQueue.prototype.addLimiter = function (item) {
            var queue = this._queue;
            if (queue.indexOf(item) > -1) {
                item.setState(this._current);
                queue.push(item);
                return true;
            }
        };
        /**
         * 设置状态
         * @param value
         *
         */
        LimitQueue.prototype.setState = function (value) {
            this._current = value;
            var queue = this._queue;
            if (queue) {
                for (var i = 0; i < queue.length; i++) {
                    var item = queue[i];
                    item.setState(value);
                }
            }
            var lm = this.listener;
            //查看是否有侦听状态变化的对像;
            if (lm) {
                lm.setState(value);
            }
        };
        LimitQueue.prototype.removeLimiter = function (item) {
            return this._queue.remove(item);
        };
        LimitQueue.prototype.clear = function () {
            this._queue.length = 0;
        };
        /**
         * 是否被限制了
         * @param type
         * @return
         *
         */
        LimitQueue.prototype.check = function (type) {
            var queue = this._queue;
            if (queue) {
                for (var i = 0; i < queue.length; i++) {
                    var limit = queue[i];
                    if (limit && limit.check(type)) {
                        return true;
                    }
                }
            }
        };
        return LimitQueue;
    }());
    jy.LimitQueue = LimitQueue;
    __reflect(LimitQueue.prototype, "jy.LimitQueue", ["jy.ILimit"]);
    /**
     * 像浏览器的历史记录;
     */
    var historys = [];
    var _currentState;
    jy.UILimiter = {
        impl: new LimitQueue(),
        MaxHistory: 5,
        get current() {
            return _currentState;
        },
        /**
         * 取得状态侦听管理器(以便注册关注的状态)
         * @return
         *
         */
        get listener() {
            return this.impl.listener;
        },
        enter: function (scene) {
            if (_currentState != scene) {
                _currentState = scene;
                this.impl.setState(scene);
                historys.push(scene);
                //只存5个历史记录;
                if (historys.length > this.MaxHistory) {
                    historys.shift();
                }
            }
        },
        /**
         * 退出
         *
         * @param {Key} [scene] 无法得到你当前切入的状态时,除非非常确定不会重复调用两次,否者不允许不传值
         * @returns
         */
        exit: function (scene) {
            scene = scene || _currentState;
            if (_currentState != scene) {
                return;
            }
            var len = historys.length;
            //弹出当前记录;
            historys.pop();
            //还原上一个记录;
            var last = len > 1 ? historys.pop() : 0 /* Default */;
            this.enter(last);
        },
        /**
         *
         * @param {Key} scene 被检查的Scene
         * @returns {boolean} 检查是否被限制 (true为被限制，false没有限制)
         */
        check: function (scene) {
            return this.impl.check(scene);
        }
    };
    function addToStates(value) {
        var ids = [];
        for (var _i = 1; _i < arguments.length; _i++) {
            ids[_i - 1] = arguments[_i];
        }
        (_a = jy.UILimiter.listener).addToStates.apply(_a, [value].concat(ids));
        var _a;
    }
    jy.addToStates = addToStates;
    function addToState(id, value) {
        jy.UILimiter.listener.addToState(id, value);
    }
    jy.addToState = addToState;
})(jy || (jy = {}));
//# sourceMappingURL=UILimiter.js.map