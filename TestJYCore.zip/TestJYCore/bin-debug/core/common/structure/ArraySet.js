var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var jy;
(function (jy) {
    /**
     * 使用数值或者字符串类型作为Key
     * V 作为Value的字典
     * 原生的map(ECMAScript5无Map)无法自定义列表顺序，而是完全按照加载顺序的，所以才需要有此类型
     * 列表存储Value
     * @author 3tion
     * @class ArraySet
     * @template V
     */
    var ArraySet = (function () {
        function ArraySet() {
            this._list = [];
            this._dict = {};
        }
        Object.defineProperty(ArraySet.prototype, "rawList", {
            /**
             * 获取原始列表，用于重新排序
             * 请不要直接进行 + - 值，使用set delete 方法进行处理
             * @readonly
             *
             */
            get: function () {
                return this._list;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(ArraySet.prototype, "rawDict", {
            /**
             * 获取原始的字典
             * 请不要直接行 + - 值，使用set delete 方法进行处理
             * @readonly
             *
             */
            get: function () {
                return this._dict;
            },
            enumerable: true,
            configurable: true
        });
        /**
         * 设置原始字典
         *
         * @param { [index: string]: V } dict
         *
         */
        ArraySet.prototype.setRawDict = function (dict) {
            this._dict = dict;
            var list = this._list;
            var i = 0;
            for (var key in dict) {
                list[i++] = dict[key];
            }
            list.length = i;
            return this;
        };
        /**
         *
         * @param {V[]} list        要放入的数据
         * @param {keyof V} keyPro   索引的属性名称
         *
         * 下例是一个形式为：{id:number,name:string}[]的数组，进行设值的例子
         * @example
         * let rawList:{id:number,name:string}[] = [{id:1,name:"test1"},{id:2,name:"test2"},{id:3,name:"test3"}];
         * let set = new ArraySet<{id:number,name:string}>();
         * set.setRawList(rawList,"id"); //设值操作
         *
         */
        ArraySet.prototype.setRawList = function (list, keyPro) {
            var rawList = this._list;
            var dict = this._dict = {};
            var i = 0;
            if (list) {
                for (var len = list.length; i < len; i++) {
                    var item = list[i];
                    dict[item[keyPro]] = item;
                    rawList[i] = item;
                }
            }
            rawList.length = i;
            return this;
        };
        /**
         *
         * 设置数据
         *
         * @param {Key} key
         * @param {V} value
         * @return {number} 返回值加入到数据中的索引
         */
        ArraySet.prototype.set = function (key, value) {
            var _a = this, _dict = _a._dict, _list = _a._list;
            var idx;
            var changed;
            if (key in _dict) {
                var old = _dict[key];
                idx = _list.indexOf(old);
                if (old != value) {
                    changed = true;
                }
            }
            else {
                idx = _list.length;
                changed = true;
            }
            if (changed) {
                _list[idx] = value;
                _dict[key] = value;
            }
            return idx;
        };
        /**
         * 获取数据
         *
         * @param {Key} key
         * @returns
         *
         */
        ArraySet.prototype.get = function (key) {
            return this._dict[key];
        };
        /**
         * 根据key移除数据
         *
         * @param {Key} key
         *
         */
        ArraySet.prototype.delete = function (key) {
            var _a = this, _dict = _a._dict, _list = _a._list;
            var old = _dict[key];
            delete _dict[key];
            if (old) {
                var idx = _list.indexOf(old);
                if (idx > -1) {
                    _list.splice(idx, 1);
                }
            }
            return old;
        };
        /**
         * 清理数据
         *
         *
         */
        ArraySet.prototype.clear = function () {
            this._list.length = 0;
            this._dict = {};
        };
        Object.defineProperty(ArraySet.prototype, "size", {
            /**
             * 获取总长度
             *
             * @readonly
             *
             */
            get: function () {
                return this._list.length;
            },
            enumerable: true,
            configurable: true
        });
        return ArraySet;
    }());
    jy.ArraySet = ArraySet;
    __reflect(ArraySet.prototype, "jy.ArraySet");
})(jy || (jy = {}));
//# sourceMappingURL=ArraySet.js.map