var jy;
(function (jy) {
    ;
})(jy || (jy = {}));
//# sourceMappingURL=GeomDefine.js.map