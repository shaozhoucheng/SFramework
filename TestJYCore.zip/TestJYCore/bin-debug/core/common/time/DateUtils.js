var jy;
(function (jy) {
    /**
     * 时间处理函数
     * DateUtils
     */
    var _sharedDate = new Date();
    /**
     * 获取运行时间
     * 此时间为进程运行时间，不会随着调整系统时间而变动
     */
    var getTimer = window.performance ? function () { return ~~performance.now(); } : Date.now;
    var _defaultCountFormats;
    /**
     * 基于UTC的时间偏移
     *
     * @private
     * @static
     * @type {number}
     */
    var _utcOffset = -_sharedDate.getTimezoneOffset() * 60000 /* ONE_MINUTE */; //默认使用当前时区，防止一些报错
    /**
     * 服务器UTC偏移后的基准时间
     *
     * @private
     * @static
     * @type {number}
     */
    var _serverUTCTime = _utcOffset; //默认使用本地时间
    jy.DateUtils = {
        /**
         * 获取共享时间
         */
        get sharedDate() {
            return _sharedDate;
        },
        getDefaultCDFOption: getDefaultCDFOption,
        regCDFormat: function (format, opt) {
            initDefaultCDFormats();
            _defaultCountFormats[format] = opt;
        },
        initServerTime: function (time, timezoneOffset) {
            _utcOffset = -timezoneOffset * 60000 /* ONE_MINUTE */;
            this.setServerTime(time);
        },
        setServerTime: function (time) {
            _serverUTCTime = time - getTimer() + _utcOffset;
        },
        get utcServerTime() {
            return _serverUTCTime + getTimer();
        },
        get serverTime() {
            return this.utcServerTime - _utcOffset;
        },
        get utcServerDate() {
            _sharedDate.setTime(this.utcServerTime);
            return _sharedDate;
        },
        get serverDate() {
            _sharedDate.setTime(this.serverTime);
            return _sharedDate;
        },
        getFormatTime: function (time, format, isRaw) {
            if (isRaw === void 0) { isRaw = true; }
            if (isRaw) {
                time = this.getUTCTime(time);
            }
            _sharedDate.setTime(time);
            return _sharedDate.format(format);
        },
        getDayEnd: function (time) {
            if (time === undefined)
                time = this.serverTime;
            _sharedDate.setTime(time);
            return _sharedDate.setHours(23, 59, 59, 999);
        },
        getUTCDayEnd: function (utcTime) {
            if (utcTime === undefined)
                utcTime = this.utcServerTime;
            _sharedDate.setTime(utcTime);
            return _sharedDate.setUTCHours(23, 59, 59, 999);
        },
        getDayStart: function (time) {
            if (time === undefined)
                time = jy.DateUtils.serverTime;
            _sharedDate.setTime(time);
            return _sharedDate.setHours(0, 0, 0, 0);
        },
        getUTCDayStart: function (utcTime) {
            if (utcTime === undefined)
                utcTime = jy.DateUtils.utcServerTime;
            _sharedDate.setTime(utcTime);
            return _sharedDate.setUTCHours(0, 0, 0, 0);
        },
        /**
         * 将服务器有偏移量的时间戳，转换成显示时间相同的UTC时间戳，用于做显示
         *
         * @static
         * @param {number} time 正常的时间戳
         * @returns {number} UTC偏移后的时间戳
         */
        getUTCTime: function (time) {
            return time + _utcOffset;
        },
        getDayCount: function (startTime, endTime) {
            endTime = jy.DateUtils.getDayStart(endTime);
            return Math.ceil((endTime - startTime) / 86400000 /* ONE_DAY */) + 1;
        },
        getUTCDayCount: function (startTime, endTime) {
            endTime = jy.DateUtils.getUTCDayStart(endTime);
            return Math.ceil((endTime - startTime) / 86400000 /* ONE_DAY */) + 1;
        },
        /**
         * 显示倒计时
         *
         * @static
         * @param {number} leftTime 剩余时间
         * @param {CountDownFormatOption} format 倒计时修饰符，
         * format 示例：{d:"{0}天",h:"{0}小时",m:"{0}分",s:"{0}秒"}
         */
        getCountdown: function (leftTime, format) {
            if (typeof format === "number") {
                format = getDefaultCDFOption(format);
            }
            var out = "";
            var tmp = format.d;
            if (tmp) {
                var day = leftTime / 86400000 /* ONE_DAY */ >> 0;
                leftTime = leftTime - day * 86400000 /* ONE_DAY */;
                out += tmp.substitute(day);
            }
            tmp = format.h;
            if (tmp) {
                var hour = leftTime / 3600000 /* ONE_HOUR */ >> 0;
                leftTime = leftTime - hour * 3600000 /* ONE_HOUR */;
                if (format.hh) {
                    hour = hour.zeroize(2);
                }
                out += tmp.substitute(hour);
            }
            tmp = format.m;
            if (tmp) {
                var minute = leftTime / 60000 /* ONE_MINUTE */ >> 0;
                leftTime = leftTime - minute * 60000 /* ONE_MINUTE */;
                if (format.mm) {
                    minute = minute.zeroize(2);
                }
                out += tmp.substitute(minute);
            }
            tmp = format.s;
            if (tmp) {
                var second = leftTime / 1000 /* ONE_SECOND */ >> 0;
                if (format.ss) {
                    second = second.zeroize(2);
                }
                out += tmp.substitute(second);
            }
            return out;
        }
    };
    /**
     * CountDownFormat
     * 获取默认的`倒计时`格式
        $_ndays	{0}天
        $_nhours	{0}小时
        $_nminutes	{0}分钟
        $_nsecends	{0}秒

     * @static
     * @param {CountDownFormat} format
     * @returns {CountDownFormatOption}
     *
     * @memberOf DateUtils
     */
    function getDefaultCDFOption(format) {
        if (initDefaultCDFormats()) {
            jy.DateUtils.getDefaultCDFOption = _getDefaultCDFOption;
        }
        return _getDefaultCDFOption(format);
        function _getDefaultCDFOption(format) {
            return _defaultCountFormats[format];
        }
    }
    function initDefaultCDFormats() {
        if (!_defaultCountFormats) {
            var LangUtil_1 = jy.LangUtil;
            _defaultCountFormats = (_a = {},
                _a[0 /* D_H_M_S */] = { d: LangUtil_1.getMsg("$_ndays"), h: LangUtil_1.getMsg("$_nhours"), m: LangUtil_1.getMsg("$_nminutes"), s: LangUtil_1.getMsg("$_nsecends") },
                _a[1 /* H_M_S */] = { h: LangUtil_1.getMsg("$_nhours"), m: LangUtil_1.getMsg("$_nminutes"), s: LangUtil_1.getMsg("$_nsecends") },
                _a[2 /* H_M */] = { h: LangUtil_1.getMsg("$_nhours"), m: LangUtil_1.getMsg("$_nminutes") },
                _a[3 /* M_S */] = { m: LangUtil_1.getMsg("$_nminutes"), s: LangUtil_1.getMsg("$_nsecends") },
                _a[4 /* S */] = { s: LangUtil_1.getMsg("$_nsecends") },
                _a);
            return true;
        }
        var _a;
    }
})(jy || (jy = {}));
//# sourceMappingURL=DateUtils.js.map