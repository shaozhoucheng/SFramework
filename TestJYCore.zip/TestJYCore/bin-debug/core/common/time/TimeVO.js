var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var jy;
(function (jy) {
    /**
     * 解析数据
     *
     * @private
     * @param {number} hour
     * @param {number} minute
     * @returns
     */
    function _decode(_this, hour, minute) {
        _this.hour = hour;
        _this.minute = minute;
        _this.time = hour * 3600000 /* ONE_HOUR */ + minute * 60000 /* ONE_MINUTE */;
        _this.strTime = hour.zeroize(2) + ":" + minute.zeroize(2);
        return _this;
    }
    /**
     * TimveVO
     */
    var TimeVO = (function () {
        function TimeVO(timeStr) {
            if (timeStr) {
                this.decode(timeStr);
            }
        }
        /**
         * 从分钟进行解析
         *
         * @param {number} minutes 分钟数
         */
        TimeVO.prototype.decodeMinutes = function (minutes) {
            return _decode(this, minutes / 60 | 0, minutes % 60);
        };
        /**
         * 从一个数值进行序列化
         * decodeMinutes和decodeBit，如果使用protobuf writeVarint32 存储，时间只要超过 02:08，不管如何使用何种方式，一定会超过2字节，而 23:59，不管怎么存储，都不会超过2字节
         * decodeBit解析比 decodeMinutes更加快捷
         * 而 hour<<6|minute  解析会更简单，快速
         * @param {number} value
         */
        TimeVO.prototype.decodeBit = function (value) {
            return _decode(this, value >> 6, value & 63);
        };
        /**
         * 从字符串中解析
         *
         * @param {number} strTime 通过解析器解析的数据
         */
        TimeVO.prototype.decode = function (strTime) {
            var timeArr = strTime.split(":");
            if (timeArr.length >= 2) {
                return _decode(this, +timeArr[0], +timeArr[1]);
            }
            else {
                jy.ThrowError("时间格式不正确，不为HH:mm格式，当前配置：" + strTime);
            }
        };
        Object.defineProperty(TimeVO.prototype, "todayTime", {
            /**
            * 获取今日的服务器时间
            *
            * @readonly
            * @memberOf TimeVO
            */
            get: function () {
                return this.getDayTime();
            },
            enumerable: true,
            configurable: true
        });
        /**
         * 获取指定时间戳那天的时间
         *
         * @param {number} [day]
         * @param {boolean} [isUTC]
         * @returns
         * @memberof TimeVO
         */
        TimeVO.prototype.getDayTime = function (day, isUTC) {
            var dayStart = isUTC ? jy.DateUtils.getDayStart : jy.DateUtils.getDayStart;
            return dayStart(day) + this.time;
        };
        return TimeVO;
    }());
    jy.TimeVO = TimeVO;
    __reflect(TimeVO.prototype, "jy.TimeVO");
})(jy || (jy = {}));
//# sourceMappingURL=TimeVO.js.map