var jy;
(function (jy) {
    function getData(valueList, keyList, o) {
        o = o || {};
        for (var i = 0, len = keyList.length; i < len; i++) {
            var key = keyList[i];
            var v = valueList[i];
            if (v != undefined) {
                o[key] = valueList[i];
            }
        }
        return o;
    }
    function copyData(to, valueList, keyList) {
        for (var i = 0, len = keyList.length; i < len; i++) {
            var key = keyList[i];
            to[key] = valueList[i];
        }
    }
    /**
     *
     * @author 君游项目解析工具
     *
     */
    jy.DataUtils = {
        parseDatas: function (to, from, checkStart, checkEnd, dataKey, toDatasKey) {
            var arr = [];
            for (var i = checkStart, j = 0; i <= checkEnd; i++) {
                var key = dataKey + i;
                if (key in from) {
                    arr[j++] = from[key];
                }
            }
            to[toDatasKey] = arr;
        },
        parseDatas2: function (to, valueList, keyList, checkStart, checkEnd, dataKey, toDatasKey) {
            var arr = [];
            for (var i = checkStart, j = 0; i <= checkEnd; i++) {
                var key = dataKey + i;
                var idx = keyList.indexOf(key);
                if (~idx) {
                    arr[j++] = valueList[idx];
                }
            }
            to[toDatasKey] = arr;
        },
        getData: getData,
        getDataList: function (dataList, keyList) {
            var list = [];
            if (dataList) {
                for (var i = 0, len = dataList.length; i < len; i++) {
                    var valueList = dataList[i];
                    list.push(getData(valueList, keyList));
                }
            }
            return list;
        },
        parseDataList: function (dataList, keyList, forEach, thisObj) {
            var args = [];
            for (var _i = 4; _i < arguments.length; _i++) {
                args[_i - 4] = arguments[_i];
            }
            if (dataList) {
                for (var i = 0, len = dataList.length; i < len; i++) {
                    var valueList = dataList[i];
                    var to = getData(valueList, keyList);
                    forEach.call(thisObj, to, args, i);
                }
            }
        },
        copyData: copyData,
        copyDataList: function (creator, dataList, keyList, forEach, thisObj) {
            var args = [];
            for (var _i = 5; _i < arguments.length; _i++) {
                args[_i - 5] = arguments[_i];
            }
            if (dataList) {
                for (var i = 0, len = dataList.length; i < len; i++) {
                    var valueList = dataList[i];
                    var to = new creator();
                    copyData(to, valueList, keyList);
                    forEach.call(thisObj, to, args, i);
                }
            }
        },
    };
})(jy || (jy = {}));
//# sourceMappingURL=DataUtils.js.map