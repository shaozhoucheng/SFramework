/**
 * DataLocator的主数据
 * 原 junyou.DataLocator.data  的全局别名简写
 */
var $DD = {};
/**
 * DataLocator的附加数据
 * 原junyou.DataLocator.extra 的全局别名简写
 */
var $DE;
var jy;
(function (jy) {
    var parsers = {};
    /**
     *
     * 用于处理顺序
     * @private
     * @static
     */
    var _plist = [];
    /**
     * 配置加载器<br/>
     * 用于预加载数据的解析
     * @author 3tion
     *
     */
    jy.DataLocatorT = {
        regParser: regParser,
        /**
         * 解析打包的配置
         */
        parsePakedDatas: function (type) {
            var configs = jy.Res.get("cfgs");
            jy.Res.remove("cfgs");
            if (type == 1) {
                configs = decodePakCfgs(new jy.ByteArray(configs));
            }
            // 按顺序解析
            for (var _i = 0, _plist_1 = _plist; _i < _plist_1.length; _i++) {
                var key = _plist_1[_i];
                var parser = parsers[key];
                var data = parser(configs[key]);
                if (data) {
                    $DD[key] = data;
                    jy.dispatch(-185 /* OneCfgComplete */, key);
                }
            }
            var extraData = {};
            //处理额外数据
            for (var key in configs) {
                if (key.charAt(0) == "$") {
                    var raw = configs[key];
                    key = key.substr(1);
                    if (raw) {
                        var i = 0, len = raw.length, data = {};
                        while (i < len) {
                            var sub = raw[i++];
                            var value = raw[i++];
                            var test = raw[i];
                            if (typeof test === "number") {
                                i++;
                                value = getJSONValue(value, test);
                            }
                            data[sub] = value;
                        }
                        extraData[key] = data;
                    }
                }
            }
            $DE = extraData;
            //清理内存
            parsers = null;
            _plist = null;
            delete jy.DataLocator;
        },
        /**
         *
         * 注册通过H5ExcelTool导出的数据并且有唯一标识的使用此方法注册
         * @param {keyof CfgData} key 数据的标识
         * @param {(Creator<any> | 0)} CfgCreator 配置的类名
         * @param {(string | 0)} [idkey="id"] 唯一标识 0用于标识数组
         * @param {CfgDataType} [type]
         */
        regCommonParser: regCommonParser,
        regBytesParser: regBytesParser
    };
    /**
     *
     * 注册通过H5ExcelTool导出的数据并且有唯一标识的使用此方法注册
     * @param {keyof CfgData} key 数据的标识
     * @param {(Creator<any> | 0)} CfgCreator 配置的类名
     * @param {(string | 0)} [idkey="id"] 唯一标识 0用于标识数组
     * @param {CfgDataType} [type]
     */
    function regCommonParser(key, CfgCreator, idkey, type) {
        if (idkey === void 0) { idkey = "id"; }
        regParser(key, function (data) {
            if (!data)
                return;
            var dict, forEach;
            var headersRaw = data[0];
            var hasLocal;
            for (var j = 0; j < headersRaw.length; j++) {
                var head = headersRaw[j];
                if ((head[2] & 2 /* Local */) == 2 /* Local */) {
                    hasLocal = 1;
                }
            }
            (_a = getParserOption(idkey, type), type = _a[0], dict = _a[1], forEach = _a[2]);
            try {
                var ref = CfgCreator || Object;
                for (var i = 1; i < data.length; i++) {
                    var rowData = data[i];
                    var ins = new ref();
                    var local = hasLocal && {};
                    for (var j = 0; j < headersRaw.length; j++) {
                        var head = headersRaw[j];
                        var name_1 = head[0], test = head[1], type_1 = head[2], def = head[3];
                        var v = getJSONValue(rowData[j], test, def);
                        if ((type_1 & 2 /* Local */) == 2 /* Local */) {
                            local[name_1] = v;
                        }
                        else {
                            ins[name_1] = v;
                        }
                    }
                    forEach(ins, i - 1, key, dict, idkey);
                    if (typeof ins.decode === "function") {
                        ins.decode(local);
                    }
                }
                if (type == 1 /* ArraySet */) {
                    dict = new jy.ArraySet().setRawList(dict, idkey);
                }
            }
            catch (e) {
                if (true) {
                    jy.ThrowError("\u89E3\u6790\u914D\u7F6E:" + key + "\u51FA\u9519", e);
                }
            }
            return dict;
            var _a;
        });
    }
    /**
     * 注册配置解析
     * @param key       配置的标识
     * @param parser    解析器
     */
    function regParser(key, parser) {
        parsers[key] = parser;
        _plist.push(key);
    }
    function getJSONValue(value, type, def) {
        // 特殊类型数据
        switch (type) {
            case 0 /* Any */:
                if (value == null) {
                    value = def;
                }
                break;
            case 1 /* String */:
                if (value === 0 || value == null) {
                    value = def || "";
                }
                break;
            case 2 /* Number */:
            case 9 /* Int32 */:
                // 0 == "" // true
                if (value === "" || value == null) {
                    value = +def || 0;
                }
                break;
            case 3 /* Bool */:
                if (value == null) {
                    value = def;
                }
                value = !!value;
                break;
            case 4 /* Array */:
            case 5 /* Array2D */:
                if (value === 0) {
                    value = undefined;
                }
                if (!value && def) {
                    value = def;
                }
                break;
            case 6 /* Date */:
            case 8 /* DateTime */:
                value = new Date((value || def || 0) * 10000);
                break;
            case 7 /* Time */:
                value = new jy.TimeVO().decodeBit(value || def || 0);
                break;
        }
        return value;
    }
    /**
     * 用于解析数组
     *
     * @memberOf DataLocator
     */
    function arrayParserForEach(t, idx, key, dict) {
        dict.push(t);
    }
    /**
     * 用于解析字典
     */
    function commonParserForEach(t, idx, key, dict, idKey) {
        if (idKey in t) {
            var id = t[idKey];
            if (true) {
                if (typeof id === "object") {
                    jy.Log("\u914D\u7F6E" + key + "\u7684\u6570\u636E\u6709\u8BEF\uFF0C\u552F\u4E00\u6807\u8BC6" + idKey + "\u4E0D\u80FD\u4E3A\u5BF9\u8C61");
                }
                if (id in dict) {
                    jy.Log("\u914D\u7F6E" + key + "\u7684\u6570\u636E\u6709\u8BEF\uFF0C\u552F\u4E00\u6807\u8BC6" + idKey + "\u6709\u91CD\u590D\u503C\uFF1A" + id);
                }
            }
            dict[id] = t;
        }
        else if (true) {
            jy.Log("\u914D\u7F6E" + key + "\u89E3\u6790\u6709\u8BEF\uFF0C\u65E0\u6CD5\u627E\u5230\u6307\u5B9A\u7684\u552F\u4E00\u6807\u793A\uFF1A" + idKey + "\uFF0C\u6570\u636E\u7D22\u5F15\uFF1A" + idx);
        }
    }
    var CfgHeadStruct = {
        1: [0, 2 /* Required */, 9 /* String */] /*必有 属性名字*/,
        2: [1, 2 /* Required */, 14 /* Enum */] /*必有 数值的数据类型*/,
        3: [2, 1 /* Optional */, 14 /* Enum */] /*可选 此列的状态*/,
        4: [3, 1 /* Optional */, 17 /* SInt32 */] /*可选 bool / int32 型默认值 */,
        5: [4, 1 /* Optional */, 1 /* Double */] /*可选 double 型默认值 */,
        6: [5, 1 /* Optional */, 9 /* String */] /*可选 字符串型默认值 */
    };
    jy.PBUtils.initDefault(CfgHeadStruct);
    //配置数据 打包的文件结构数据
    //readUnsignedByte 字符串长度 readString 表名字 readUnsignedByte 配置类型(0 PBBytes 1 JSON字符串) readVarint 数据长度
    function decodePakCfgs(buffer) {
        var cfgs = {};
        while (buffer.readAvailable) {
            var len = buffer.readUnsignedByte();
            var key = buffer.readUTFBytes(len); //得到表名
            var type = buffer.readUnsignedByte();
            var value = void 0;
            len = buffer.readVarint();
            switch (type) {
                case 0://JSON字符串
                    var str = buffer.readUTFBytes(len);
                    value = JSON.parse(str);
                    break;
                case 1://PBBytes
                    value = buffer.readByteArray(len);
                    break;
            }
            cfgs[key] = value;
        }
        return cfgs;
    }
    function getParserOption(idkey, type) {
        if (idkey === void 0) { idkey = "id"; }
        var dict, forEach;
        if (idkey == "" || idkey == 0) {
            type = 2 /* Array */;
        }
        else if (!type) {
            type = 3 /* Dictionary */;
        }
        switch (type) {
            case 2 /* Array */:
            case 1 /* ArraySet */:
                dict = [];
                forEach = arrayParserForEach;
                break;
            case 3 /* Dictionary */:
                dict = {};
                forEach = commonParserForEach;
                break;
        }
        return [type, dict, forEach];
    }
    /**
     * 通用的Bytes版本的配置解析器
     * @param buffer
     */
    function regBytesParser(key, CfgCreator, idkey, type) {
        if (idkey === void 0) { idkey = "id"; }
        regParser(key, function (bytes) {
            if (!bytes) {
                return;
            }
            var dict, forEach;
            (_a = getParserOption(idkey, type), type = _a[0], dict = _a[1], forEach = _a[2]);
            try {
                var struct = {};
                var headersRaw = [];
                var i = 0;
                var count = bytes.readVarint(); //头的数量
                var hasLocal = void 0;
                while (bytes.readAvailable && count--) {
                    var len = bytes.readVarint();
                    var head = jy.PBUtils.readFrom(CfgHeadStruct, bytes, len);
                    var name_2 = head[0], headType = head[1], headState = head[2], i32Def = head[3], dblDef = head[4], strDef = head[5];
                    var def = void 0, isJSON = 0, pbType = void 0;
                    switch (headType) {
                        case 0 /* Any */:
                        case 1 /* String */:
                            def = strDef;
                            pbType = 9 /* String */;
                            break;
                        case 2 /* Number */:
                            def = dblDef;
                            pbType = 1 /* Double */;
                            break;
                        case 3 /* Bool */:
                        case 9 /* Int32 */:
                        case 6 /* Date */:
                        case 7 /* Time */:
                        case 8 /* DateTime */:
                            def = i32Def;
                            pbType = 17 /* SInt32 */;
                            break;
                        case 4 /* Array */:
                        case 5 /* Array2D */:
                            if (strDef) {
                                def = JSON.parse(strDef);
                            }
                            pbType = 9 /* String */;
                            isJSON = 1;
                            break;
                    }
                    struct[i + 1] = [name_2, 1 /* Optional */, pbType, def];
                    head.length = 5;
                    head[3] = def;
                    head[4] = isJSON;
                    headersRaw[i++] = head;
                    if ((headState & 2 /* Local */) == 2 /* Local */) {
                        hasLocal = 1;
                    }
                }
                jy.PBUtils.initDefault(struct, CfgCreator);
                var headLen = i;
                i = 0;
                count = bytes.readVarint(); //行的数量
                while (bytes.readAvailable && count--) {
                    var len = bytes.readVarint();
                    var obj = jy.PBUtils.readFrom(struct, bytes, len);
                    if (!obj) {
                        continue;
                    }
                    var local = hasLocal && {};
                    for (var j = 0; j < headLen; j++) {
                        var head = headersRaw[j];
                        var name_3 = head[0], test = head[1], type_2 = head[2], def = head[3], isJSON = head[4];
                        var value = obj[name_3];
                        if (value && isJSON) {
                            value = JSON.parse(value);
                        }
                        var v = getJSONValue(value, test, def);
                        if ((type_2 & 2 /* Local */) == 2 /* Local */) {
                            local[name_3] = v;
                        }
                        else {
                            obj[name_3] = v;
                        }
                    }
                    forEach(obj, i++, key, dict, idkey);
                    if (typeof obj.decode === "function") {
                        obj.decode(local);
                    }
                }
                if (type == 1 /* ArraySet */) {
                    dict = new jy.ArraySet().setRawList(dict, idkey);
                }
            }
            catch (e) {
                if (true) {
                    jy.ThrowError("\u89E3\u6790\u914D\u7F6E:" + key + "\u51FA\u9519\uFF0C\u8BF7\u91CD\u65B0\u6253\u5305\u914D\u7F6E", e, true);
                }
            }
            return dict;
            var _a;
        });
    }
})(jy || (jy = {}));
//# sourceMappingURL=DataLocator.js.map