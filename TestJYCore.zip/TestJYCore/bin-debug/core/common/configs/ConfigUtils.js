var jy;
(function (jy) {
    /**
     * 资源的 版本字典
     */
    var _hash = {};
    /**
     * 配置数据
     */
    var _data;
    /**
     * 注册的皮肤路径
     * key      {string}   皮肤的key
     * value    {Path}    皮肤实际路径地址
     */
    var _regedSkinPath = {};
    var getPrefix;
    var _res;
    /**
     * 获取皮肤路径
     *
     * @param {string} key
     * @param {string} fileName
     * @returns
     */
    function getSkinPath(key, fileName) {
        return key + "/" + fileName;
    }
    /**
     * 通过Path获取完整url
     *
     * @private
     * @static
     * @param {string} uri 路径标识
     * @param {Path} path Path对象
     * @returns
     */
    function getUrlWithPath(uri, path) {
        if (!path || /^((http|https):)?\/\//.test(uri)) {
            return uri;
        }
        uri = path.tPath + uri;
        var prefix = path.iPrefix ? "" : getPrefix(uri);
        return prefix + uri;
    }
    /**
     * 根据uri缓存url的字典
     */
    var uriDict = {};
    /**
     * 获取资源版本号
     * @param uri
     */
    function getResVer(uri) {
        return ~~(_hash && _hash[uri.hash()]);
    }
    /**
     * 配置工具
     * @author 3tion
     * @export
     * @class ConfigUtils
     */
    jy.ConfigUtils = {
        setData: function (data) {
            _data = data;
            !_data.params && (_data.params = {});
            //检查路径是否存在有路径有父路径的，如果有，进行预处理
            var paths = _data.paths;
            for (var key in paths) {
                var p = paths[key];
                p.tPath = getPath(p);
            }
            _res = _data.paths.res;
            //检查前缀
            getPrefix = (function (prefixes) {
                var len = 0;
                if (prefixes) {
                    len = prefixes.length;
                }
                switch (len) {
                    case 0:
                        return function (uri) { return ""; };
                    case 1: {
                        var prefix_1 = prefixes[0];
                        return function (uri) { return prefix_1; };
                    }
                    default:
                        return function (uri) {
                            var idx = uri.hash() % prefixes.length;
                            return prefixes[idx] || "";
                        };
                }
            })(_data.prefixes);
            function getPath(p) {
                var parentKey = p.parent;
                if (parentKey) {
                    var parent_1 = paths[parentKey];
                    if (parent_1) {
                        return getPath(parent_1) + p.path;
                    }
                    else if (true) {
                        jy.ThrowError("\u8DEF\u5F84[" + p.path + "]\u914D\u7F6E\u4E86\u7236\u7EA7(parent)\uFF0C\u4F46\u662F\u627E\u4E0D\u5230\u5BF9\u5E94\u7684\u7236\u7EA7");
                    }
                }
                return p.path;
            }
        },
        /**
         * 解析版本控制文件
         * @param {ArrayBufferLike} hash
         */
        parseHash: function (hash) {
            var dv = new DataView(hash);
            var pos = 0;
            var len = dv.byteLength;
            _hash = {};
            while (pos < len) {
                var hash_1 = dv.getUint32(pos);
                pos += 4 /* SIZE_OF_UINT32 */;
                var version = dv.getUint16(pos);
                pos += 2 /* SIZE_OF_UINT16 */;
                _hash[hash_1] = version;
            }
            jy.dispatch(-188 /* ParseResHash */);
        },
        /**
         * 设置版本控制文件
         * @param hash
         */
        setHash: function (hash) {
            _hash = hash;
        },
        getResVer: getResVer,
        /**
         * 获取资源完整路径
         *
         * @static
         * @param {string} uri                  路径标识
         * @returns {string}
         */
        getResUrl: function (uri) {
            var url = uriDict[uri];
            if (!url) {
                var ver = getResVer(uri);
                if (ver) {
                    if (uri.indexOf("?") == -1) {
                        uri = uri + "?" + ver;
                    }
                    else {
                        uri = uri + "&jyver=" + ver;
                    }
                }
                url = getUrlWithPath(uri, _res);
                uriDict[uri] = url;
            }
            return url;
        },
        /**
         * 获取参数
         */
        getParam: function (key) {
            return _data.params[key];
        },
        getSkinPath: getSkinPath,
        /**
         * 获取皮肤文件地址
         */
        getSkinFile: function (key, fileName) {
            return getUrlWithPath(getSkinPath(key, fileName), _regedSkinPath[key] || _data.paths.skin);
        },
        /**
         * 设置皮肤路径
         * 如 `lib` 原本应该放在当前项目  resource/skin/ 目录下
         * 现在要将`lib`的指向改到  a/ 目录下
         * 则使用下列代码
         * ```typescript
         * ConfigUtils.regSkinPath("lib","a/");
         * ```
         * 如果要将`lib`的指向改到 http://www.xxx.com/a/下
         * 则使用下列代码
         * ```typescript
         * ConfigUtils.regSkinPath("lib","http://www.xxx.com/a/",true);
         * ```
         * 如果域名不同，`自行做好跨域策略CROS`
         *
         * @param {string} key
         * @param {string} path
         * @param {boolean} [iPrefix] 是否忽略皮肤前缀
         */
        regSkinPath: function (key, path, iPrefix) {
            _regedSkinPath[key] = { tPath: path, path: path, iPrefix: iPrefix };
        },
        /**
         * 获取路径
         *
         * @param {string} uri
         * @param {string} pathKey
         * @returns
         */
        getUrl: function (uri, pathKey) {
            var path = _data.paths[pathKey];
            if (path) {
                return getUrlWithPath(uri, path);
            }
        }
    };
})(jy || (jy = {}));
//# sourceMappingURL=ConfigUtils.js.map