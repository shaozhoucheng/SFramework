var jy;
(function (jy) {
    /**
     * 扩展一个实例，如果A类型实例本身并没有B类型的方法，则直接对实例的属性进行赋值，否则将不会赋值
     *
     * @export
     * @template A
     * @template B
     * @param {A} instance                  要扩展的实例
     * @param {{ prototype: B }} clazzB     需要扩展的对象方法
     * @param {boolean} override            是否强制覆盖原有方法
     * @returns {(A & B)}
     */
    function expandInstance(instance, clazzB) {
        var keys = [];
        for (var _i = 2; _i < arguments.length; _i++) {
            keys[_i - 2] = arguments[_i];
        }
        var bpt = clazzB.prototype;
        for (var _a = 0, _b = Object.getOwnPropertyNames(bpt); _a < _b.length; _a++) {
            var name_1 = _b[_a];
            if (!keys || ~keys.indexOf(name_1)) {
                var define = bpt.getPropertyDescriptor(name_1);
                if (define) {
                    Object.defineProperty(instance, name_1, define);
                }
                else {
                    instance[name_1] = bpt[name_1];
                }
            }
        }
        return instance;
    }
    jy.expandInstance = expandInstance;
    /**
     * 将类型A扩展类型B的指定属性，并返回引用
     *
     * @export
     * @template A
     * @template B
     * @template K
     * @template B
     * @param {{ prototype: A }} clazzA     要被扩展的类型
     * @param {{ prototype: B }} clazzB     扩展的模板，已经模板的父类型也会作为模板
     * @param {...K[]} keys      如果没有参数，则将B的全部属性复制给类型A
     * @returns {(A & Record<K, B>)}
     */
    function expand(clazzA, clazzB) {
        var keys = [];
        for (var _i = 2; _i < arguments.length; _i++) {
            keys[_i - 2] = arguments[_i];
        }
        _expand(clazzA.prototype, clazzB.prototype, keys);
        return clazzA;
    }
    jy.expand = expand;
    function _expand(pt, bpt, keys) {
        for (var _i = 0, _a = Object.getOwnPropertyNames(bpt); _i < _a.length; _i++) {
            var name_2 = _a[_i];
            if (!keys || ~keys.indexOf(name_2)) {
                if (!(name_2 in pt)) {
                    pt[name_2] = bpt[name_2];
                }
            }
        }
        var sup = Object.getPrototypeOf(bpt);
        if (sup) {
            return _expand(pt, sup, keys);
        }
    }
    /**
     * 获取一个复合类型
     *
     * @export
     * @template A
     * @template B
     * @param {{ prototype: A }} clazzA     类型A
     * @param {{ prototype: B }} clazzB     类型B
     * @returns
     */
    function getMixin(clazzA, clazzB) {
        var merged = function () { };
        if (Object.assign) {
            Object.assign(merged.prototype, clazzA.prototype, clazzB.prototype);
        }
        else {
            merged = expand(merged, clazzA);
            merged = expand(merged, clazzB);
        }
        return merged;
    }
    jy.getMixin = getMixin;
    /**
     * 拷贝属性
     *
     * @export
     * @template To
     * @template From
     * @param {To} to
     * @param {From} from
     * @param {keyof B} key
     */
    function copyProperty(to, from, key) {
        Object.defineProperty(to, key, Object.getOwnPropertyDescriptor(from, key));
    }
    jy.copyProperty = copyProperty;
    /**
     * 批量拷贝属性
     *
     * @export
     * @template To
     * @template From
     * @param {To} to
     * @param {From} from
     * @param {...(keyof From)[]} keys
     */
    function copyProperties(to, from) {
        var keys = [];
        for (var _i = 2; _i < arguments.length; _i++) {
            keys[_i - 2] = arguments[_i];
        }
        for (var i = 0; i < keys.length; i++) {
            var key = keys[i];
            copyProperty(to, from, key);
        }
    }
    jy.copyProperties = copyProperties;
})(jy || (jy = {}));
//# sourceMappingURL=Mixin.js.map