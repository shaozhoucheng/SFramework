var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var jy;
(function (jy) {
    // const enum Const {
    function sendMultiDataPerFrame(cmd, data, msgType) {
        //@ts-ignore
        var ws = this._ws;
        if (!ws || ws.readyState != WebSocket.OPEN) {
            return;
        }
        //@ts-ignore
        var _a = this, _pcmdList = _a._pcmdList, _sendBuffer = _a._sendBuffer;
        //没有同协议的指令，新增数据
        var pdata = jy.recyclable(jy.NetSendData);
        pdata.cmd = cmd;
        pdata.data = data;
        pdata.msgType = msgType;
        _sendBuffer.reset();
        this.writeToBuffer(_sendBuffer, pdata);
        pdata.recycle();
        for (var _i = 0, _pcmdList_1 = _pcmdList; _i < _pcmdList_1.length; _i++) {
            var pdata_1 = _pcmdList_1[_i];
            this.writeToBuffer(_sendBuffer, pdata_1);
            pdata_1.recycle();
        }
        //清空被动数据
        _pcmdList.length = 0;
        ws.send(_sendBuffer.outBytes);
    }
    function sendOneDataPerFrame(cmd, data, msgType) {
        //@ts-ignore
        var ws = this._ws;
        if (!ws || ws.readyState != WebSocket.OPEN) {
            return;
        }
        //@ts-ignore
        var _a = this, _pcmdList = _a._pcmdList, _sendBuffer = _a._sendBuffer;
        //没有同协议的指令，新增数据
        var pdata = jy.recyclable(jy.NetSendData);
        pdata.cmd = cmd;
        pdata.data = data;
        pdata.msgType = msgType;
        _sendBuffer.reset();
        this.writeToBuffer(_sendBuffer, pdata);
        pdata.recycle();
        ws.send(_sendBuffer.outBytes);
        for (var _i = 0, _pcmdList_2 = _pcmdList; _i < _pcmdList_2.length; _i++) {
            var pdata_2 = _pcmdList_2[_i];
            _sendBuffer.reset();
            this.writeToBuffer(_sendBuffer, pdata_2);
            pdata_2.recycle();
            ws.send(_sendBuffer.outBytes);
        }
        //清空被动数据
        _pcmdList.length = 0;
    }
    /**
     * 单BinaryFrame单消息模式 的消息处理
     *
     * @protected
     * @memberof WSNetService
     */
    function onData(ev) {
        //@ts-ignore
        var readBuffer = this._readBuffer;
        readBuffer.replaceBuffer(ev.data);
        readBuffer.position = 0;
        this.decodeBytes(readBuffer);
    }
    /**
     *
     * 单BinaryFrame 多消息模式 的消息处理
     * @protected
     */
    function onDataN(ev) {
        //@ts-ignore
        var readBuffer = this._readBuffer;
        var ab = new Uint8Array(ev.data);
        var temp;
        var position = readBuffer.position;
        var buffer = readBuffer.buffer;
        var length = buffer.byteLength;
        if (position < length) {
            var rb = new Uint8Array(buffer);
            var rbLen = length - position;
            var abLen = ab.length;
            temp = new Uint8Array(rbLen + abLen);
            var i = 0, m = void 0;
            for (m = 0; m < rbLen; m++) {
                temp[i++] = rb[position + m];
            }
            for (m = 0; m < abLen; m++) {
                temp[i++] = ab[m];
            }
        }
        else {
            temp = ab;
        }
        readBuffer.replaceBuffer(temp.buffer);
        readBuffer.position = 0;
        this.decodeBytes(readBuffer);
    }
    /**
     * 解除ws绑定
     *
     * @param {WebSocket} ws
     */
    function loose(ws) {
        ws.onclose = null;
        ws.onerror = null;
        ws.onmessage = null;
        ws.onopen = null;
    }
    /**
     * WebSocket版本的NetService
     * @author 3tion
     */
    var WSNetService = (function (_super) {
        __extends(WSNetService, _super);
        function WSNetService() {
            var _this = _super.call(this) || this;
            _this.onOpen = function () {
                var ws = _this._ws;
                ws && (ws.onopen = null);
                if (true) {
                    console.log("webSocket连接成功");
                }
                jy.dispatch(-197 /* Connected */);
            };
            /**
             *
             * 发生错误
             * @protected
             */
            _this.onError = function (ev) {
                if (true) {
                    jy.ThrowError("socket发生错误", ev.error);
                }
                jy.dispatch(-196 /* ConnectFailed */);
            };
            /**
             *
             * 断开连接
             * @protected
             */
            _this.onClose = function (ev) {
                if (true) {
                    console.log("socket断开连接");
                }
                jy.Global.nextTick(jy.dispatch, jy, -195 /* Disconnect */);
            };
            //覆盖instance
            jy.NetService._ins = _this;
            return _this;
        }
        /**
         * 设置数据模式
         *
         * @param {WSNetServiceDataMode} mode
         * @memberof WSNetService
         */
        WSNetService.prototype.setDataMode = function (mode) {
            if (this.dataMode != mode) {
                //@ts-ignore
                this.dataMode = mode;
                this.checkDataMode();
            }
        };
        /**
         * 检查数据模式
         *
         * @memberof WSNetService
         */
        WSNetService.prototype.checkDataMode = function () {
            var ws = this._ws;
            if (ws) {
                var mode = ~~this.dataMode;
                ws.onmessage = (mode & 1 /* ReceiveMask */) == 1 /* ReceiveMultiDataPerFrame */ ? onDataN.bind(this) : onData.bind(this);
                this.$send = (mode & 2 /* SendMask */) == 2 /* SendOneDataPerFrame */ ? sendOneDataPerFrame : sendMultiDataPerFrame;
            }
        };
        Object.defineProperty(WSNetService.prototype, "connected", {
            get: function () {
                var ws = this._ws;
                return ws && ws.readyState == WebSocket.OPEN;
            },
            enumerable: true,
            configurable: true
        });
        /**
         *
         * 设置websocket地址
         * @param {string} actionUrl
         */
        WSNetService.prototype.setUrl = function (actionUrl) {
            if (this._actionUrl != actionUrl) {
                this._actionUrl = actionUrl;
                var ws = this._ws;
                if (ws && ws.readyState <= WebSocket.OPEN) {
                    this.connect();
                }
            }
        };
        /**
         * 打开新的连接
         */
        WSNetService.prototype.connect = function () {
            var ws = this._ws;
            if (ws) {
                loose(ws);
            }
            this._ws = ws = new WebSocket(this._actionUrl);
            ws.binaryType = "arraybuffer";
            ws.onclose = this.onClose;
            ws.onerror = this.onError;
            ws.onopen = this.onOpen;
            this.checkDataMode();
        };
        WSNetService.prototype._send = function (cmd, data, msgType) {
            this.$send(cmd, data, msgType);
        };
        /**
         * 主动断开连接
         *
         * @returns
         * @memberof WSNetService
         */
        WSNetService.prototype.disconnect = function () {
            var ws = this._ws;
            if (!ws || ws.readyState != WebSocket.OPEN) {
                return;
            }
            loose(ws);
            this._ws = null;
            ws.close();
        };
        return WSNetService;
    }(jy.NetService));
    jy.WSNetService = WSNetService;
    __reflect(WSNetService.prototype, "jy.WSNetService");
})(jy || (jy = {}));
//# sourceMappingURL=WSNetService.js.map