var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var jy;
(function (jy) {
    /**
     * 使用http进行通信的网络服务
     * @author 3tion
     *
     */
    var HttpNetService = (function (_super) {
        __extends(HttpNetService, _super);
        function HttpNetService() {
            var _this = _super.call(this) || this;
            _this._state = 0 /* UNREQUEST */;
            /**
             * 请求发送成功的次数
             */
            _this._success = 0;
            /**
             * 请求连续发送失败的次数
             */
            _this._cerror = 0;
            /**
             * 请求失败次数
             */
            _this._error = 0;
            //覆盖instance
            jy.NetService._ins = _this;
            _this._unsendRequest = [];
            _this._sendingList = [];
            _this._loader = new XMLHttpRequest;
            return _this;
        }
        /**
         * 重置
         * @param actionUrl             请求地址
         * @param autoTimeDelay         自动发送的最短延迟时间
         */
        HttpNetService.prototype.setUrl = function (actionUrl, autoTimeDelay) {
            if (autoTimeDelay === void 0) { autoTimeDelay = 5000; }
            this._actionUrl = actionUrl;
            if (autoTimeDelay != this._autoTimeDelay) {
                this._autoTimeDelay = autoTimeDelay;
            }
            // 200毫秒检查一次，是否可以自动拉数据了
            jy.TimerUtil.addCallback(200, this.checkUnsend, this);
            var loader = this._loader;
            loader.onreadystatechange = this.onReadyStateChange.bind(this);
            loader.ontimeout = this.errorHandler.bind(this);
        };
        /**
        * @protected
        */
        HttpNetService.prototype.onReadyStateChange = function () {
            var xhr = this._loader;
            if (xhr.readyState == 4) {
                var ioError_1 = (xhr.status >= 400 || xhr.status == 0);
                var self_1 = this;
                setTimeout(function () {
                    if (ioError_1) {
                        self_1.errorHandler();
                    }
                    else {
                        self_1.complete();
                    }
                }, 0);
            }
        };
        /**
         * 发生错误
         */
        HttpNetService.prototype.errorHandler = function () {
            this._error++;
            this._cerror++;
            this._state = -1 /* FAILED */;
            if (this._cerror > 1) {
                this.showReconnect();
                return;
            }
            //曾经成功过
            //数据未发送成功
            var sending = this._sendingList;
            var idx = sending.length;
            var unrequest = this._unsendRequest;
            for (var _i = 0, unrequest_1 = unrequest; _i < unrequest_1.length; _i++) {
                var pdata = unrequest_1[_i];
                sending[idx++] = pdata;
            }
            //交互未发送的请求和发送中的请求列表
            unrequest.length = 0;
            this._unsendRequest = sending;
            this._sendingList = unrequest;
            //尝试重新发送请求
            this.checkUnsend();
        };
        HttpNetService.prototype.complete = function () {
            this._state = 2 /* COMPLETE */;
            this._reconCount = 0;
            //处理Response
            var readBuffer = this._readBuffer;
            readBuffer.replaceBuffer(this._loader.response);
            readBuffer.position = 0;
            //成功一次清零连续失败次数
            this._cerror = 0;
            this._success++;
            //清理正在发送的数据            
            for (var _i = 0, _a = this._sendingList; _i < _a.length; _i++) {
                var pdata = _a[_i];
                pdata.recycle();
            }
            //数据发送成功
            this._sendingList.length = 0;
            this.onBeforeSolveData();
            this.decodeBytes(readBuffer);
            this.checkUnsend();
        };
        /**
         * 检查在发送过程中的请求
         */
        HttpNetService.prototype.checkUnsend = function () {
            //有在发送过程中，主动发送的数据
            if (this._unsendRequest.length || jy.Global.now > this._nextAutoTime) {
                this.trySend();
            }
        };
        HttpNetService.prototype._send = function (cmd, data, msgType) {
            //没有同协议的指令，新增数据
            var pdata = jy.recyclable(jy.NetData);
            pdata.cmd = cmd;
            pdata.data = data;
            pdata.msgType = msgType;
            this._unsendRequest.push(pdata);
            this.trySend();
        };
        /**
         * 发送消息之前，用于预处理一些http头信息等
         *
         * @protected
         */
        HttpNetService.prototype.onBeforeSend = function () {
        };
        /**
         * 接收到服务端Response，用于预处理一些信息
         *
         * @protected
         */
        HttpNetService.prototype.onBeforeSolveData = function () {
        };
        /**
         * 尝试发送
         */
        HttpNetService.prototype.trySend = function () {
            if (this._state == 1 /* REQUESTING */) {
                return;
            }
            this._state = 1 /* REQUESTING */;
            var loader = this._loader;
            loader.open("POST", this._actionUrl, true);
            loader.responseType = "arraybuffer";
            this.onBeforeSend();
            var sendBuffer = this._sendBuffer;
            sendBuffer.reset();
            var unsend = this._unsendRequest;
            var sending = this._sendingList;
            for (var i = 0, len = unsend.length; i < len; i++) {
                var pdata = unsend[i];
                this.writeToBuffer(sendBuffer, pdata);
                sending[i] = pdata;
            }
            var pcmdList = this._pcmdList;
            for (var _i = 0, pcmdList_1 = pcmdList; _i < pcmdList_1.length; _i++) {
                var pdata = pcmdList_1[_i];
                this.writeToBuffer(sendBuffer, pdata);
                sending[i++] = pdata;
            }
            //清空被动数据
            pcmdList.length = 0;
            //清空未发送的数据
            unsend.length = 0;
            loader.send(sendBuffer.outBytes);
            //重置自动发送的时间
            this._nextAutoTime = jy.Global.now + this._autoTimeDelay;
        };
        return HttpNetService;
    }(jy.NetService));
    jy.HttpNetService = HttpNetService;
    __reflect(HttpNetService.prototype, "jy.HttpNetService");
})(jy || (jy = {}));
//# sourceMappingURL=HttpNetService.js.map