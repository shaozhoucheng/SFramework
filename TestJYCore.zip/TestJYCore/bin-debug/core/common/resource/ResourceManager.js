var jy;
(function (jy) {
    /**
     * 资源管理器
     */
    var _resources = {};
    function get(resid, noResHandler, thisObj) {
        var res = getResource(resid);
        if (!res) {
            var args = [];
            for (var i = 3; i < arguments.length; i++) {
                args[i - 3] = arguments[i];
            }
            res = noResHandler.apply(thisObj, args);
            regResource(resid, res);
        }
        return res;
    }
    jy.ResManager = {
        get: get,
        /**
         * 获取纹理资源
         *
         * @param {string} resID 资源id
         * @param {boolean} [noWebp] 是否不加webp后缀
         * @returns {TextureResource}
         */
        getTextureRes: function (resID, noWebp) {
            var resources = _resources;
            var res = resources[resID];
            if (res) {
                if (!(res instanceof jy.TextureResource)) {
                    jy.ThrowError("[" + resID + "]\u8D44\u6E90\u6709\u8BEF\uFF0C\u4E0D\u662FTextureResource");
                    res = undefined;
                }
            }
            if (!res) {
                res = new jy.TextureResource(resID, noWebp);
                resources[resID] = res;
            }
            return res;
        },
        /**
         * 获取资源
         */
        getResource: getResource,
        // /**
        //  * 注册资源
        //  */
        // regResource,
        //按时间检测资源
        init: function () {
            var tobeDele = [];
            jy.TimerUtil.addCallback(30000 /* CheckTime */, function () {
                var expire = jy.Global.now - 300000 /* DisposeTime */;
                var reses = _resources;
                var delLen = 0;
                for (var key in reses) {
                    var res = reses[key];
                    if (!res.isStatic && res.lastUseTime < expire) {
                        tobeDele[delLen++] = key;
                    }
                }
                // //对附加的checker进行检查
                // for (let i = 0; i < _checkers.length; i++) {
                //     _checkers[i].resCheck(expire);
                // }
                for (var i = 0; i < delLen; i++) {
                    var key = tobeDele[i];
                    var res = reses[key];
                    if (res) {
                        res.dispose();
                        jy.Res.remove(res.uri);
                        delete reses[key];
                    }
                }
            });
        }
    };
    /**
     * 获取资源
     */
    function getResource(resID) {
        return _resources[resID];
    }
    /**
     * 注册资源
     */
    function regResource(resID, res) {
        var resources = _resources;
        if (resID in resources) {
            return resources[resID] === res;
        }
        resources[resID] = res;
        return true;
    }
})(jy || (jy = {}));
//# sourceMappingURL=ResourceManager.js.map