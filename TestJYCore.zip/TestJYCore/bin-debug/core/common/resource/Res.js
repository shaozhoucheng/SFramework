var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var jy;
(function (jy) {
    var Res;
    (function (Res) {
        /**
         *  失败的超时时间
         */
        var failedExpiredTime = 10000 /* FailedExpiredTime */;
        /**
         * 设置失败的过期时间
         * 失败次数超过`maxRetry`
         * @export
         * @param {number} second
         */
        function setFailedExpired(second) {
            var time = ~~second * 1000 /* ONE_SECOND */;
            if (time <= 0) {
                time = 10000 /* FailedExpiredTime */;
            }
            failedExpiredTime = time;
        }
        Res.setFailedExpired = setFailedExpired;
        /**
         * 最大重试次数
         */
        var maxRetry = 3 /* MaxRetry */;
        /**
         * 设置单个资源，不做延迟重试的最大重试次数，默认为3
         * @param val
         */
        function setMaxRetry(val) {
            maxRetry = val;
        }
        Res.setMaxRetry = setMaxRetry;
        /**
         * 最大加载数量
         * 目前所有主流浏览器针对 http 1.1 单域名最大加载数均为6个
         * http2 基本无限制
         */
        var maxThread = 6 /* MaxThread */;
        /**
         * 设置最大加载线程  默认为 6
         * @param val
         */
        function setMaxThread(val) {
            maxThread = val;
        }
        Res.setMaxThread = setMaxThread;
        /**
         * 扩展名和类型的绑定字典
         */
        var extTypeDict = (_a = {},
            _a[".jpg" /* JPG */] = 2 /* Image */,
            _a[".png" /* PNG */] = 2 /* Image */,
            _a[".webp" /* WEBP */] = 2 /* Image */,
            _a[".json" /* JSON */] = 3 /* Json */,
            _a[".bin" /* BIN */] = 0 /* Binary */,
            _a);
        function checkItemState(item, event) {
            var state = item.state;
            if (!item.removed) {
                state = event.type == "complete" /* COMPLETE */ ? 2 /* COMPLETE */ : -1 /* FAILED */;
            }
            item.state = state;
            return state;
        }
        function bindRequest(loader, request, item, callback) {
            request.on("complete" /* COMPLETE */, loader.onLoadFinish, loader);
            request.on("ioError" /* IO_ERROR */, loader.onLoadFinish, loader);
            request.item = item;
            request.resCB = callback;
        }
        function looseRequest(loader, request) {
            request.off("complete" /* COMPLETE */, loader.onLoadFinish, loader);
            request.off("ioError" /* IO_ERROR */, loader.onLoadFinish, loader);
            request.item = undefined;
            request.resCB = undefined;
            request.recycle();
        }
        var BinLoader = (function () {
            function BinLoader(type) {
                if (type === void 0) { type = "arraybuffer"; }
                this.type = type;
            }
            BinLoader.prototype.loadFile = function (resItem, callback) {
                var request = jy.recyclable(egret.HttpRequest);
                bindRequest(this, request, resItem, callback);
                request.responseType = this.type;
                request.open(resItem.url);
                request.send();
            };
            BinLoader.prototype.onLoadFinish = function (event) {
                var request = event.target;
                var item = request.item, resCB = request.resCB, response = request.response;
                looseRequest(this, request);
                var state = checkItemState(item, event);
                if (state == 2 /* COMPLETE */) {
                    item.data = response;
                }
                resCB.callAndRecycle(item);
            };
            return BinLoader;
        }());
        Res.BinLoader = BinLoader;
        __reflect(BinLoader.prototype, "jy.Res.BinLoader", ["jy.Res.ResLoader"]);
        var ImageLoader = (function () {
            function ImageLoader() {
            }
            ImageLoader.prototype.loadFile = function (resItem, callback) {
                var request = jy.recyclable(egret.ImageLoader);
                bindRequest(this, request, resItem, callback);
                request.load(resItem.url);
            };
            ImageLoader.prototype.onLoadFinish = function (event) {
                var request = event.target;
                var item = request.item, resCB = request.resCB, data = request.data;
                looseRequest(this, request);
                var state = checkItemState(item, event);
                if (state == 2 /* COMPLETE */) {
                    var texture = new egret.Texture();
                    texture._setBitmapData(data);
                    item.data = texture;
                }
                resCB.callAndRecycle(item);
            };
            return ImageLoader;
        }());
        Res.ImageLoader = ImageLoader;
        __reflect(ImageLoader.prototype, "jy.Res.ImageLoader", ["jy.Res.ResLoader"]);
        var binLoader = new BinLoader();
        /**
         * 资源字典
         * Key {Key} 资源标识
         * Value {ResItem} 资源
         *
         */
        var resDict = {};
        /**
         * 加载器字典
         * Key {number}             加载器类型
         * Value {ResAnalyzer}      加载器
         */
        var loaderMap = (_b = {},
            _b[0 /* Binary */] = binLoader,
            _b[1 /* Text */] = new BinLoader("text"),
            _b[3 /* Json */] = new BinLoader("json"),
            _b[2 /* Image */] = new ImageLoader,
            _b);
        /**
         * 加载列队的总数
         */
        var queues = {};
        /**
         * 失败的资源加载列队
         */
        var failedList = [];
        /**
        * 获取资源的扩展名
        * @param url
        */
        function getExt(url) {
            var hash = url.lastIndexOf("?");
            hash == -1 && (hash = undefined);
            var ext = url.substring(url.lastIndexOf("."), hash);
            return ext.toLocaleLowerCase();
        }
        Res.getExt = getExt;
        /**
         * 内联绑定
         * @param ext 扩展名
         * @param type 类型
         */
        function bindExtType(ext, type) {
            extTypeDict[ext] = type;
        }
        Res.bindExtType = bindExtType;
        /**
         * 注册资源分析器
         * @param type 分析器类型
         * @param analyzer 分析器
         */
        function regAnalyzer(type, analyzer) {
            loaderMap[type] = analyzer;
        }
        Res.regAnalyzer = regAnalyzer;
        /**
         * 根据 url 获取资源的处理类型
         * @param url
         */
        function getType(url) {
            var ext = getExt(url);
            return ~~extTypeDict[ext]; //默认使用binary类型
        }
        /**
         * 获取或创建一个加载列队
         * @param queueID
         * @param list
         * @param priority
         */
        function getOrCreateQueue(queueID, type, priority, list) {
            if (type === void 0) { type = 1 /* FIFO */; }
            var old = queues[queueID];
            if (old) {
                if (list) {
                    list.appendTo(old.list);
                }
                return old;
            }
            list = list || [];
            priority = ~~priority;
            var queue = { id: queueID, list: list, priority: priority, type: type };
            queues[queueID] = queue;
            return queue;
        }
        //创建内置分组
        getOrCreateQueue(2 /* Highway */, 1 /* FIFO */, 9999);
        getOrCreateQueue(0 /* Normal */);
        getOrCreateQueue(1 /* Backgroud */, 0 /* FILO */, -9999);
        /**
         * addRes方法的返回值
         */
        var addResResult = [];
        /**
         * 添加资源
         * @param {ResItem} resItem
         * @param {ResQueueID} [queueID=ResQueueID.Normal]
         * @returns {ResItem}
         */
        function addRes(resItem, queueID) {
            if (queueID === void 0) { queueID = 0 /* Normal */; }
            var uri = resItem.uri;
            var old = resDict[uri];
            addResResult[1] = false;
            if (old) {
                if (old != resItem && old.url != resItem.url) {
                    true && jy.ThrowError("\u8D44\u6E90[" + uri + "]\u91CD\u540D\uFF0C\u52A0\u8F7D\u8DEF\u5F84\u5206\u5E03\u4E3A[" + old.url + "]\u548C[" + resItem.url + "]");
                }
                else {
                    var state = old.state;
                    if (state >= 1 /* REQUESTING */) {
                        addResResult[0] = old;
                        return addResResult;
                    }
                }
                resItem = old;
            }
            else {
                resDict[uri] = resItem;
            }
            addResResult[0] = resItem;
            var oQID = resItem.qid;
            if (oQID != queueID) {
                var oQueue = queues[oQID];
                if (oQueue) {
                    oQueue.list.remove(resItem);
                }
                //更新列表
                resItem.qid = queueID;
                var queue = getOrCreateQueue(queueID);
                queue.list.pushOnce(resItem);
                addResResult[1] = true;
            }
            return addResResult;
        }
        Res.addRes = addRes;
        /**
         * 加载资源
         * @param {string} uri 资源标识
         * @param {ResCallback} callback 加载完成的回调
         * @param {string} [url] 资源路径
         * @param {ResQueueID} [queueID=ResQueueID.Normal]
         */
        function load(uri, url, callback, queueID) {
            if (queueID === void 0) { queueID = 0 /* Normal */; }
            //检查是否已经有资源
            var item = resDict[uri];
            if (!item) {
                if (!url) {
                    url = jy.ConfigUtils.getResUrl(uri);
                }
                item = { uri: uri, url: url, type: getType(url) };
            }
            loadRes(item, callback, queueID);
        }
        Res.load = load;
        function loadList(list, opt, queueID) {
            if (queueID === void 0) { queueID = 0 /* Normal */; }
            var total = list.length;
            var group = opt.group;
            opt.current = 0;
            opt.total = total;
            for (var i = 0; i < total; i++) {
                var item = list[i];
                item.group = group;
                loadRes(item, jy.CallbackInfo.get(doLoadList, null, opt), queueID);
            }
        }
        Res.loadList = loadList;
        function doLoadList(item, param) {
            var group = param.group, callback = param.callback, onProgress = param.onProgress;
            if (item.group == group) {
                if (item.state == -1 /* FAILED */) {
                    callback.callAndRecycle(false);
                }
                else {
                    param.current++;
                    onProgress && onProgress.call();
                    if (param.current >= param.total) {
                        callback.callAndRecycle(true);
                        onProgress && onProgress.recycle();
                    }
                }
            }
        }
        /**
         * 同步获取某个资源，如果资源未加载完成，则返回空
         * @param uri 资源标识
         */
        function get(uri) {
            var item = resDict[uri];
            if (item && item.state == 2 /* COMPLETE */) {
                return item.data;
            }
        }
        Res.get = get;
        function set(uri, item) {
            if (!resDict[uri]) {
                resDict[uri] = item;
                return true;
            }
        }
        Res.set = set;
        /**
         * 移除某个资源
         * @param uri
         */
        function remove(uri) {
            var item = resDict[uri];
            if (item) {
                delete resDict[uri];
                var qid = item.qid;
                var queue = queues[qid];
                if (queue) {
                    queue.list.remove(item);
                }
                item.removed = true;
            }
        }
        Res.remove = remove;
        /**
         * 阻止尝试某个资源加载，目前是还未加载的资源，从列队中做移除，其他状态不处理
         * @param uri
         */
        function cancel(uri) {
            var item = resDict[uri];
            if (item) {
                if (item.state == 0 /* UNREQUEST */) {
                    var qid = item.qid;
                    var queue = queues[qid];
                    if (queue) {
                        queue.list.remove(item);
                    }
                    doCallback(item);
                }
            }
        }
        Res.cancel = cancel;
        /**
         * 加载资源
         * @param {ResItem} resItem
         * @param {ResQueueID} [queueID=ResQueueID.Normal]
         */
        function loadRes(resItem, callback, queueID) {
            if (queueID === void 0) { queueID = 0 /* Normal */; }
            resItem = addRes(resItem, queueID)[0];
            var state = resItem.state;
            if (state == 2 /* COMPLETE */ || (state == -1 /* FAILED */ && resItem.retry > maxRetry && jy.Global.now < ~~resItem.ft)) {
                return callback && jy.Global.nextTick(callback.callAndRecycle, callback, resItem); // callback.callAndRecycle(resItem);
            }
            resItem.removed = false;
            if (callback) {
                var list = resItem.callbacks;
                if (!list) {
                    resItem.callbacks = list = [];
                }
                list.push(callback);
            }
            return next();
        }
        Res.loadRes = loadRes;
        /**
         * 获取下一个要加载的资源
         */
        function getNext() {
            var next;
            //得到优先级最大并且
            var high = -Infinity;
            var highQueue;
            for (var key in queues) {
                var queue = queues[key];
                if (queue.list.length) {
                    var priority = queue.priority;
                    if (priority > high) {
                        high = priority;
                        highQueue = queue;
                    }
                }
            }
            if (highQueue) {
                //检查列队类型
                var list = highQueue.list;
                switch (highQueue.type) {
                    case 1 /* FIFO */:
                        next = list.shift();
                        break;
                    case 0 /* FILO */:
                        next = list.pop();
                        break;
                }
            }
            if (!next) {
                if (failedList.length > 0) {
                    next = failedList.shift();
                }
            }
            return next;
        }
        /**
         * 正在加载的资源列队
         */
        var loading = [];
        function next() {
            while (loading.length < maxThread) {
                var item = getNext();
                if (!item)
                    break;
                loading.pushOnce(item);
                var state = ~~item.state;
                if (state == -1 /* FAILED */ && item.ft < jy.Global.now) {
                    state = 0 /* UNREQUEST */;
                }
                switch (state) {
                    case -1 /* FAILED */:
                    case 2 /* COMPLETE */:
                        onItemComplete(item);
                        break;
                    case 0 /* UNREQUEST */://其他情况不处理
                        var type = item.type;
                        if (type == undefined) {
                            type = getType(item.url);
                        }
                        var loader = loaderMap[type];
                        if (!loader) {
                            loader = binLoader;
                        }
                        //标记为加载中
                        item.state = 1 /* REQUESTING */;
                        loader.loadFile(item, jy.CallbackInfo.get(onItemComplete));
                        break;
                }
            }
        }
        /**
         * 资源加载结束，执行item的回调
         * @param item
         */
        function doCallback(item) {
            var callbacks = item.callbacks;
            if (callbacks) {
                item.callbacks = undefined;
                for (var i = 0; i < callbacks.length; i++) {
                    var cb = callbacks[i];
                    cb.callAndRecycle(item);
                }
            }
        }
        function onItemComplete(item) {
            loading.remove(item);
            item.qid = undefined;
            var state = ~~item.state;
            if (state == -1 /* FAILED */) {
                var retry = item.retry || 1;
                if (retry > maxRetry) {
                    var now = jy.Global.now;
                    var ft = ~~item.ft;
                    if (now > ft) {
                        item.ft = failedExpiredTime * (retry - maxRetry) + now;
                    }
                    doCallback(item);
                    return jy.dispatch(-187 /* ResLoadFailed */, item);
                }
                item.retry = retry + 1;
                item.state = 0 /* UNREQUEST */;
                failedList.push(item);
            }
            else if (state == 2 /* COMPLETE */) {
                //加载成功，清零retry
                item.retry = 0;
                //检查资源是否被加入到列队中
                doCallback(item);
                jy.dispatch(-186 /* ResLoadSuccess */, item);
            }
            return next();
        }
        function getLocalDB(version, keyPath, storeName) {
            //检查浏览器是否支持IndexedDB
            var w = window;
            w.indexedDB = w.indexedDB ||
                w.mozIndexedDB ||
                w.webkitIndexedDB ||
                w.msIndexedDB;
            if (!w.indexedDB) {
                //不支持indexedDB，不对白鹭的RES做任何调整，直接return
                return;
            }
            w.IDBTransaction = w.IDBTransaction ||
                w.webkitIDBTransaction ||
                w.msIDBTransaction;
            w.IDBKeyRange = w.IDBKeyRange ||
                w.webkitIDBKeyRange ||
                w.msIDBKeyRange;
            try {
                indexedDB.open(storeName, version);
            }
            catch (e) {
                true && jy.ThrowError("\u65E0\u6CD5\u5F00\u542F indexedDB,error:", e);
                return;
            }
            var RW = "readwrite";
            var R = "readonly";
            return {
                /**
                 * 存储资源
                 *
                 * @param {ResItem} data
                 * @param {(this: IDBRequest, ev: Event) => any} callback 存储资源执行完成后的回调
                 */
                save: function (data, callback) {
                    open(function (result) {
                        try {
                            var store = getObjectStore(result, RW);
                            var request = data.uri ? store.put(data) : store.add(data);
                            if (callback) {
                                request.onsuccess = callback;
                                request.onerror = callback;
                            }
                        }
                        catch (e) {
                            return callback && callback(e);
                        }
                    }, function (e) { callback && callback(e); });
                },
                /**
                 * 获取资源
                 *
                 * @param {string} url
                 * @param {{ (data: ResItem) }} callback
                 */
                get: function (url, callback) {
                    open(function (result) {
                        try {
                            var store = getObjectStore(result, R);
                            var request = store.get(url);
                            request.onsuccess = function (e) {
                                callback(e.target.result, url);
                            };
                            request.onerror = function () {
                                callback(null, url);
                            };
                        }
                        catch (e) {
                            true && jy.ThrowError("indexedDB error", e);
                            callback(null, url);
                        }
                    }, function (e) { callback(null, url); });
                },
                /**
                 * 删除指定资源
                 *
                 * @param {string} url
                 * @param {{ (this: IDBRequest, ev: Event) }} callback 删除指定资源执行完成后的回调
                 */
                delete: function (url, callback) {
                    open(function (result) {
                        try {
                            var store = getObjectStore(result, RW);
                            var request = store.delete(url);
                            if (callback) {
                                request.onerror = request.onsuccess = function (e) { callback(url, e); };
                            }
                        }
                        catch (e) {
                            return callback && callback(url, e);
                        }
                    }, function (e) { callback && callback(url, e); });
                },
                /**
                 * 删除全部资源
                 *
                 * @param {{ (this: IDBRequest, ev: Event) }} callback 删除全部资源执行完成后的回调
                 */
                clear: function (callback) {
                    open(function (result) {
                        try {
                            var store = getObjectStore(result, RW);
                            var request = store.clear();
                            if (callback) {
                                request.onsuccess = callback;
                                request.onerror = callback;
                            }
                        }
                        catch (e) {
                            return callback(e);
                        }
                    }, callback);
                },
            };
            function open(callback, onError) {
                try {
                    var request = indexedDB.open(storeName, version);
                }
                catch (e) {
                    true && jy.ThrowError("indexedDB error", e);
                    return onError && onError(e);
                }
                request.onerror = function (e) {
                    onError && onError(e.error);
                    errorHandler(e);
                };
                request.onupgradeneeded = function (e) {
                    var _db = e.target.result;
                    var names = _db.objectStoreNames;
                    if (!names.contains(storeName)) {
                        _db.createObjectStore(storeName, { keyPath: keyPath });
                    }
                };
                request.onsuccess = function (e) {
                    var result = request.result;
                    result.onerror = errorHandler;
                    callback(result);
                };
            }
            function getObjectStore(result, mode) {
                return result.transaction([storeName], mode).objectStore(storeName);
            }
            function errorHandler(ev) {
                jy.ThrowError("indexedDB error", ev.error);
            }
        }
        Res.getLocalDB = getLocalDB;
        /**
         *  尝试启用本地资源缓存
         * @author 3tion(https://github.com/eos3tion/)
         * @export
         * @param {number} [version=1]
         * @returns
         */
        function tryLocal(version, keyPath, storeName) {
            if (version === void 0) { version = 1; }
            if (keyPath === void 0) { keyPath = "uri"; }
            if (storeName === void 0) { storeName = "res"; }
            if (egret.Capabilities.runtimeType != egret.RuntimeType.WEB) {
                return;
            }
            var db = getLocalDB(version, keyPath, storeName);
            //尝试
            if (!db) {
                return;
            }
            var w = window;
            w.URL = window.URL || w.webkitURL;
            //当前ios10还不支持IndexedDB的Blob存储，所以如果是ios，则此值为false
            var canUseBlob = egret.Capabilities.os == "iOS" ? false : !!(window.Blob && window.URL);
            function saveLocal(item, data) {
                item.local = true;
                var uri = item.uri;
                var local = { data: data, version: jy.ConfigUtils.getResVer(uri), uri: uri, url: item.url };
                //存储数据
                db.save(local);
            }
            var canvas = document.createElement("canvas");
            var context = canvas.getContext("2d");
            var BApt = BinLoader.prototype;
            var BAptLoadFile = BApt.loadFile;
            BApt.loadFile = function (resItem, callback) {
                var _this = this;
                if (resItem.noLocal) {
                    BAptLoadFile.call(this, resItem, callback);
                }
                else {
                    return db.get(resItem.uri, function (data) {
                        if (data) {
                            var local = data.data;
                            if (local) {
                                var ver = jy.ConfigUtils.getResVer(data.uri);
                                if (ver == data.version) {
                                    resItem.data = local;
                                    resItem.state = 2 /* COMPLETE */;
                                    resItem.local = true;
                                    return callback.call(resItem);
                                }
                            }
                        }
                        BAptLoadFile.call(_this, resItem, callback);
                    });
                }
            };
            BApt.onLoadFinish = function (event) {
                var request = event.target;
                var item = request.item, resCB = request.resCB, response = request.response;
                looseRequest(this, request);
                var state = checkItemState(item, event);
                var data;
                if (state == 2 /* COMPLETE */) {
                    data = response;
                }
                var uri = item.uri;
                if (data && !item.local && uri) {
                    //存储数据
                    saveLocal(item, data);
                }
                item.data = data;
                resCB.callAndRecycle(item);
            };
            var eWeb = egret.web;
            if (eWeb) {
                var WILpt = eWeb.WebImageLoader.prototype;
                var obl_1 = WILpt.onBlobLoaded;
                WILpt.onBlobLoaded = function (e) {
                    this.blob = this.request.response;
                    obl_1.call(this, e);
                };
            }
            //注入
            var IApt = ImageLoader.prototype;
            var IAptLoadFile = IApt.loadFile;
            IApt.loadFile = function (resItem, callback) {
                var _this = this;
                var uri = resItem.uri, url = resItem.url, noLocal = resItem.noLocal;
                if (noLocal) {
                    IAptLoadFile.call(this, resItem, callback);
                }
                else {
                    db.get(uri, function (data) {
                        if (data) {
                            var ver = jy.ConfigUtils.getResVer(uri);
                            if (ver == data.version) {
                                var rawData = data.data;
                                if (rawData instanceof Blob) {
                                    url = URL.createObjectURL(rawData);
                                }
                                else if (typeof rawData === "string") {
                                    url = rawData;
                                }
                                else {
                                    if (true) {
                                        jy.ThrowError("出现ImageAnalyzer本地缓存不支持的情况");
                                    }
                                }
                                resItem.local = true;
                            }
                        }
                        resItem.url = url;
                        IAptLoadFile.call(_this, resItem, callback);
                    });
                }
            };
            IApt.onLoadFinish = function (event) {
                var request = event.target;
                var item = request.item, resCB = request.resCB, blob = request.blob, dat = request.data;
                request.blob = undefined;
                looseRequest(this, request);
                var uri = item.uri;
                if (!item.local) {
                    item.local = true;
                    var url = item.url;
                    var local = blob;
                    if (!local) {
                        // 普通图片
                        // 尝试转换成DataURL，此方法为同步方法，可能会影响性能
                        if (dat instanceof egret.BitmapData) {
                            var img = dat.source;
                            if (!img) {
                                return;
                            }
                            var w_1 = img.width;
                            var h = img.height;
                            var type = "image/" + url.substring(url.lastIndexOf(".") + 1);
                            canvas.width = w_1;
                            canvas.height = h;
                            context.clearRect(0, 0, w_1, h);
                            context.drawImage(img, 0, 0);
                            try {
                                if (canUseBlob && url.indexOf("wxLocalResource:") != 0) {
                                    canvas.toBlob(function (blob) {
                                        saveLocal(item, blob);
                                    }, type);
                                }
                                else {
                                    local = canvas.toDataURL(type);
                                }
                            }
                            catch (e) {
                                //一般跨域并且没有权限的时候，会参数错误
                            }
                        }
                    }
                    if (local) {
                        if (!canUseBlob && typeof local !== "string") {
                            var a = new FileReader();
                            a.onload = function (e) {
                                saveLocal(item, this.result);
                            };
                            a.readAsDataURL(local);
                        }
                        else {
                            saveLocal(item, local);
                        }
                    }
                }
                var state = checkItemState(item, event);
                if (state == 2 /* COMPLETE */) {
                    var texture = new egret.Texture();
                    texture._setBitmapData(dat);
                    item.data = texture;
                }
                resCB.callAndRecycle(item);
            };
            return db;
        }
        Res.tryLocal = tryLocal;
        var _a, _b;
    })(Res = jy.Res || (jy.Res = {}));
})(jy || (jy = {}));
//# sourceMappingURL=Res.js.map