var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
if (true) {
    var ErrorTexture = jy.ColorUtil.getTexture(0xff0000, 1);
}
var jy;
(function (jy) {
    /**
     *
     * 纹理资源
     * @export
     * @class TextureResource
     * @implements {IResource}
     */
    var TextureResource = (function () {
        function TextureResource(uri, noWebp) {
            /**
             *
             * 绑定的对象列表
             * @private
             * @type {Bitmap[]}
             */
            this._list = [];
            this.uri = uri;
            this.url = jy.ConfigUtils.getResUrl(uri + (!noWebp ? jy.Global.webp : ""));
        }
        Object.defineProperty(TextureResource.prototype, "isStatic", {
            /**
             *
             * 是否为静态不销毁的资源
             * @type {boolean}
             */
            get: function () {
                return this._list.length > 0;
            },
            enumerable: true,
            configurable: true
        });
        /**
         *
         * 绑定一个目标
         * @param {Bitmap} target
         */
        TextureResource.prototype.bind = function (bmp) {
            if (this._tex) {
                bmp.texture = this._tex;
                bmp.dispatch(-193 /* Texture_Complete */);
            }
            this._list.pushOnce(bmp);
            this.lastUseTime = jy.Global.now;
        };
        /**
         *
         * 解除目标的绑定
         * @param {Bitmap} target
         */
        TextureResource.prototype.loose = function (bmp) {
            this._list.remove(bmp);
            this.lastUseTime = jy.Global.now;
        };
        TextureResource.prototype.load = function () {
            jy.Res.load(this.uri, this.url, jy.CallbackInfo.get(this.loadComplete, this), this.qid);
        };
        /**
         * 资源加载完成
         */
        TextureResource.prototype.loadComplete = function (item) {
            var data = item.data, uri = item.uri;
            if (uri == this.uri) {
                this._tex = data;
                for (var _i = 0, _a = this._list; _i < _a.length; _i++) {
                    var bmp = _a[_i];
                    bmp.texture = data;
                    if (true && !data) {
                        bmp.texture = bmp.placehoder || ErrorTexture;
                        var rect = bmp.suiRawRect;
                        if (rect) {
                            bmp.width = rect.width;
                            bmp.height = rect.height;
                        }
                    }
                    bmp.dispatch(-193 /* Texture_Complete */);
                }
            }
        };
        /**
         * 销毁资源
         */
        TextureResource.prototype.dispose = function () {
            if (this._tex) {
                this._tex.dispose();
                this._tex = undefined;
            }
            this._list.length = 0;
        };
        return TextureResource;
    }());
    jy.TextureResource = TextureResource;
    __reflect(TextureResource.prototype, "jy.TextureResource", ["jy.IResource"]);
})(jy || (jy = {}));
//# sourceMappingURL=TextureResource.js.map