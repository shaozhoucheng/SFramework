var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var jy;
(function (jy) {
    var clamp = Math.clamp;
    /**
     * 相机
     * @author 3tion
     *
     */
    var Camera = (function (_super) {
        __extends(Camera, _super);
        function Camera(width, height) {
            var _this = _super.call(this) || this;
            //限制范围
            _this._lx = 0;
            _this._ly = 0;
            _this._lw = Infinity;
            _this._lh = Infinity;
            /**
             * 是否需要横向滚动
             *
             * @protected
             * @memberof Camera
             */
            _this._hScroll = true;
            /**
             *
             * 是否需要纵向滚动
             *
             * @protected
             * @memberof Camera
             */
            _this._vScroll = true;
            _this._rect = new egret.Rectangle();
            var stage = egret.sys.$TempStage;
            if (!width) {
                width = stage.stageWidth;
            }
            if (!height) {
                height = stage.stageHeight;
            }
            _this.setSize(width, height);
            return _this;
        }
        Object.defineProperty(Camera.prototype, "changed", {
            get: function () {
                var target = this._host;
                if (target) {
                    var pos = getPosHash(target);
                    if (pos != this._lastPos) {
                        this._lastPos = pos;
                        return true;
                    }
                }
                return this._changed;
            },
            enumerable: true,
            configurable: true
        });
        /**
         * 标记已经改变完
         */
        Camera.prototype.change = function () {
            this._changed = false;
        };
        /**
         * 强制设置为改变
         * 用于地图切换时，坐标不发生变化的情况
         *
         */
        Camera.prototype.invalidate = function () {
            this._changed = true;
        };
        /**
         * 相机跟随一个可视对象
         * @param target 镜头要跟随的目标
         */
        Camera.prototype.lookat = function (target) {
            this._host = target;
            return !!target;
        };
        Object.defineProperty(Camera.prototype, "host", {
            /**
             * 获取当前镜头绑定的单位
             */
            get: function () {
                return this._host;
            },
            enumerable: true,
            configurable: true
        });
        /**
         * 设置相机的可视区域宽度和高度
         * @param width 可视区宽
         * @param height 可视区高
         */
        Camera.prototype.setSize = function (width, height) {
            var rect = this._rect;
            var changed = this._changed;
            if (width != rect.width) {
                rect.width = width;
                changed = true;
            }
            if (height != rect.height) {
                rect.height = height;
                changed = true;
            }
            if (changed) {
                this._changed = changed;
                this.check();
            }
            return this;
        };
        /**
         * 设置限制范围
         *
         * @param {number} [width=Infinity]
         * @param {number} [height=Infinity]
         * @param {number} [x=0]
         * @param {number} [y=0]
         * @returns
         * @memberof Camera
         */
        Camera.prototype.setLimits = function (width, height, x, y) {
            this._lx = x || 0;
            this._ly = y || 0;
            this._lw = width || Infinity;
            this._lh = height || Infinity;
            this.check();
            return this;
        };
        Camera.prototype.check = function () {
            var _a = this, _lx = _a._lx, _ly = _a._ly, _lw = _a._lw, _lh = _a._lh, _rect = _a._rect;
            var w = _rect.width, h = _rect.height;
            var flag = w < _lw;
            this._hScroll = flag;
            if (!flag) {
                _rect.x = 0;
            }
            flag = h < _lh;
            this._vScroll = flag;
            if (!flag) {
                _rect.y = 0;
            }
        };
        /**
         * 将相机移动到指定坐标
         */
        Camera.prototype.moveTo = function (x, y) {
            var _a = this, _hScroll = _a._hScroll, _vScroll = _a._vScroll, _rect = _a._rect, _lx = _a._lx, _ly = _a._ly, _lw = _a._lw, _lh = _a._lh;
            var rw = _rect.width, rh = _rect.height, rx = _rect.x, ry = _rect.y;
            var changed = this._changed;
            if (_hScroll) {
                x -= rw * .5;
                x = clamp(x, _lx, _lw - rw);
                if (x != rx) {
                    _rect.x = x;
                    changed = true;
                }
            }
            if (_vScroll) {
                y -= rh * .5;
                y = clamp(y, _ly, _lh - rh);
                if (y != ry) {
                    _rect.y = y;
                    changed = true;
                }
            }
            this._changed = changed;
            return this;
        };
        Object.defineProperty(Camera.prototype, "rect", {
            /**
             * 获取相机显示区域
             */
            get: function () {
                var target = this._host;
                if (target) {
                    this.moveTo(target.x, target.y);
                }
                return this._rect;
            },
            enumerable: true,
            configurable: true
        });
        return Camera;
    }(egret.HashObject));
    jy.Camera = Camera;
    __reflect(Camera.prototype, "jy.Camera");
    /**
     * 获取坐标点的hash值
     *
     * @export
     * @param {Point} pos
     * @returns
     */
    function getPosHash(pos) {
        return pos.x << 16 | (pos.y & 0xffff);
    }
    jy.getPosHash = getPosHash;
    function getPosHash2(x, y) {
        return x << 16 | (y & 0xffff);
    }
    jy.getPosHash2 = getPosHash2;
})(jy || (jy = {}));
//# sourceMappingURL=Camera.js.map