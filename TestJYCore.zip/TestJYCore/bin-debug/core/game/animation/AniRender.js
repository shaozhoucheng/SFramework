var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
if (true) {
    var $gm = $gm || {};
    $gm.recordAni = function () {
        $gm._recordAni = !$gm._recordAni;
        if ($gm._recordAni) {
            if (!$gm._aniRecords) {
                $gm._aniRecords = {};
            }
        }
        else {
            delete $gm._aniRecords;
        }
    };
    $gm.showAniRecords = function (time) {
        if (time === void 0) { time = 0; }
        var dict = $gm._aniRecords;
        var now = Date.now();
        var output = [];
        for (var guid in dict) {
            var record = dict[guid];
            var delta = now - record.time;
            if (delta > time) {
                output.push({ delta: delta, guid: record.guid, stack: record.stack });
            }
        }
        output.sort(function (a, b) { return a.delta - b.delta; });
        if (true)
            console.table(output);
    };
    $gm.showAniStacks = function (time) {
        if (time === void 0) { time = 0; }
        var dict = $gm._aniRecords;
        var now = Date.now();
        var output = {};
        for (var guid in dict) {
            var record = dict[guid];
            var delta = now - record.time;
            if (delta > time) {
                output[record.stack] = ~~output[record.stack] + 1;
            }
        }
        for (var stack in output) {
            if (true)
                egret.log("次数：", output[stack], "堆栈：\n", stack);
        }
    };
}
var jy;
(function (jy) {
    /**
     * 由于目前特效和渲染器是完全一一对应关系，所以直接做成AniBitmap
     * @author 3tion
     *
     */
    var AniRender = (function (_super) {
        __extends(AniRender, _super);
        function AniRender() {
            var _this = _super.call(this) || this;
            /**
             * 0 初始化，未运行
             * 1 正在运行
             * 2 已回收
             */
            _this.state = 0 /* Standby */;
            /**
             * 非循环动画，播放完毕后的回收策略
             * 默认为全部回收
             */
            _this.recyclePolicy = 3 /* RecycleAll */;
            // ani动画的`暂定`动作固定值0
            _this.a = 0;
            return _this;
        }
        Object.defineProperty(AniRender.prototype, "guid", {
            /**
             * 特效标识
             */
            get: function () {
                return this._guid;
            },
            enumerable: true,
            configurable: true
        });
        AniRender.prototype.render = function () {
            var aniinfo = this._aniInfo;
            if (aniinfo) {
                var actionInfo = aniinfo.actionInfo;
                if (actionInfo) {
                    var now = jy.Global.now;
                    this.onData(actionInfo, now);
                    this.doRender(now);
                }
            }
        };
        /**
         * 处理数据
         *
         * @param {number} now 时间戳
         */
        AniRender.prototype.doData = function (now) {
            if (this._aniInfo) {
                var actionInfo = this._aniInfo.actionInfo;
                if (actionInfo) {
                    this.onData(actionInfo, now);
                }
            }
        };
        AniRender.prototype.renderFrame = function (frame, now) {
            if (!frame) {
                return;
            }
            this.f = frame.f;
            var display = this.display;
            if (display && display.draw(this, now)) {
                this.willRenderFrame = undefined;
            }
        };
        /**
         * 派发事件
         * @param event     事件名
         * @param now       当前时间
         */
        AniRender.prototype.dispatchEvent = function (event, now) {
            var handler = this.handler;
            if (handler) {
                handler.call(event, this, now);
            }
        };
        AniRender.prototype.doComplete = function (now) {
            var handler = this.handler;
            if (handler) {
                handler.call(-1993 /* AniComplete */, this, now);
            }
            this.state = 2 /* Completed */;
            var policy = this.recyclePolicy;
            if ((policy & 2 /* RecycleRender */) == 2 /* RecycleRender */) {
                AniRender.recycle(this.guid);
            }
            else {
                var display = this.display;
                if (display) {
                    //这里不删除和AniRender的引用关系，但移除渲染事件
                    display.off("enterFrame" /* ENTER_FRAME */, this.render, this);
                    if ((policy & 1 /* RecycleDisplay */) == 1 /* RecycleDisplay */) {
                        //回收策略要求回收可视对象，才移除引用
                        this.display = undefined;
                        display.recycle();
                    }
                }
            }
        };
        AniRender.prototype.isComplete = function (info) {
            var loop = this.loop;
            if (loop != undefined) {
                loop--;
                this.loop = loop;
                return loop < 1;
            }
            return !info.isCircle;
        };
        AniRender.prototype.callback = function () {
            var _aniInfo = this._aniInfo;
            if (_aniInfo) {
                var _a = this, f = _a.f, loop = _a.loop, display = _a.display, state = _a.state;
                this.idx = checkStart(_aniInfo, loop, f);
                display.res = _aniInfo.getResource();
                if (state == 1 /* Playing */) {
                    this.checkPlay();
                }
            }
        };
        /**
         * 播放
         */
        AniRender.prototype.play = function (now) {
            var globalNow = jy.Global.now;
            now = now === void 0 ? globalNow : now;
            this.plTime = globalNow;
            this.renderedTime = now;
            this.nextRenderTime = now;
            this.state = 1 /* Playing */;
            this.resOK = false;
            this._render = undefined;
            this.checkPlay();
            if (true) {
                if ($gm._recordAni) {
                    var stack = new Error().stack;
                    var guid = this._guid;
                    var bin = { stack: stack, guid: guid, time: now };
                    $gm._aniRecords[guid] = bin;
                }
            }
        };
        AniRender.prototype.checkPlay = function () {
            var display = this.display;
            var res = display.res;
            if (res) {
                var old = this._render;
                var render = void 0;
                if (this.waitTexture) {
                    var _a = this, a = _a.a, d = _a.d;
                    if (res.isResOK(a, d)) {
                        if (!this.resOK) {
                            this.resOK = true;
                            //重新计算时间
                            var deltaTime = jy.Global.now - this.plTime;
                            this.renderedTime = this.nextRenderTime = this.renderedTime + deltaTime;
                        }
                        render = this.render;
                    }
                    else {
                        render = this.checkPlay;
                        res.loadRes(a, d);
                    }
                }
                else {
                    render = this.render;
                }
                if (old != render) {
                    if (old) {
                        display.off("enterFrame" /* ENTER_FRAME */, old, this);
                    }
                    if (render) {
                        display.on("enterFrame" /* ENTER_FRAME */, render, this);
                    }
                }
                this._render = render;
            }
        };
        AniRender.prototype.onRecycle = function () {
            if (true) {
                if ($gm._recordAni) {
                    delete $gm._aniRecords[this._guid];
                }
            }
            var handler = this.handler;
            if (handler) {
                handler.call(-1992 /* AniBeforeRecycle */, this);
                handler.recycle();
                this.handler = undefined;
            }
            delete AniRender._renderByGuid[this._guid];
            this.state = 3 /* Recycled */;
            var display = this.display;
            if (display) {
                //这里必须移除和可视对象的关联
                this.display = undefined;
                display.off("enterFrame" /* ENTER_FRAME */, this.render, this);
                if ((this.recyclePolicy & 1 /* RecycleDisplay */) == 1 /* RecycleDisplay */) {
                    display.recycle();
                }
            }
            if (this._aniInfo) {
                this._aniInfo.loose(this);
                this._aniInfo = undefined;
            }
            this.idx = 0;
            this._guid = NaN;
            if (this.waitTexture) {
                this.waitTexture = false;
            }
            this.loop = undefined;
            this._render = undefined;
        };
        AniRender.prototype.onSpawn = function () {
            this.f = 0;
            this.state = 0;
            this.recyclePolicy = 3 /* RecycleAll */;
            this._playSpeed = 1;
        };
        AniRender.prototype.init = function (aniInfo, display, guid) {
            this._aniInfo = aniInfo;
            this.display = display;
            if (aniInfo.state == 2 /* COMPLETE */) {
                display.res = aniInfo.getResource();
            }
            else {
                aniInfo.bind(this);
            }
            this._guid = guid;
        };
        /**
         * 获取ANI动画
         *
         * @static
         * @param {string} uri    动画地址
         * @param {AniOption} [option] 动画的参数
         * @returns (description)
         */
        AniRender.getAni = function (uri, option, qid) {
            if (true && !uri) {
                true && jy.ThrowError("\u521B\u5EFA\u4E86\u6CA1\u6709uri\u7684AniRender");
            }
            var aniDict = $DD.ani;
            var aniInfo = aniDict[uri];
            if (!aniInfo) {
                aniInfo = new jy.AniInfo();
                aniInfo.key = uri;
                aniDict[uri] = aniInfo;
            }
            aniInfo.qid = qid;
            var res = aniInfo.getResource();
            res && (res.qid = qid);
            var display = jy.recyclable(jy.ResourceBitmap);
            var ani = jy.recyclable(AniRender);
            var guid, stop;
            if (option) {
                guid = option.guid;
                var pos = option.pos;
                var x = option.x, y = option.y;
                if (pos) {
                    x = pos.x;
                    y = pos.y;
                }
                if (x != undefined) {
                    display.x = x;
                }
                if (y != undefined) {
                    display.y = y;
                }
                var scale = option.scale;
                if (scale != undefined) {
                    display.scaleX = display.scaleY = scale;
                }
                stop = option.stop;
                var parent_1 = option.parent;
                if (parent_1) {
                    var idx = option.childIdx;
                    if (idx == undefined) {
                        parent_1.addChild(display);
                    }
                    else {
                        parent_1.addChildAt(display, idx);
                    }
                }
                var loop = option.loop;
                ani.loop = loop;
                ani.handler = option.handler;
                var recyclePolicy = option.recyclePolicy;
                if (recyclePolicy == undefined) {
                    recyclePolicy = 3 /* RecycleAll */;
                }
                ani.recyclePolicy = recyclePolicy;
                ani.waitTexture = !!option.waitTexture;
                ani.idx = checkStart(aniInfo, loop, option.start >>> 0); //强制为正整数
            }
            !guid && (guid = this.guid++);
            this._renderByGuid[guid] = ani;
            ani.init(aniInfo, display, guid);
            if (!stop) {
                ani.play();
            }
            return ani;
        };
        /**
         * 获取正在运行的AniRender
         * @param guid  唯一标识
         */
        AniRender.getRunningAni = function (guid) {
            return this._renderByGuid[guid];
        };
        /**
         * 回收某个特效
         * @param {number} guid AniRender的唯一标识
         */
        AniRender.recycle = function (guid) {
            var ani = this._renderByGuid[guid];
            if (ani) {
                ani.recycle();
            }
        };
        /***********************************静态方法****************************************/
        AniRender._renderByGuid = {};
        AniRender.guid = 1;
        return AniRender;
    }(jy.BaseRender));
    jy.AniRender = AniRender;
    __reflect(AniRender.prototype, "jy.AniRender", ["jy.IRecyclable"]);
    function checkStart(aniInfo, loop, startFrame) {
        var actionInfo = aniInfo.actionInfo;
        if (loop || (loop == undefined && actionInfo && actionInfo.isCircle)) {
            var total = aniInfo.actionInfo.frames.length;
            if (startFrame > total) {
                startFrame = startFrame % total;
            }
        }
        return startFrame;
    }
})(jy || (jy = {}));
//# sourceMappingURL=AniRender.js.map