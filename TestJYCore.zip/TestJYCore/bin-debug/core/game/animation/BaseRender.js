var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var jy;
(function (jy) {
    /**
     * 基础渲染器
     * @author 3tion
     *
     */
    var BaseRender = (function () {
        function BaseRender() {
            /**原始方向索引 */
            this.d = 0;
            /**原始帧数索引 */
            this.f = 0;
            /**
             * 数组的索引
             */
            this.idx = 0;
            /**
             * 下一次需要重新计算渲染的时间
             */
            this.nextRenderTime = 0;
            /**
             * 当前渲染时间
             */
            this.renderedTime = 0;
            /**
             * 播放速度，默认为1倍速度<br/>
             * 值越高，速度越快
             */
            this._playSpeed = 1;
        }
        BaseRender.onSlowRender = function () {
            jy.dispatch(-1996 /* SlowRender */);
        };
        Object.defineProperty(BaseRender.prototype, "playSpeed", {
            /**
             * 播放速度，默认为1倍速度<br/>
             * 值越高，速度越快
             */
            get: function () {
                return this._playSpeed;
            },
            /**
             * 设置播放速度
             */
            set: function (value) {
                if (value < 0) {
                    value = 0;
                }
                if (value != this._playSpeed) {
                    this._playSpeed = value;
                }
            },
            enumerable: true,
            configurable: true
        });
        /**
         *  处理数据帧
         */
        BaseRender.prototype.onData = function (actionInfo, now) {
            var nextRenderTime = this.nextRenderTime;
            if (nextRenderTime < now) {
                var renderedTime = this.renderedTime;
                var delta = now - nextRenderTime;
                var frames_1 = actionInfo.frames;
                //当前帧
                var idx = this.idx;
                //最后一帧
                var flen = frames_1.length - 1;
                var ps = this.playSpeed * BaseRender.globalPlaySpeed;
                var frame = void 0;
                if (ps > 0) {
                    if (delta > 500) {
                        if (nextRenderTime != 0) {
                            true && printSlow(delta);
                            if (BaseRender.dispatchSlowRender) {
                                jy.Global.callLater(BaseRender.onSlowRender);
                            }
                        }
                        nextRenderTime = now;
                        renderedTime = now;
                    }
                    ps = 1 / ps;
                    if (ps < 0.01) {
                        ps = 0.01;
                    }
                    do {
                        frame = frames_1[idx];
                        if (frame) {
                            var tt = frame.t * ps; // 容错
                            if (tt <= 0) {
                                tt = now - renderedTime;
                                break;
                            }
                            nextRenderTime = renderedTime + tt;
                            if (nextRenderTime < now) {
                                if (frame.e) {
                                    this.dispatchEvent(frame.e, now);
                                }
                                renderedTime = nextRenderTime;
                                idx++;
                            }
                            else {
                                break;
                            }
                        }
                        else {
                            this.idx = 0;
                            if (this.isComplete(actionInfo)) {
                                this.doComplete(now);
                                return;
                            }
                            else {
                                idx = 0;
                                frame = frames_1[0];
                                break;
                            }
                        }
                    } while (true);
                }
                else {
                    frame = frames_1[idx];
                }
                this.idx = idx;
                this.renderedTime = renderedTime;
                this.nextRenderTime = nextRenderTime;
                this.willRenderFrame = frame;
                if (idx > flen) {
                    this.idx = 0;
                    if (this.isComplete(actionInfo)) {
                        this.doComplete(now);
                        return;
                    }
                }
            }
        };
        BaseRender.prototype.isComplete = function (info) {
            return !info.isCircle;
        };
        /**
         * 渲染帧时调用
         *
         * @param {number} now (description)
         */
        BaseRender.prototype.doRender = function (now) {
            if (this.willRenderFrame) {
                this.clearRes();
                this.renderFrame(this.willRenderFrame, now);
            }
        };
        /**
         * 渲染指定帧
         * @param frame
         * @param now
         */
        BaseRender.prototype.renderFrame = function (frame, now) {
            this.f = frame.f;
        };
        /**
         * 清理当前帧
         */
        BaseRender.prototype.clearRes = function () {
        };
        /**
         * 派发事件
         * @param event     事件名
         * @param now       当前时间
         */
        BaseRender.prototype.dispatchEvent = function (event, now) {
        };
        /**
         * 渲染结束
         * @param now       当前时间
         */
        BaseRender.prototype.doComplete = function (now) {
        };
        /**
         * 全局单位播放速度
         */
        BaseRender.globalPlaySpeed = 1;
        return BaseRender;
    }());
    jy.BaseRender = BaseRender;
    __reflect(BaseRender.prototype, "jy.BaseRender", ["jy.IDrawInfo"]);
    if (true) {
        var printSlow = (function () {
            return function (delta) {
                jy.Global.callLater(print, 0, null, delta);
            };
            function print(delta) {
                console.log("Render\u4E0A\u6B21\u6267\u884C\u65F6\u95F4\u548C\u5F53\u524D\u65F6\u95F4\u5DEE\u503C\u8FC7\u957F[" + delta + "]");
            }
        })();
    }
})(jy || (jy = {}));
//# sourceMappingURL=BaseRender.js.map