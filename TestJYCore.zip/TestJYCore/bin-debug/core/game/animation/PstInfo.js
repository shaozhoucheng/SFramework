var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
/**
 * 资源打包信息
 * AS3的版本中实现了5种打包方式
 * H5中实现了2种（2 按动作打包，4 单方向单动作打包），不过后面只会使用4（单方向单动作）进行打包，其他方式弃用
 * @author 3tion
 */
var jy;
(function (jy) {
    // /**
    //  * 打包类型
    //  */
    // const enum PakSaveType {
    //     // /**全部打包 (弃用)*/
    //     // PAK_ALL = 0,
    //     // /**1 按方向打包 (弃用)*/
    //     // PAK_BY_DIRECTION = 1,
    //     // /**2 按动作打包 (弃用)*/
    //     // PAK_BY_ACTION = 2,
    //     // /**3 混合打包 (弃用)*/
    //     // PAK_COMPLEX = 3,
    //     /**
    //      * 单方向单动作
    //      */
    //     PAK_ONE_A_D = 4
    // }
    // var parsers: { [index: number]: { new (key: string): SplitInfo } };
    // /**
    //  * 获取处理器
    //  */
    // function getParsers(t: number): { new (key: string): SplitInfo } {
    //     if (!parsers) {
    //         parsers = {};
    //         // 后续H5项目只使用PAK_ONE_A_D一种打包方式
    //         // 其他方式弃用
    //         // parsers[PakSaveType.PAK_BY_ACTION] = ActionSInfo;
    //         parsers[PakSaveType.PAK_ONE_A_D] = OneADSInfo;
    //     }
    //     return parsers[t];
    // }
    /**
     * 存储pst信息
     */
    var PstInfo = (function () {
        function PstInfo() {
            this.urCreator = jy.UnitResource;
        }
        /**
         * 获取施法点
         * @param {number} action 动作标识
         * @param {number} direction 方向
         * @return {Point} 如果有施法点
         */
        PstInfo.prototype.getCastPoint = function (action, direction) {
            if (this.castPoints) {
                var pt = this.castPoints[jy.ADKey.get(action, direction)];
                if (pt) {
                    return pt;
                }
            }
            return;
        };
        PstInfo.prototype.getResKey = function (direction, action) {
            return this.splitInfo.getResKey(direction, action);
        };
        PstInfo.prototype.getADKey = function (r) {
            return this.splitInfo.adDict[r];
        };
        PstInfo.prototype.init = function (key, data) {
            this.key = key;
            this._resources = {};
            // let parserRef = getParsers(data[0]);
            // if (!parserRef) {
            //     return;
            // }
            // let parser = new parserRef(key);
            var parser = new SplitInfo(key);
            //处理数据
            this.splitInfo = parser;
            parser.parseSplitInfo(data[1]);
            this.frames = parser.parseFrameData(data[2]);
            // extra [0] 头顶坐标Y number
            // extra [1] 受创点Y number
            // extra [2] 施法点 {[index:string]:Array<Array<number>(2)>(5)}
            var extra = data[3];
            if (extra) {
                this.headY = +extra[0];
                this.hurtY = +extra[1];
                var castInfo = extra[2];
                if (castInfo) {
                    var castPoints = {};
                    this.castPoints = castPoints;
                    for (var a in castInfo) {
                        var aInfo = castInfo[a];
                        for (var d = 0; d < 8; d++) {
                            var pInfo = aInfo[d > 4 ? 8 - d : d];
                            if (pInfo) {
                                castPoints[jy.ADKey.get(+a, d)] = { x: +pInfo[0], y: +pInfo[1] };
                            }
                        }
                    }
                }
            }
        };
        /**
         * 解析图片数据
         * 用于批量处理数据
         */
        PstInfo.prototype.decodeImageDatas = function (data) {
            for (var uri in data) {
                var res = this.getResource(uri);
                res.decodeData(data[uri]);
            }
        };
        PstInfo.prototype.getResource = function (uri) {
            var res = this._resources[uri];
            if (!res) {
                res = new this.urCreator(uri, this);
                this._resources[uri] = res;
            }
            return res;
        };
        /**
         * 获取单位资源
         */
        PstInfo.prototype.getUnitResource = function (uri) {
            var res = this.getResource(uri);
            res.loadData();
            return res;
        };
        return PstInfo;
    }());
    jy.PstInfo = PstInfo;
    __reflect(PstInfo.prototype, "jy.PstInfo");
    /**
     * 资源打包分隔信息
     * 只保留了最主流的单动作，单方向
     */
    var SplitInfo = (function () {
        function SplitInfo(key) {
            this._key = key;
        }
        SplitInfo.prototype.parseFrameData = function (data) {
            this._resDict = {};
            var adDict = this.adDict = {};
            var frames = {};
            /**
             * 有效的动作数组，有些动作是自定义出来的，不是原始动作
             */
            var alist = [];
            for (var key in data) {
                var a = +key;
                var aInfo = jy.getActionInfo(data[a], a);
                frames[a] = aInfo;
                var fs = aInfo.frames;
                for (var i = 0; i < fs.length; i++) {
                    var frame = fs[i];
                    alist.pushOnce(frame.a);
                }
            }
            //检查有效动作
            for (var i = 0; i < alist.length; i++) {
                var a = alist[i];
                for (var d = 0; d < 5; d++) {
                    var res = this.getResKey(d, a);
                    adDict[res] = jy.ADKey.get(a, d);
                }
            }
            return frames;
        };
        SplitInfo.prototype.parseSplitInfo = function (infos) {
            this._n = infos.n || "{a}{d}";
            this._a = infos.a || _pst$a;
            this._d = infos.d;
        };
        SplitInfo.prototype.getResKey = function (direction, action) {
            var key = jy.ADKey.get(action, direction);
            var res = this._resDict[key];
            if (!res) {
                this._resDict[key] = res = this._n.substitute({ "f": this._key, "a": getRep(action, this._a), "d": getRep(direction, this._d) });
            }
            return res;
        };
        return SplitInfo;
    }());
    jy.SplitInfo = SplitInfo;
    __reflect(SplitInfo.prototype, "jy.SplitInfo");
    function getRep(data, repArr) {
        var str = data + "";
        if (repArr && (data in repArr)) {
            str = repArr[data];
        }
        return str;
    }
    jy.ADKey = {
        /**
         * 得到 A(动作)D(方向)的标识
         *
         * @static
         * @param {number} action A(动作)标识
         * @param {number} direction D(方向)标识
         * @returns {number} A(动作)D(方向)的标识
         */
        get: function (action, direction) {
            return action << 8 | direction;
        },
        /**
         * 从A(动作)D(方向)的标识中获取 A(动作)标识
         *
         * @static
         * @param {ADKey} adKey A(动作)D(方向)的标识
         * @returns {number} A(动作)标识
         */
        getAction: function (adKey) {
            return adKey >> 8;
        },
        /**
         * 从A(动作)D(方向)的标识中获取 D(方向)标识
         *
         * @static
         * @param {ADKey} adKey A(动作)D(方向)的标识
         * @returns {number} D(方向)标识
         */
        getDirection: function (adKey) {
            return adKey & 0xff;
        }
    };
    /**
     * 默认动作数组
     * [a,b,c....x,y,z,A,B,C...X,Y,Z]
     */
    var _pst$a = function () {
        var a = [];
        m(97, 122); //a-z
        m(65, 90); //A-Z
        return a;
        function m(f, t) {
            for (var i = f; i <= t; i++) {
                a.push(String.fromCharCode(i));
            }
        }
    }();
    // /**
    //  * 单方向单动作分隔数据
    //  * 后面只用这种打包方式
    //  */
    // export class OneADSInfo extends SplitInfo {
    //     protected _n: string;
    //     protected _a: any[];
    //     protected _d: any[];
    //     parseFrameData(data: any) {
    //         this._resDict = {};
    //         let adDict = this.adDict = {};
    //         let frames: { [index: number]: ActionInfo } = {};
    //         for (let key in data) {
    //             let a = +key;
    //             frames[a] = getActionInfo(data[a], a);
    //             for (let d = 0; d < 5; d++) {
    //                 let res = this.getResUri(d, a);
    //                 adDict[res] = ADKey.get(a, d);
    //             }
    //         }
    //         return frames;
    //     }
    //     parseSplitInfo(infos: any) {
    //         this._n = infos.n || "{a}{d}";
    //         this._a = infos.a || _pst$a;
    //         this._d = infos.d;
    //     }
    //     getResUri(direction: number, action: number): string {
    //         let key = ADKey.get(action, direction);
    //         let res = this._resDict[key];
    //         if (!res) {
    //             this._resDict[key] = res = this._n.substitute({ "f": this._key, "a": getRep(action, this._a), "d": getRep(direction, this._d) });
    //         }
    //         return res;
    //         function getRep(data: number, repArr: any[]): string {
    //             var str = data + "";
    //             if (repArr && (data in repArr)) {
    //                 str = repArr[data];
    //             }
    //             return str;
    //         }
    //     }
    // }
    // /**
    //  * 基于动作打包的分隔数据
    //  * @deprecated 已弃用
    //  */
    // export class ActionSInfo extends SplitInfo {
    //     parseSplitInfo(infos: any[]) {
    //         var flag = true;
    //         if (infos) {
    //             this._resDict = {};
    //             this._subReses = [];
    //             var _adDict: { [index: string]: number[] } = {};
    //             this.adDict = _adDict;
    //             var _resDict = this._resDict;
    //             var _subReses = this._subReses;
    //             var len = infos.length;
    //             for (let i = 0; i < len; i++) {
    //                 let pak = infos[i][0];
    //                 let acts = pak.a;
    //                 if (acts) {
    //                     let dlen = acts.length;
    //                     if (dlen) {
    //                         flag = false;
    //                         let res = this.getFileName(pak);
    //                         let arr = _adDict[res];
    //                         if (!arr) {
    //                             arr = [];
    //                             _adDict[res] = arr;
    //                         }
    //                         if (res && _subReses.indexOf(res) == -1) {
    //                             _subReses.push(res);
    //                         }
    //                         for (let j = 0; j < dlen; j++) {
    //                             let a = acts[j];
    //                             _resDict[a] = res;
    //                             //push所有动作的数据
    //                             arr.push(SplitInfo.getADKey(a, 0), SplitInfo.getADKey(a, 1), SplitInfo.getADKey(a, 2), SplitInfo.getADKey(a, 3), SplitInfo.getADKey(a, 4));
    //                         }
    //                     }
    //                 }
    //             }
    //         }
    //         if (flag) {
    //             throw new Error("no pak split info");
    //         }
    //     }
    //     getFileName(pakInfo: any) {
    //         var dirs = pakInfo.a;
    //         return PakSaveType.PAK_BY_ACTION + "-" + dirs.join("_");
    //     }
    //     getResource(direction: number, action: number): string {
    //         return this._resDict[action];
    //     }
    // }
})(jy || (jy = {}));
//# sourceMappingURL=PstInfo.js.map