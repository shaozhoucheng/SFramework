var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var jy;
(function (jy) {
    /**
     * 用于处理无方向的动画信息
     * @author 3tion
     *
     */
    var AniInfo = (function (_super) {
        __extends(AniInfo, _super);
        function AniInfo() {
            var _this = _super.call(this) || this;
            /**
             * 加载状态
             */
            _this.state = 0 /* UNREQUEST */;
            return _this;
        }
        /**
         * 绑定渲染器
         * @param render
         */
        AniInfo.prototype.bind = function (render) {
            var state = this.state;
            if (state != 2 /* COMPLETE */) {
                if (!this._refList) {
                    this._refList = [];
                }
                this._refList.push(render);
                if (state == 0 /* UNREQUEST */) {
                    var uri = this.uri = "a/" /* Ani */ + this.key + "/" + "d.json" /* CfgFile */;
                    var url = this.url = jy.ConfigUtils.getResUrl(uri);
                    jy.Res.load(uri, url, jy.CallbackInfo.get(this.dataLoadComplete, this), this.qid);
                    this.state = 1 /* REQUESTING */;
                }
            }
        };
        /**
         * 资源加载完成
         */
        AniInfo.prototype.dataLoadComplete = function (item) {
            var uri = item.uri, data = item.data;
            if (uri == this.uri) {
                if (data) {
                    this.init(this.key, data);
                    if (this._refList) {
                        for (var _i = 0, _a = this._refList; _i < _a.length; _i++) {
                            var render = _a[_i];
                            render.callback();
                        }
                    }
                }
                else {
                    this.state = 2 /* COMPLETE */;
                }
                this._refList = undefined;
            }
        };
        /**
         * 和渲染器解除绑定
         * @param render
         */
        AniInfo.prototype.loose = function (render) {
            var _refList = this._refList;
            if (_refList) {
                _refList.remove(render);
            }
        };
        AniInfo.prototype.init = function (key, data) {
            _super.prototype.init.call(this, key, data[0]);
            var res = new jy.UnitResource("a/" /* Ani */ + key, this);
            res.qid = this.qid;
            res.decodeData(data[1]);
            this._resources = res;
            this.state = 2 /* COMPLETE */;
        };
        AniInfo.prototype.getResource = function (uri) {
            return this._resources;
        };
        Object.defineProperty(AniInfo.prototype, "actionInfo", {
            get: function () {
                var frames = this.frames;
                return frames && frames[0];
            },
            enumerable: true,
            configurable: true
        });
        return AniInfo;
    }(jy.PstInfo));
    jy.AniInfo = AniInfo;
    __reflect(AniInfo.prototype, "jy.AniInfo");
})(jy || (jy = {}));
//# sourceMappingURL=AniInfo.js.map