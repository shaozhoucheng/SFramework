var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var jy;
(function (jy) {
    /**
     * 拆分的资源
     * @author 3tion
     */
    var SplitUnitResource = (function () {
        function SplitUnitResource(uri, url) {
            /**
             * 资源加载状态
             */
            this.state = 0 /* UNREQUEST */;
            this.uri = uri;
            this.url = url;
            this.textures = [];
        }
        Object.defineProperty(SplitUnitResource.prototype, "isStatic", {
            get: function () {
                return this.state == 1 /* REQUESTING */; //加载中，本次不允许卸载
            },
            enumerable: true,
            configurable: true
        });
        /**
         * 绑定纹理集
         *
         * @param {{ [index: number]: egret.Texture[][] }} textures (description)
         * @param {number[]} adKeys (description)
         */
        SplitUnitResource.prototype.bindTextures = function (textures, adKey) {
            var a = jy.ADKey.getAction(adKey);
            var dTextures = textures[a];
            if (dTextures) {
                var d = jy.ADKey.getDirection(adKey);
                var textures_1 = dTextures[d];
                if (textures_1) {
                    for (var i = 0; i < textures_1.length; i++) {
                        this.bindTexture(textures_1[i]);
                    }
                }
            }
        };
        /**
         * 绑定纹理
         */
        SplitUnitResource.prototype.bindTexture = function (tex) {
            var textures = this.textures;
            if (!~textures.indexOf(tex)) {
                textures.push(tex);
                if (this.bmd) {
                    tex.$bitmapData = this.bmd;
                }
            }
        };
        SplitUnitResource.prototype.load = function () {
            if (this.state == 0 /* UNREQUEST */) {
                this.state = 1 /* REQUESTING */;
                jy.Res.load(this.uri, this.url, jy.CallbackInfo.get(this.loadComplete, this), this.qid);
            }
        };
        /**
         * 资源加载完成
         */
        SplitUnitResource.prototype.loadComplete = function (item) {
            var uri = item.uri, data = item.data;
            if (uri == this.uri) {
                if (data) {
                    var bmd = data.bitmapData;
                    this.bmd = bmd;
                    this.state = 2 /* COMPLETE */;
                    //将已经请求的位图设置为加载完成的位图
                    var textures = this.textures;
                    for (var i = 0; i < textures.length; i++) {
                        var texture = textures[i];
                        if (texture) {
                            texture.$bitmapData = bmd;
                        }
                    }
                }
                else {
                    this.state = -1 /* FAILED */;
                }
            }
        };
        SplitUnitResource.prototype.dispose = function () {
            var textures = this.textures;
            for (var i = 0; i < textures.length; i++) {
                var texture = textures[i];
                if (texture) {
                    texture.dispose();
                }
            }
            textures.length = 0;
            if (this.bmd) {
                this.bmd = undefined;
            }
            //将加载状态标记为未加载
            this.state = 0 /* UNREQUEST */;
        };
        return SplitUnitResource;
    }());
    jy.SplitUnitResource = SplitUnitResource;
    __reflect(SplitUnitResource.prototype, "jy.SplitUnitResource", ["jy.IResource"]);
})(jy || (jy = {}));
//# sourceMappingURL=SplitUnitResource.js.map