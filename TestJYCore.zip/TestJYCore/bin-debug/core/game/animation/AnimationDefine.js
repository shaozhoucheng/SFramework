var jy;
(function (jy) {
    /**
     * 获取帧数据
     * 为数组的顺序："a", "f", "t", "e", "d"
     * @param {*} data 如果无法获取对应属性的数据，会使用默认值代替  a: 0, d: -1, f: 0, t: 100
     * @returns
     */
    function getFrameInfo(data) {
        var def = { a: 0, d: -1, f: 0, t: 100 };
        var keys = ["a", "f", "t", "e", "d"];
        if (!Array.isArray(data)) {
            if (typeof data === "object") {
                for (var i = 0; i < 5; i++) {
                    var key = keys[i];
                    if (data[key] == undefined) {
                        data[key] = def[key];
                    }
                }
                return data;
            }
            else {
                return def;
            }
        }
        var f = jy.DataUtils.getData(data, keys, def);
        if (+f.e == 0) {
            f.e = undefined;
        }
        if (f.t == -1) {
            f.t = Infinity;
        }
        return f;
    }
    jy.getFrameInfo = getFrameInfo;
    /**
     * 获取动作数据
     *
     * @param {any} data
     * @param {number} key
     * @returns
     */
    function getActionInfo(data, key) {
        var aInfo = {};
        aInfo.key = key;
        var d = data[0]; //放数组0号位的原因是历史遗留，之前AS3项目的结构有这个数组，做h5项目的时候忘记修改
        var totalTime = 0;
        var j = 0;
        d.forEach(function (item) {
            var f = getFrameInfo(item);
            totalTime += f.t;
            d[j++] = f; // 防止有些错误的空数据
        });
        aInfo.frames = d;
        aInfo.totalTime = totalTime;
        aInfo.isCircle = !!data[1];
        return aInfo;
    }
    jy.getActionInfo = getActionInfo;
    var customActionKey = -0.5; // 使用0.5 防止和手动加的key重复
    /**
     * 获取自定义动作
     * 如果无法获取对应属性的数据，会使用默认值代替
     * a: 0, d: -1, f: 0, t: 100
     * @static
     * @param {any[]} actions 动作序列  如果无法获取对应属性的数据，会使用默认值代替  a: 0, d: -1, f: 0, t: 100
     * @param {number} [key] 动作标识，需要使用整数
     * @return {CustomAction}   自定义动作
     */
    function getCustomAction(actions, key) {
        key = key || customActionKey--;
        var frames = [];
        var totalTime = 0;
        for (var i = 0; i < actions.length; i++) {
            var frame = getFrameInfo(actions[i]);
            frames[i++] = frame;
            totalTime += frame.t;
        }
        return { key: key, frames: frames, totalTime: totalTime };
    }
    jy.getCustomAction = getCustomAction;
})(jy || (jy = {}));
//# sourceMappingURL=AnimationDefine.js.map