var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
/**
 * @author 3tion
 */
var jy;
(function (jy) {
    function setJTexture(bmp, texture) {
        bmp.texture = texture;
        var tx, ty;
        if (texture) {
            (tx = texture.tx, ty = texture.ty);
        }
        bmp.anchorOffsetX = tx || 0;
        bmp.anchorOffsetY = ty || 0;
    }
    /**
     * 单位资源<br/>
     * 图片按动作或者方向的序列帧，装箱处理后的图片位图资源<br/>
     * 以及图片的坐标信息
     */
    var UnitResource = (function () {
        function UnitResource(key, pstInfo) {
            this.state = 0 /* UNREQUEST */;
            this.key = key;
            var uri = this.uri = key + "/" + "d.json" /* CfgFile */;
            this.url = jy.ConfigUtils.getResUrl(uri);
            this.pst = pstInfo;
        }
        /**
         * 解析数据
         */
        UnitResource.prototype.decodeData = function (data) {
            var _datas = {};
            for (var action in data) {
                var dData = [];
                _datas[action] = dData;
                var actData = data[action];
                if (!actData)
                    continue;
                for (var d = 0, len = actData.length; d < len; d++) {
                    var fData = [];
                    dData[d] = fData;
                    var dirData = actData[d];
                    if (!dirData)
                        continue;
                    for (var f = 0, flen = dirData.length; f < flen; f++) {
                        if (dirData[f] !== 0) {
                            fData[f] = getTextureFromImageData(dirData[f]);
                        }
                    }
                }
            }
            this._datas = _datas;
            this.state = 2 /* COMPLETE */;
            return;
            /**
             * 从数据中获取纹理
             */
            function getTextureFromImageData(data) {
                var texture = new egret.Texture();
                var sx = data[0];
                var sy = data[1];
                texture.tx = data[2] || 0;
                texture.ty = data[3] || 0;
                var width = data[4];
                var height = data[5];
                texture.$initData(sx, sy, width, height, 0, 0, width, height, width, height);
                return texture;
            }
        };
        /**
         * 加载数据
         */
        UnitResource.prototype.loadData = function () {
            if (this.state == 0 /* UNREQUEST */) {
                this.state = 1 /* REQUESTING */;
                jy.Res.load(this.uri, this.url, jy.CallbackInfo.get(this.dataLoadComplete, this), this.qid);
            }
        };
        /**
         * 资源加载完成
         */
        UnitResource.prototype.dataLoadComplete = function (item) {
            var uri = item.uri, data = item.data;
            if (uri == this.uri) {
                this.decodeData(data);
            }
        };
        /**
         * 将资源渲染到位图容器中
         *
         * @param {egret.Bitmap} bitmap 要被绘制的位图
         * @param {IDrawInfo} drawInfo  绘制信息
         * @param {number} now 当前时间戳
         * @returns {boolean} true 表示绘制成功
         *                    其他情况标识绘制失败
         * @memberof UnitResource
         */
        UnitResource.prototype.draw = function (bitmap, drawInfo, now) {
            var frame = this.getTexture(drawInfo);
            var a = drawInfo.a, d = drawInfo.d;
            if (frame) {
                var res = this.loadRes(d, a);
                res.lastUseTime = jy.Global.now;
                if (frame.bitmapData) {
                    setJTexture(bitmap, frame);
                    return true;
                }
                else {
                    if (res.state == 2 /* COMPLETE */) {
                        res.bindTexture(frame);
                    }
                }
            }
            setJTexture(bitmap, this.placehoder);
        };
        /**
         * 根据 `动作``方向``帧数`获取纹理数据
         * @param info
         */
        UnitResource.prototype.getTexture = function (info) {
            var datas = this._datas;
            if (datas) {
                var a = info.a, f = info.f, d = info.d;
                var dDatas = datas[a];
                if (dDatas) {
                    var frames_1 = dDatas[d];
                    if (frames_1) {
                        var frame = frames_1[f];
                        if (frame) {
                            return frame;
                        }
                    }
                }
            }
        };
        UnitResource.prototype.loadRes = function (direction, action) {
            var r = this.pst.getResKey(direction, action);
            var uri = this.getUri2(r);
            return jy.ResManager.get(uri, this.noRes, this, uri, r);
        };
        UnitResource.prototype.noRes = function (uri, r) {
            var tmp = new jy.SplitUnitResource(uri, this.getUrl(uri));
            tmp.qid = this.qid;
            tmp.bindTextures(this._datas, this.pst.getADKey(r));
            tmp.load();
            return tmp;
        };
        UnitResource.prototype.getUri = function (direction, action) {
            return this.getUri2(this.pst.getResKey(direction, action));
        };
        UnitResource.prototype.getUri2 = function (resKey) {
            return this.key + "/" + resKey + ".png" /* PNG */;
        };
        UnitResource.prototype.getUrl = function (uri) {
            return jy.ConfigUtils.getResUrl(uri + jy.Global.webp);
        };
        UnitResource.prototype.isResOK = function (direction, action) {
            var uri = this.getUri(direction, action);
            var res = jy.ResManager.getResource(uri);
            return !!(res && res.bmd);
        };
        /**
         * 遍历Res所有资源
         * @param { (uri: string, adKey: number): any } forEach 如果 forEach 方法返回 真 ，则停止遍历
         */
        UnitResource.prototype.checkRes = function (forEach) {
            var dict = this.pst.splitInfo.adDict;
            for (var resKey in dict) {
                var uri = this.getUri2(resKey);
                if (forEach(uri, dict[resKey])) {
                    return;
                }
            }
        };
        return UnitResource;
    }());
    jy.UnitResource = UnitResource;
    __reflect(UnitResource.prototype, "jy.UnitResource");
})(jy || (jy = {}));
//# sourceMappingURL=UnitResource.js.map