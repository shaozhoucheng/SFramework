var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var jy;
(function (jy) {
    /**
     * 资源显示用位图
     */
    var ResourceBitmap = (function (_super) {
        __extends(ResourceBitmap, _super);
        function ResourceBitmap() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            /**
             * z方向的坐标
             *
             * @type {number}
             */
            _this.z = 0;
            return _this;
        }
        Object.defineProperty(ResourceBitmap.prototype, "depth", {
            get: function () {
                return this.y + this.z;
            },
            enumerable: true,
            configurable: true
        });
        /**
         * 当前资源是否成功渲染
         *
         * @param {IDrawInfo} drawInfo
         * @param {number} now
         * @returns
         * @memberof ResourceBitmap
         */
        ResourceBitmap.prototype.draw = function (drawInfo, now) {
            var res = this.res;
            if (res) {
                return res.draw(this, drawInfo, now);
            }
        };
        ResourceBitmap.prototype.onRecycle = function () {
            jy.removeDisplay(this);
            this.removeAllListeners();
            this.res = undefined;
            this.rotation = 0;
            this.x = 0;
            this.y = 0;
            this.z = 0;
            this.scaleX = 1;
            this.scaleY = 1;
            this.anchorOffsetX = 0;
            this.anchorOffsetY = 0;
            this.texture = undefined;
        };
        return ResourceBitmap;
    }(egret.Bitmap));
    jy.ResourceBitmap = ResourceBitmap;
    __reflect(ResourceBitmap.prototype, "jy.ResourceBitmap", ["jy.IRecyclable", "jy.IDepth"]);
})(jy || (jy = {}));
//# sourceMappingURL=ResourceBitmap.js.map