var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var jy;
(function (jy) {
    /**
     * 2d游戏的引擎管理游戏层级关系<br/>
     * @author 3tion
     *
     */
    var GameEngine = (function (_super) {
        __extends(GameEngine, _super);
        function GameEngine(stage) {
            var _this = _super.call(this) || this;
            _this._layers = [];
            /**
             * 排序层
             */
            _this._sortedLayers = [];
            _this._stage = stage;
            _this.init();
            return _this;
        }
        GameEngine.init = function (stage, ref) {
            ref = ref || GameEngine;
            GameEngine.instance = new ref(stage);
        };
        // static addLayerConfig(id: number, parentid: number = 0, ref?: new (id: number) => GameLayer) {
        //     let lc = <LayerConfig>{};
        //     lc.id = id;
        //     lc.parentid = parentid;
        //     lc.ref = ref || BaseLayer;
        //     GameEngine.layerConfigs[id] = lc;
        // }
        /**
          * 单位坐标发生变化时调用
          */
        GameEngine.invalidateSort = function () {
            GameEngine.instance.invalidateSort();
        };
        /**
         * 单位坐标发生变化时调用
         */
        GameEngine.prototype.invalidateSort = function () {
            this._sortDirty = true;
        };
        Object.defineProperty(GameEngine.prototype, "viewRect", {
            get: function () {
                return this._viewRect;
            },
            enumerable: true,
            configurable: true
        });
        /**
         * 获取或创建容器
         */
        GameEngine.prototype.getLayer = function (id) {
            var layers = this._layers;
            var layer = layers[id];
            if (!layer) {
                var cfg = GameEngine.layerConfigs[id];
                if (!cfg) {
                    return;
                }
                var ref = cfg.ref;
                layer = new ref(id);
                this.addLayer(layer, cfg);
                layers[id] = layer;
                if (layer instanceof jy.SortedLayer) {
                    this._sortedLayers.push(layer);
                }
            }
            return layer;
        };
        /**
         *
         * @param {GameLayer} layer 要调整的层级
         * @param {number} newid 新的层级id
         * @param {boolean} [awake=true] 是否执行一次awake
         */
        GameEngine.prototype.changeId = function (layer, newid, awake) {
            if (awake === void 0) { awake = true; }
            var id = layer.id;
            if (id != newid) {
                var layers = this._layers;
                if (layers[id] == layer) {
                    layers[id] = undefined;
                }
                layers[newid] = layer;
                layer.id = newid;
            }
            awake && this.awakeLayer(newid);
        };
        /**
         * 将指定
         *
         * @param {GameLayerID} layerID
         *
         * @memberOf GameEngine
         */
        GameEngine.prototype.sleepLayer = function (layerID) {
            var layer = this._layers[layerID];
            jy.removeDisplay(layer);
        };
        GameEngine.prototype.awakeLayer = function (layerID) {
            var layer = this._layers[layerID];
            var cfg = GameEngine.layerConfigs[layerID];
            if (layer) {
                this.addLayer(layer, cfg);
            }
        };
        GameEngine.prototype.addLayer = function (layer, cfg) {
            if (cfg && cfg.parentid) {
                var parent_1 = this.getLayer(cfg.parentid);
                if (parent_1 instanceof egret.DisplayObjectContainer) {
                    this.addLayerToContainer(layer, parent_1);
                }
            }
            else {
                this.addLayerToContainer(layer, this._stage);
            }
        };
        GameEngine.prototype.addLayerToContainer = function (layer, container) {
            var children = container.$children;
            var id = layer.id;
            var j = 0;
            for (var i = 0, len = children.length; i < len; i++) {
                var child = children[i];
                if (layer != child) {
                    var childLayer = child;
                    if (childLayer.id > id) {
                        break;
                    }
                    j++;
                }
            }
            container.addChildAt(layer, j);
        };
        GameEngine.prototype.init = function () {
            this.initConfigs();
            this.initLayers();
        };
        /**
        * 初始化默认添加的层
        */
        GameEngine.prototype.initLayers = function () {
            // [GameLayerID.Tip,GameLayerID.TopUI, GameLayerID.PopUI, GameLayerID.BaseUI, GameLayerID.UI].forEach(ui => {
            //     let layer = this.getLayer(ui);
            //     layer.scaleX = layer.scaleY = 0.75;
            // })
            this.getLayer(9999 /* Out */);
            this.getLayer(9000 /* Tip */);
            this.getLayer(8900 /* TopUI */);
            this.getLayer(8700 /* PopUI */);
            this.getLayer(8100 /* BaseUI */);
            this.getLayer(8000 /* UI */);
            this.getLayer(1000 /* Game */);
            // this._gameScene = this.getLayer(GameLayerID.GameScene);
            this.getLayer(1700 /* GameScene */);
            this.getLayer(1790 /* CeilEffect */);
            this.getLayer(1780 /* SortedUI */);
            this.getLayer(1770 /* GameEffect */);
            this.getLayer(1760 /* Sorted */);
            this.getLayer(1750 /* Bottom */);
            this.getLayer(1740 /* BottomEffect */);
            // this._background = <TileMapLayer>this.getLayer(GameLayerID.Background);
            this.getLayer(1710 /* Mini */);
        };
        GameEngine.prototype.initConfigs = function () {
            new LayerConfig(9999 /* Out */);
            new LayerConfig(9000 /* Tip */);
            new LayerConfig(8900 /* TopUI */, 8000 /* UI */);
            new LayerConfig(8700 /* PopUI */, 8000 /* UI */);
            new LayerConfig(8300 /* MiddleUI */, 8000 /* UI */);
            new LayerConfig(8100 /* BaseUI */, 8000 /* UI */);
            new LayerConfig(8000 /* UI */);
            new LayerConfig(1000 /* Game */);
            new LayerConfig(1900 /* Mask */, 1000 /* Game */);
            new LayerConfig(1800 /* TopEffect */, 1000 /* Game */);
            new LayerConfig(1700 /* GameScene */, 1000 /* Game */);
            new LayerConfig(1790 /* CeilEffect */, 1700 /* GameScene */);
            new LayerConfig(1780 /* SortedUI */, 1700 /* GameScene */, jy.SortedLayer);
            new LayerConfig(1770 /* GameEffect */, 1700 /* GameScene */);
            new LayerConfig(1760 /* Sorted */, 1700 /* GameScene */, jy.SortedLayer);
            new LayerConfig(1750 /* Bottom */, 1700 /* GameScene */);
            new LayerConfig(1740 /* BottomEffect */, 1700 /* GameScene */);
            new LayerConfig(1730 /* Background */, 1700 /* GameScene */);
            new LayerConfig(1710 /* Mini */, 1700 /* GameScene */);
        };
        GameEngine.layerConfigs = {};
        return GameEngine;
    }(egret.EventDispatcher));
    jy.GameEngine = GameEngine;
    __reflect(GameEngine.prototype, "jy.GameEngine");
    /**
     * 层级配置
     */
    var LayerConfig = (function () {
        function LayerConfig(id, parentid, ref) {
            if (parentid === void 0) { parentid = 0; }
            this.id = id;
            this.parentid = parentid;
            this.ref = ref || jy.GameLayer;
            GameEngine.layerConfigs[id] = this;
        }
        return LayerConfig;
    }());
    __reflect(LayerConfig.prototype, "LayerConfig");
})(jy || (jy = {}));
//# sourceMappingURL=GameEngine.js.map