var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var jy;
(function (jy) {
    /**
     * 旋转的屏幕抖动
     * 角度统一从0开始，正向或者逆向旋转，振幅从最大到0
     *
     * @export
     * @class CircleShake
     * @extends {BaseShake}
     * @author 3tion
     */
    var CircleShake = (function (_super) {
        __extends(CircleShake, _super);
        function CircleShake() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        /**
         *
         *
         * @param {number} swing        最大振幅
         * @param {number} endRad       结束角度
         * @param {number} [cx]         单位X方向基准值      一般为单位初始值
         * @param {number} [cy]         单位Y方向基准值      一般为单位初始值
         * @param {number} [time=150]   单圈的时间，震动总时间为  endRad / Math.PI2 * time
         * @returns
         */
        CircleShake.prototype.init = function (swing, endRad, cx, cy, time) {
            if (time === void 0) { time = 150; }
            this._eR = endRad;
            /**
             * 总时间
             */
            var total = endRad / Math.PI2 * time;
            if (swing < 0) {
                swing = -swing;
            }
            this._swing = swing;
            this._dRad = endRad / total;
            this._dSwing = -swing / total;
            this._total = total;
            this.setTargetPos(cx, cy);
            return this;
        };
        CircleShake.prototype.tick = function (duration, outPt) {
            var rad = duration * this._dRad;
            var swing = this._swing + duration * this._dSwing;
            outPt.x = Math.round(this._cx + swing * Math.cos(rad));
            outPt.y = Math.round(this._cy + swing * Math.sin(rad));
        };
        return CircleShake;
    }(jy.BaseShake));
    jy.CircleShake = CircleShake;
    __reflect(CircleShake.prototype, "jy.CircleShake");
})(jy || (jy = {}));
//# sourceMappingURL=CircleShake.js.map