var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var jy;
(function (jy) {
    /**
     * 旋转抖动
     * 屏幕朝顺时针/逆时针方向抖动一定角度
     * 抖动从0绝对距离的偏移开始，当中间角度时，达到最大偏移值，最后回到0偏移值
     * 偏移:swing*( sin 0) 角度：startRad ---------->偏移:swing*( sin Math.PI/2) 角度： (startRad + endRad)/2 -------------->偏移:swing*( sin Math.PI) 角度： endRad
     *
     * @export
     * @class RotateShake
     * @extends {BaseShake}
     * @author 3tion
     */
    var RotateShake = (function (_super) {
        __extends(RotateShake, _super);
        function RotateShake() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        /**
         *
         *
         * @param {number} startRad     起始角度
         * @param {number} endRad       结束角度
         * @param {number} [swing=30]   最大振幅
         * @param {number} [cx]         单位X方向基准值      一般为单位初始值
         * @param {number} [cy]         单位Y方向基准值      一般为单位初始值
         * @param {number} [total=150]  总时间
         * @returns
         */
        RotateShake.prototype.init = function (startRad, endRad, swing, cx, cy, total) {
            if (swing === void 0) { swing = 30; }
            if (total === void 0) { total = 150; }
            this._sR = startRad;
            this._eR = endRad;
            this._swing = swing;
            this._dRad = (endRad - startRad) / total;
            this.setTargetPos(cx, cy);
            return this;
        };
        RotateShake.prototype.tick = function (duration, outPt) {
            var rad = duration * this._dRad;
            var swing = this._swing + Math.sin(duration * Math.PI);
            outPt.x = Math.round(this._cx + swing * Math.cos(rad));
            outPt.y = Math.round(this._cy + swing * Math.sin(rad));
        };
        return RotateShake;
    }(jy.BaseShake));
    jy.RotateShake = RotateShake;
    __reflect(RotateShake.prototype, "jy.RotateShake");
})(jy || (jy = {}));
//# sourceMappingURL=RotateShake.js.map