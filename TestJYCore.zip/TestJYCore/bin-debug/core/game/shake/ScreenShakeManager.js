var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var jy;
(function (jy) {
    /**
     * 屏幕抖动管理器
     *
     * @export
     * @class ScreenShakeManager
     */
    var ScreenShakeManager = (function () {
        function ScreenShakeManager() {
            /**
             * 释放可震动
             *
             * @type {boolean}
             */
            this.shakable = true;
            this._pt = { x: 0, y: 0 };
            this._tmp = new egret.Rectangle();
            // private clearShakeRect() {
            //     GameEngine.instance.checkViewRect = undefined;
            // }
        }
        ScreenShakeManager.prototype.setLimits = function (width, height, x, y) {
            if (width === void 0) { width = Infinity; }
            if (height === void 0) { height = Infinity; }
            if (x === void 0) { x = 0; }
            if (y === void 0) { y = 0; }
            this._limits = new egret.Rectangle(x, y, width, height);
            return this;
        };
        /**
         * 开始一个新的震动
         *
         * @template T
         * @param {T} shake
         * @returns T
         */
        ScreenShakeManager.prototype.start = function (shake) {
            if (this.shakable) {
                var cur = this._cur;
                if (cur) {
                    cur.end();
                }
                this._cur = shake;
                var engine = jy.GameEngine.instance;
                var layer = engine.getLayer(1000 /* Game */);
                if (cur != shake) {
                    shake.setShakeTarget(layer);
                }
                shake.start();
                this._st = jy.Global.now;
                egret.startTick(this.tick, this);
                // engine.checkViewRect = this.checkViewRect;
                // Global.clearCallLater(this.clearShakeRect);
            }
            return shake;
        };
        // private checkViewRect = (rect: egret.Rectangle) => {
        //     let limits = this._limits;
        //     let tmp = this._tmp;
        //     let x = rect.x - 50;
        //     let y = rect.y - 50;
        //     let width = rect.width + 100;
        //     let height = rect.height + 100;
        //     if (limits) {
        //         tmp.setTo(Math.clamp(x, limits.x, limits.width), Math.clamp(y, limits.y, limits.height), Math.clamp(width, limits.x, limits.width), Math.clamp(height, limits.y, limits.height));
        //     } else {
        //         tmp.setTo(x, y, width, height);
        //     }
        //     return tmp;
        //     // return this._tmp.setTo(rect.x - 50, rect.y - 50, rect.width + 100, rect.height + 100);
        // }
        ScreenShakeManager.prototype.tick = function () {
            var shake = this._cur;
            var duration = jy.Global.now - this._st;
            if (duration < shake.total) {
                var pt = this._pt;
                var cur = this._cur;
                cur.tick(duration, pt);
                var target = cur.target;
                var limits = this._limits;
                if (limits) {
                    var rect = jy.GameEngine.instance.viewRect;
                    var px = pt.x;
                    var py = pt.y;
                    var x = void 0, y = void 0;
                    if (px < 0) {
                        var lx = limits.x;
                        var rx = rect.x;
                        x = rx + px > lx ? px : lx;
                    }
                    else {
                        var dw = limits.width - rect.width;
                        x = px < dw ? px : dw;
                    }
                    if (py < 0) {
                        var ly = limits.y;
                        var ry = rect.y;
                        y = ry + py > ly ? px : ly;
                    }
                    else {
                        var dh = limits.height - rect.height;
                        y = py < dh ? py : dh;
                    }
                    target.x = x;
                    target.y = y;
                }
            }
            else {
                shake.end();
                // Global.callLater(this.clearShakeRect, 30000);
            }
            return true;
        };
        return ScreenShakeManager;
    }());
    jy.ScreenShakeManager = ScreenShakeManager;
    __reflect(ScreenShakeManager.prototype, "jy.ScreenShakeManager");
})(jy || (jy = {}));
//# sourceMappingURL=ScreenShakeManager.js.map