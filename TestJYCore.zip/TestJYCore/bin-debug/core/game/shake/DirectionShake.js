var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var jy;
(function (jy) {
    /**
     * 带方向的震动
     *
     * @export
     * @class DirectionShake
     * @extends {BaseShake}
     */
    var DirectionShake = (function (_super) {
        __extends(DirectionShake, _super);
        function DirectionShake() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        /**
         *
         * 初始化一个有方向的Shake
         * @param {number} fx           起点x
         * @param {number} fy           起点y
         * @param {number} tx           目标x
         * @param {number} ty           目标y
         * @param {number} [cx]         单位X方向基准值      一般为单位初始值
         * @param {number} [cy]         单位Y方向基准值      一般为单位初始值
         * @param {number} [swing=30]   最大振幅，振幅会按次数衰减到0
         * @param {number} [count=3]    震动次数，此次数指的是 单摆摆动的从`最低点`到`最高点`再回到`最低点`，  即一次完整的摆动 下->左->下   或者 下->右->下
         * @param {number} [time=90]    单次震动的时间
         */
        DirectionShake.prototype.init1 = function (fx, fy, tx, ty, cx, cy, swing, count, time) {
            if (swing === void 0) { swing = 30; }
            if (count === void 0) { count = 3; }
            if (time === void 0) { time = 90; }
            var dx = tx - fx;
            var dy = ty - fy;
            var dist = Math.sqrt(dx * dx + dy * dy);
            this.init(dx / dist, dy / dist, cx, cy, swing, count, time);
        };
        /**
         * 初始化一个有方向的Shake
         * @param {number} rad              方向(弧度)			使用Math.atan2(toY-fromY,toX-fromX)
         * @param {number} [cx]             单位X方向基准值      一般为单位初始值
         * @param {number} [cy]             单位Y方向基准值      一般为单位初始值
         * @param {number} [swing=30]       最大振幅，振幅会按次数衰减到0
         * @param {number} [count=3]        震动次数，此次数指的是 单摆摆动的从`最低点`到`最高点`再回到`最低点`，  即一次完整的摆动 下->左->下   或者 下->右->下
         * @param {number} [time=90]        单次震动的时间
         */
        DirectionShake.prototype.init2 = function (rad, cx, cy, swing, count, time) {
            if (swing === void 0) { swing = 30; }
            if (count === void 0) { count = 3; }
            if (time === void 0) { time = 90; }
            this.init(Math.cos(rad), Math.sin(rad), cx, cy, swing, count, time);
        };
        DirectionShake.prototype.init = function (cos, sin, cx, cy, swing, count, time) {
            if (swing === void 0) { swing = 30; }
            if (count === void 0) { count = 3; }
            if (time === void 0) { time = 90; }
            if (~~time < 30) {
                time = 30;
            }
            if (~~count < 1) {
                count = 1;
            }
            var total = time * count;
            this._dSwing = -swing / total;
            this._dRad = Math.PI / time;
            this._count = count;
            this.setTargetPos(cx, cy);
            this._cos = cos;
            this._sin = sin;
            this._total = total;
            return this;
        };
        DirectionShake.prototype.tick = function (duration, outPt) {
            var swing = this._dSwing * duration * Math.sin(duration * this._dRad);
            outPt.x = Math.round(this._cx + this._cos * swing);
            outPt.y = Math.round(this._cy + this._sin * swing);
        };
        return DirectionShake;
    }(jy.BaseShake));
    jy.DirectionShake = DirectionShake;
    __reflect(DirectionShake.prototype, "jy.DirectionShake");
})(jy || (jy = {}));
//# sourceMappingURL=DirectionShake.js.map