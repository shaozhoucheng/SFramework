var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var jy;
(function (jy) {
    /**
     *
     * 震动的基本实现
     * @export
     * @class BaseShake
     * @implements {Shake}
     * @author 3tion
     */
    var BaseShake = (function () {
        function BaseShake() {
        }
        Object.defineProperty(BaseShake.prototype, "target", {
            get: function () {
                return this._target;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(BaseShake.prototype, "total", {
            /**
             * 总执行时间
             */
            get: function () {
                return this._total;
            },
            enumerable: true,
            configurable: true
        });
        BaseShake.prototype.setShakeTarget = function (target) {
            this._target = target;
            return this;
        };
        /**
         * 设置单位基准值
         *
         * @param {number} [cx]
         * @param {number} [cy]
         */
        BaseShake.prototype.setTargetPos = function (cx, cy) {
            var target = this._target;
            if (cx === undefined)
                cx = target ? target.x : 0;
            if (cy === undefined)
                cy = target ? target.y : 0;
            this._cx = cx;
            this._cy = cy;
        };
        BaseShake.prototype.start = function () {
            if (this._target) {
                this._shaking = true;
            }
        };
        BaseShake.prototype.end = function () {
            if (this._shaking) {
                var target = this._target;
                target.x = this._cx;
                target.y = this._cy;
                this._shaking = false;
            }
        };
        /**
         * 销毁的处理
         */
        BaseShake.prototype.dispose = function () {
            this._target = undefined;
        };
        return BaseShake;
    }());
    jy.BaseShake = BaseShake;
    __reflect(BaseShake.prototype, "jy.BaseShake", ["jy.Shake"]);
})(jy || (jy = {}));
//# sourceMappingURL=BaseShake.js.map