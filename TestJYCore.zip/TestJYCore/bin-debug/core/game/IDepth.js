var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var jy;
(function (jy) {
    var DSprite = (function (_super) {
        __extends(DSprite, _super);
        function DSprite() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.depth = 0;
            return _this;
        }
        return DSprite;
    }(egret.Sprite));
    jy.DSprite = DSprite;
    __reflect(DSprite.prototype, "jy.DSprite", ["jy.IDepth"]);
})(jy || (jy = {}));
//# sourceMappingURL=IDepth.js.map