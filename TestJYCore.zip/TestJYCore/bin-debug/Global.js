var jy;
(function (jy) {
    try {
        var supportWebp = document.createElement('canvas').toDataURL('image/webp').indexOf('data:image/webp') == 1;
    }
    catch (err) { }
    var _webp = supportWebp ? ".webp" /* WEBP */ : "";
    var _isNative = egret.Capabilities.engineVersion != "Unknown";
    /**
     *  当前这一帧的时间
     */
    var now = 0;
    /**
     * 按照帧，应该走的时间
     * 每帧根据帧率加固定时间
     * 用于处理逐帧同步用
     */
    var frameNow = 0;
    var _callLater = new jy.CallLater();
    var tweenManager = new jy.TweenManager();
    var _nextTicks = [];
    var _intervals = [];
    /**
     * 注入白鹭的全局Ticker
     */
    function initTick() {
        //@ts-ignore
        var ticker = egret.ticker;
        var update = ticker.render;
        var delta = 0 | 1000 / ticker.$frameRate;
        var temp = [];
        ticker.render = function () {
            var _now = jy.DateUtils.serverTime;
            var dis = _now - now;
            now = _now;
            if (dis > 2000) {
                //有2秒钟大概就是进入过休眠了
                jy.dispatch(-190 /* Awake */);
                frameNow = _now;
            }
            else {
                frameNow += delta;
            }
            if (true) {
                $();
            }
            else if (false) {
                try {
                    $();
                }
                catch (e) {
                    jy.ThrowError("ticker.render", e);
                }
            }
            return;
            function $() {
                //执行顺序  nextTick  callLater TimerUtil  tween  最后是白鹭的更新
                var len = _intervals.length;
                for (var i = 0; i < len; i++) {
                    var cb = _intervals[i];
                    cb.execute(false);
                }
                len = _nextTicks.length;
                var tmp = temp;
                for (var i = 0; i < len; i++) {
                    tmp[i] = _nextTicks[i];
                }
                _nextTicks.length = 0;
                //先复制再操作是为了防止回调过程中，有新增的nextTick
                for (var i = 0; i < len; i++) {
                    tmp[i].execute();
                }
                _callLater.tick(_now);
                jy.TimerUtil.tick(_now);
                tweenManager.tick(dis);
                update.call(ticker);
            }
        };
    }
    function nextTick(callback, thisObj) {
        var args = [];
        for (var _i = 2; _i < arguments.length; _i++) {
            args[_i - 2] = arguments[_i];
        }
        nextTick2(jy.CallbackInfo.get.apply(jy.CallbackInfo, [callback, thisObj].concat(args)));
    }
    function nextTick2(callback) {
        _nextTicks.push(callback);
    }
    /**
     * 动画的全局对象
     * @author 3tion
     *
     */
    jy.Global = {
        initTick: initTick,
        nextTick: nextTick,
        nextTick2: nextTick2,
        callLater: function (callback, time, thisObj) {
            var args = [];
            for (var _i = 3; _i < arguments.length; _i++) {
                args[_i - 3] = arguments[_i];
            }
            return _callLater.callLater.apply(_callLater, [callback, now, time, thisObj].concat(args));
        },
        clearCallLater: function (callback, thisObj) {
            return _callLater.clearCallLater(callback, thisObj);
        },
        callLater2: function (callback, time) {
            return _callLater.callLater2(callback, now, time);
        },
        clearCallLater2: function (callback) {
            return _callLater.clearCallLater2(callback);
        },
        getTween: function (target, props, pluginData, override) {
            return tweenManager.get(target, props, pluginData, override);
        },
        removeTween: function (tween) {
            return tweenManager.removeTween(tween);
        },
        removeTweens: function (target) {
            return tweenManager.removeTweens(target);
        },
        get isNative() {
            return _isNative;
        },
        tweenManager: tweenManager,
        get now() {
            return now;
        },
        get frameNow() {
            return frameNow;
        },
        get webp() {
            return _webp;
        },
        addInterval: function (callback) {
            _intervals.pushOnce(callback);
        },
        removeInterval: function (callback) {
            _intervals.remove(callback);
        },
    };
})(jy || (jy = {}));
//# sourceMappingURL=Global.js.map