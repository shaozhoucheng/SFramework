var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var jy;
(function (jy) {
    var xc;
    (function (xc) {
        var Game = (function (_super) {
            __extends(Game, _super);
            function Game() {
                var _this = _super.call(this) || this;
                egret.ImageLoader.crossOrigin = "anonymous";
                jy.Global.initTick();
                _this.on(egret.Event.ADDED_TO_STAGE, _this.onAddToStage, _this);
                RES.setMaxLoadingThread(4);
                return _this;
            }
            Game.prototype.onAddToStage = function (event) {
                jy.facade.registerInlineMediator(jy.hqg.XXPanelMediator, xc.ModuleId.Servers);
                var stage = this.stage;
                xc.Core.stage = stage;
                xc.ResizeManager.getInstance().init(stage);
                jy.GameEngine.init(stage);
                var engine = jy.GameEngine.instance;
                // let camera = new game.Camera();
                // engine.camera = camera;
                // stage.on(egret.Event.RESIZE, () => {
                //     camera.setSize(stage.stageWidth, stage.stageHeight);
                //     sui.Panel.WIDTH = stage.stageWidth;
                //     sui.Panel.HEIGHT = stage.stageHeight;
                // }, this)
                // mvc.Facade.on(lingyu.NetEvent.WEB_COMPLETE, this.connectHandler, this);
                // mvc.Facade.on(lingyu.NetEvent.WEB_FAILED, this.failHandler, this);
                new xc.PreLoader();
            };
            Game.prototype.failHandler = function () {
                // $reportGameStep(gameReport.SOCKET_CONN_FAIL);
            };
            //连接成功，直接拉取角色列表(后期用于拉取登入参数)
            Game.prototype.connectHandler = function () {
                // $reportGameStep(gameReport.SOCKET_CONNENT);
                // var param = egret["baseParams"];
                // Core.params = param;
                // var uid = param['uid'];
                // var pid = param['pid'];
                // new AdditionRequest();
                // if (!Core.login) {
                //     let base = egret["baseParams"];
                //     let newPlayer = base["newPlayer"];
                //     new PreRegiest();
                //     if (!newPlayer) {
                //         FightController.getInstance().removeAll();
                //         DropItemHelper.getInstance().removeAll();
                //         // new PreRegiest();
                //         AIManager.getInstance().clear();
                //         CoreFunction.systemTips = new SystemTips();
                //         //初始化技能
                //         SkillManager.init();
                //         //角标初始化
                //         getSinglon(BadgeManage).init();
                //         new ActivityDefine();
                //         alarmClock.getDate = Core.getServerDate;
                //         alarmClock.start();
                //     } else {
                //         mvc.Facade.on(lingyu.EventConst.DATA_LOCATOR, () => {
                //             FightController.getInstance().removeAll();
                //             DropItemHelper.getInstance().removeAll();
                //             CoreFunction.systemTips = new SystemTips();
                //             //初始化技能
                //             SkillManager.init();
                //             //角标初始化
                //             getSinglon(BadgeManage).init();
                //             new ActivityDefine();
                //             alarmClock.getDate = Core.getServerDate;
                //             alarmClock.start();
                //         }, this);
                //     }
                //     //
                //     $facade.getProxy(ServiceName.RoleService, (roleService: RoleService) => {
                //         roleService.getRoleList_C2S({ userId: uid, pid: pid, serverId: Core.serverVO.id, timestamp: Global.now, verify: "needAmd5", loginType: 1 });
                //         // roleService.getRoleList_C2S({ userId: "59046e2f1126887006", pid: "hoodinn", serverId:2, timestamp: Global.now, verify: "needAmd5", loginType: 1 });
                //     }, this);
                //     this.loginCompleteHandler();
                // } else {
                //     chuanqi.FightController.getInstance().removeAll();
                //     chuanqi.DropItemHelper.getInstance().removeAll();
                //     DmgEffect.dispose();
                //     chuanqi.AIManager.getInstance().clear();
                //     $facade.getProxy(ServiceName.RoleService, (roleService: RoleService) => {
                //         roleService.getRoleList_C2S({ userId: uid, pid: pid, serverId: Core.serverVO.id, timestamp: Global.now, verify: "needAmd5", loginType: 1 });
                //         //  roleService.getRoleList_C2S({ userId: "59046e2f1126887006", pid: "hoodinn", serverId:2, timestamp: Global.now, verify: "needAmd5", loginType: 1 });
                //     }, this);
                //     if (Core.roleDTO) {
                //         $facade.getProxy(ServiceName.RoleService, (roleService: RoleService) => {
                //             roleService.todoLogin(Core.roleDTO);
                //         }, this);
                //     }
                // }
            };
            Game.prototype.loginCompleteHandler = function () {
                // let facade = $facade;
                // facade.off(lingyu.NetEvent.LOGIN_COMPLETE, this.loginCompleteHandler, this);
                // this.createGameScene();
            };
            // private hero: UnitEntity;
            /**
            * 创建游戏场景
            * Create a game scene
            */
            Game.prototype.createGameScene = function () {
                // Core.start();
                // let $fps = FPSHelp.getInstance();
                // // let facade = $facade;
                // if (DEBUG) {
                //     getSinglon(KeyBoardManage);//键盘事件管理
                //     // new CaculatePanel();
                //     DebugPanel.getInstance();
                // }
                // let target = new NumberStep(1, 10286);
            };
            return Game;
        }(egret.DisplayObjectContainer));
        xc.Game = Game;
        __reflect(Game.prototype, "jy.xc.Game");
    })(xc = jy.xc || (jy.xc = {}));
})(jy || (jy = {}));
//# sourceMappingURL=Game.js.map