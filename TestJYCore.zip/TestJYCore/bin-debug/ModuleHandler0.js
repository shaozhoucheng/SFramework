var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var jy;
(function (jy) {
    // import IModuleCfg = mvc.IModuleCfg;
    /**
     *
     * @author builder
     *
     */
    var ModuleHandler0 = (function () {
        function ModuleHandler0() {
            // super();
        }
        /**
         * 打开某个模块
         * @param cfg
         */
        ModuleHandler0.prototype.show = function (cfg) {
            var args = [];
            for (var _i = 1; _i < arguments.length; _i++) {
                args[_i - 1] = arguments[_i];
            }
            //找到指定模块，并打开面板
            jy.facade.getMediator(cfg.id, this._showMediator, this, cfg, args);
        };
        ModuleHandler0.prototype.showTest = function (name) {
            jy.facade.getMediator(name, this._showMediator, this, null, null);
        };
        ModuleHandler0.prototype._showMediator = function (mediator) {
            var args = [];
            for (var _i = 1; _i < arguments.length; _i++) {
                args[_i - 1] = arguments[_i];
            }
            var cfg = args[0];
            var params = args[1];
            var preModuleID = params[0];
            var view = mediator.view;
            if (preModuleID) {
                // view.preModuleID = preModuleID;
            }
            var layer = jy.GameEngine.instance.getLayer(cfg.containerID);
            layer.addChild(view);
            // if (layer) {
            //     view.show(layer);
            // } else {
            //     console.log("mediator " + mediator.name + "without the layer");
            // }
        };
        ModuleHandler0.prototype.hide = function (cfg) {
            //找到指定模块，并打开面板
            // $facade.getMediator(cfg.id, this._hideMediator, this, cfg);
        };
        ModuleHandler0.prototype._hideMediator = function (mediator, args) {
            // let view: sui.Panel = mediator.view as sui.Panel;
            // view.hide();
        };
        return ModuleHandler0;
    }());
    jy.ModuleHandler0 = ModuleHandler0;
    __reflect(ModuleHandler0.prototype, "jy.ModuleHandler0", ["jy.ModuleHandler"]);
})(jy || (jy = {}));
//# sourceMappingURL=ModuleHandler0.js.map