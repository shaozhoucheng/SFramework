var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var jy;
(function (jy) {
    var hqg;
    (function (hqg) {
        /**
             * 由导出工具生成
             * https://github.com/eos3tion/ExportUIFromFlash
             * 生成时间：2018-07-19 17:16:36
             */
        var XXPanelMediator = (function (_super) {
            __extends(XXPanelMediator, _super);
            function XXPanelMediator() {
                return _super.call(this, jy.xc.ModuleId.Servers) || this;
            }
            XXPanelMediator.prototype.init = function () {
                var v = new jy.Panel();
                v.bind("lib", "ui.test.XXPanel");
                this.view = v;
            };
            XXPanelMediator.prototype.awake = function () {
                console.log("i'm in ");
            };
            return XXPanelMediator;
        }(jy.Mediator));
        hqg.XXPanelMediator = XXPanelMediator;
        __reflect(XXPanelMediator.prototype, "jy.hqg.XXPanelMediator");
    })(hqg = jy.hqg || (jy.hqg = {}));
})(jy || (jy = {}));
//# sourceMappingURL=XXPanelMediator.js.map