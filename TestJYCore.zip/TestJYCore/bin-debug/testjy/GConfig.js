var jy;
(function (jy) {
    var xc;
    (function (xc) {
        xc.ConfigKey = {
            // Hero: "Hero",
            GongNeng: "GongNeng",
        };
        function rP(key, CfgCreator, idkey) {
            if (idkey === void 0) { idkey = "id"; }
            jy.DataLocator.regCommonParser(key, CfgCreator, idkey);
        }
        function rE(key) {
            jy.DataLocator.regExtra(key);
        }
        function initData() {
            var C = xc.ConfigKey;
            var P = jy.xc;
            // 	rP(C.Hero, HeroCfg);
            rP(C.GongNeng, P.GongNengCfg);
            // rP(C.JianZhu, JianZhuCfg);
        }
        xc.initData = initData;
    })(xc = jy.xc || (jy.xc = {}));
})(jy || (jy = {}));
//# sourceMappingURL=GConfig.js.map