var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var jy;
(function (jy) {
    var xc;
    (function (xc) {
        var ResizeManager = (function () {
            function ResizeManager() {
            }
            ResizeManager.getInstance = function () {
                if (!this._instance) {
                    this._instance = new ResizeManager();
                }
                return this._instance;
            };
            ResizeManager.prototype.init = function (stage) {
                this._stage = stage;
                this._dislist = [];
                this._layList = [];
                this._hoffArr = [];
                this._voffArr = [];
                this._stage.on(egret.Event.RESIZE, this.onstageResize, this);
            };
            /**
             *添加一个元件，相对于舞台的布局
             *
             * @ param {egret.DisplayObject} dis (description)
             * @ param {number} layout (sui.Layout)
             * @ param {number} hoffset 在大布局的基础上，水平方向上的再偏移量（右移传正，左移传负）
             * @ param {number} voffset 在大布局的基础上，垂直方向上的再偏移量（下移传正，上移传负）
             */
            ResizeManager.prototype.add = function (dis, layout, hoffset, voffset) {
                if (hoffset === void 0) { hoffset = 0; }
                if (voffset === void 0) { voffset = 0; }
                dis.layoutType = layout;
                this._dislist.push(dis);
                this._layList.push(layout);
                this._hoffArr.push(hoffset);
                this._voffArr.push(voffset);
                if (!dis.stage) {
                    dis.on(egret.Event.ADDED_TO_STAGE, this.onDisAdded, this);
                }
                else {
                    jy.Layout.layout(dis, layout, hoffset, voffset, true, true, this._stage);
                }
            };
            /**
             * 移除元件
             *
             * @param {egret.DisplayObject} dis (description)
             * @returns (description)
             */
            ResizeManager.prototype.remove = function (dis) {
                var index = this._dislist.indexOf(dis);
                if (index < 0)
                    return;
                dis.off(egret.Event.ADDED_TO_STAGE, this.onDisAdded, this);
                this._dislist.splice(index, 1);
                this._layList.splice(index, 1);
                this._hoffArr.splice(index, 1);
                this._voffArr.splice(index, 1);
            };
            ResizeManager.prototype.onDisAdded = function (e) {
                var dis = e.target;
                var index = this._dislist.indexOf(dis);
                if (index < 0)
                    return;
                jy.Layout.layout(dis, this._layList[index], this._hoffArr[index], this._voffArr[index], true, true, this._stage);
            };
            /**刷新位置 */
            ResizeManager.prototype.refreshLayout = function (dis) {
                var index = this._dislist.indexOf(dis);
                if (index < 0)
                    return;
                jy.Layout.layout(dis, this._layList[index], this._hoffArr[index], this._voffArr[index], true, true, this._stage);
            };
            ResizeManager.prototype.onstageResize = function (e) {
                var len = this._dislist.length;
                var dis;
                for (var i = 0; i < len; i++) {
                    dis = this._dislist[i];
                    jy.Layout.layout(dis, this._layList[i], this._hoffArr[i], this._voffArr[i], true, true, this._stage);
                    dis.stageResize();
                }
            };
            return ResizeManager;
        }());
        xc.ResizeManager = ResizeManager;
        __reflect(ResizeManager.prototype, "jy.xc.ResizeManager");
    })(xc = jy.xc || (jy.xc = {}));
})(jy || (jy = {}));
//# sourceMappingURL=ResizeManager.js.map