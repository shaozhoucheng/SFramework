/**
 * 游戏的常量的接口定义
 * 子项目自身实现接口
 * @author builder
 */
var jy;
(function (jy) {
    var xc;
    (function (xc) {
    })(xc = jy.xc || (jy.xc = {}));
})(jy || (jy = {}));
//# sourceMappingURL=GameConfig.js.map