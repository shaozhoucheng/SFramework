var jy;
(function (jy) {
    var xc;
    (function (xc) {
        xc.ModuleId = {
            /**服务器主面板 */
            Servers: "Login",
        };
    })(xc = jy.xc || (jy.xc = {}));
})(jy || (jy = {}));
//# sourceMappingURL=ModuleId.js.map