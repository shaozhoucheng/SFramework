var jy;
(function (jy) {
    /**
     * 获取一个单例
     * @returns {any}
     */
    function getInstance(Class) {
        var _instance = Class._instance;
        if (!_instance) {
            Class._instance = _instance = new Class();
        }
        return _instance;
    }
    jy.getInstance = getInstance;
})(jy || (jy = {}));
//# sourceMappingURL=SingleInstance.js.map