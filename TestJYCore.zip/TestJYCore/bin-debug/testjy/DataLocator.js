var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var jy;
(function (jy) {
    /**
     * 配置加载器<br/>
     * 用于预加载数据的解析
     * @author builder
     *
     */
    var DataLocator = (function () {
        function DataLocator() {
        }
        /**
         * 注册配置解析
         * @param key       配置的标识
         * @param parser    解析器
         */
        DataLocator.regParser = function (key, parser) {
            this.parsers[key] = parser;
            this._plist.push(key);
        };
        // 弃用此方法，数据全部打包
        // /**
        //  * 所有配置为独立文件解析所有数据
        //  */
        // public static parseDatas() {
        //     var parsers = this.parsers;
        //     for (let key of this._plist) {
        //         let parser = parsers[key];
        //         this.data[key] = parser(RES.getRes(key));
        //         RES.destroyRes(key);
        //     }
        //     //处理额外数据
        //     let extraData = this.extraData;
        //     for (let key in extraData) {
        //         let skey = "$" + key;
        //         let raw: any[] = RES.getRes(skey);
        //         RES.destroyRes(skey);
        //         let i = 0, len = raw.length, data: { [index: string]: any } = {};
        //         while (i < len) {
        //             let sub: string = raw[i++];
        //             let value = raw[i++];
        //             let test = raw[i];
        //             if (typeof test === "number") {
        //                 i++;
        //                 // 特殊类型数据
        //                 switch (test) {
        //                     case 3://boolean
        //                         value = !!value;
        //                         break;
        //                     case 6://Date
        //                     case 8:
        //                         value = new Date(value * 10000);
        //                         break;
        //                     case 7://TimeVO
        //                         value = new TimeVO(value);
        //                         break;
        //                     default:
        //                         break;
        //                 }
        //             }
        //             data[sub] = value;
        //         }
        //         extraData[key] = data;
        //     }
        //     //清理内存
        //     delete this.parsers;
        //     delete this._plist;
        // }
        /**
         * 解析打包的配置
         */
        DataLocator.parsePakedDatas = function () {
            egret.sys.$TempStage.on(egret.Event.ENTER_FRAME, this.onParse, this, false, 999999);
        };
        /**
         * 解析打包的配置
         */
        DataLocator.parseRegiest = function () {
            //egret.sys.$TempStage.on(egret.Event.ENTER_FRAME, this.onParse, this, false, 999999);
            var parsers = this.parsers;
            var key = "GongNeng";
            var parser = parsers[key];
            var configs = RES.getRes("regiest");
            var data = parser(configs[key]);
            if (data) {
                this.data[key] = data;
            }
            key = "JieMianHuChi";
            parser = parsers[key];
            data = parser(configs[key]);
            if (data) {
                this.data[key] = data;
            }
            key = "GongNengKaiFang";
            parser = parsers[key];
            data = parser(configs[key]);
            if (data) {
                this.data[key] = data;
            }
            // key = "YinDao";
            // parser = parsers[key];
            // data = parser(configs[key]);
            // if (data) { 
            //     this.data[key] = data;
            // }
        };
        DataLocator.onParse = function (e) {
            if (e) {
                this._cost = 0;
            }
            var parsers = this.parsers;
            var configs = RES.getRes("cfgs");
            if (this._plist && this._plist.length) {
                var now = Date.now();
                var key = this._plist.shift();
                var parser = parsers[key];
                var data = parser(configs[key]);
                if (data) {
                    this.data[key] = data;
                }
                this._cost += Date.now() - now;
                // if (this._cost <= 30) {
                //     this.onParse();
                // }
                this.onParse();
            }
            else {
                egret.sys.$TempStage.off(egret.Event.ENTER_FRAME, this.onParse, this);
                RES.destroyRes("cfgs");
                delete this.parsers;
                delete this._plist;
                jy.facade.dispatch(-159 /* DATA_LOCATOR */);
                // Global.setDataParsed();
                //szc
                // let webServer = new shao.WSNetService
                new jy.xc.PreRegiest();
            }
        };
        /**
         * 根据标识获取配置数据
         * @param key   标识
         */
        DataLocator.getData = function (key) {
            return this.data[key];
        };
        /**
         *
         * 设置/覆盖数据
         * @static
         * @param {string} key
         * @param {*} data
         */
        DataLocator.setData = function (key, data) {
            this.data[key] = data;
        };
        /**
         *
         * 获取其他附加数据
         * @static
         * @param {string} key  主标识（模块标识）
         * @param {string} [sub]  子标识，不传子标识则返回全部数据
         */
        DataLocator.getExtra = function (key, sub) {
            var mod = this.extraData[key];
            if (mod) {
                if (sub === undefined) {
                    return mod;
                }
                return mod[sub];
            }
            return undefined;
        };
        /**
         *
         * 注册附加数据
         * @static
         * @param {string} key
         */
        DataLocator.regExtra = function (key) {
            this.extraData[key] = null;
        };
        /**
         * 注册通过H5ExcelTool导出的数据并且有唯一标识的使用此方法注册
         * @param {string}              key             数据的标识
         * @param {{ new (): ICfg }}    CfgCreator      配置的类名
         * @param {string}              [idkey="id"]    唯一标识
         */
        DataLocator.regCommonParser = function (key, CfgCreator, idkey) {
            var _this = this;
            if (idkey === void 0) { idkey = "id"; }
            this.regParser(key, function (data) {
                var dict = {};
                try {
                    jy.DataParseUtil.copyDataListForCfg(CfgCreator, data, _this.commonParserForEach, _this, [dict, idkey, key]);
                }
                catch (err) {
                    if (true) {
                        // ThrowError(`解析配置:${key}出错`);
                    }
                }
                return dict;
            });
        };
        DataLocator.commonParserForEach = function (t, args, idx) {
            var dict = args[0];
            var idKey = args[1];
            if (idKey in t) {
                var id = t[idKey];
                if (true) {
                    if (typeof id === "object") {
                        jy.ThrowError("\u914D\u7F6E" + args[2] + "\u7684\u6570\u636E\u6709\u8BEF\uFF0C\u552F\u4E00\u6807\u8BC6" + idKey + "\u4E0D\u80FD\u4E3A\u5BF9\u8C61");
                    }
                    if (id in dict) {
                        jy.ThrowError("\u914D\u7F6E" + args[2] + "\u7684\u6570\u636E\u6709\u8BEF\uFF0C\u552F\u4E00\u6807\u8BC6" + idKey + "\u6709\u91CD\u590D\u503C\uFF1A" + id);
                    }
                }
                dict[id] = t;
                return true;
            }
            else {
                if (true) {
                    jy.ThrowError("\u914D\u7F6E" + args[2] + "\u89E3\u6790\u6709\u8BEF\uFF0C\u65E0\u6CD5\u627E\u5230\u6307\u5B9A\u7684\u552F\u4E00\u6807\u793A\uFF1A" + idKey + "\uFF0C\u6570\u636E\u7D22\u5F15\uFF1A" + idx);
                }
                return false;
            }
        };
        DataLocator.parsers = {};
        /**
         *
         * 主数据
         * @private
         * @static
         * @type {{ [index: string]: any }}
         */
        DataLocator.data = {};
        /**
         *
         * 其他附加数据，用于代替之前的 公共数据表
         * @private
         * @static
         * @type {{ [index: string]: { [index: string]: any } }}
         */
        DataLocator.extraData = {};
        /**
         *
         * 用于处理顺序
         * @private
         * @static
         */
        DataLocator._plist = [];
        return DataLocator;
    }());
    jy.DataLocator = DataLocator;
    __reflect(DataLocator.prototype, "jy.DataLocator");
})(jy || (jy = {}));
//# sourceMappingURL=DataLocator.js.map