var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var jy;
(function (jy) {
    var xc;
    (function (xc) {
        var PreLoader = (function () {
            function PreLoader() {
                // private onReshowLoader(evt: egret.Event) {
                //     if (!this.reLoaded) {
                //         this.loadUI.visible = true;
                //     }
                // }
                this._loadFlag = false;
                this.reLoaded = false;
                this._dataFlag = false;
                var loadUI = jy.getInstance(xc.LoadingUI);
                // loadUI.showLoadUI(this.initRES, this);
                this.initRES();
                jy.facade.on(-159 /* DATA_LOCATOR */, this.dataParsed, this);
            }
            PreLoader.prototype.newLoader = function (evt) {
                // RES.loadConfig("resource/default.res.json" + "?v=" + Math.random(), "resource/", RES.ResourceItem.TYPE_JSON);
                this.preload3Time = Date.now();
                var key = "preload3";
                RES.addEventListener(RES.ResourceEvent.GROUP_COMPLETE, this.onResourceLoadComplete2, this);
                RES.addEventListener(RES.ResourceEvent.GROUP_PROGRESS, this.onResourceProgress2, this);
                // RES.addEventListener(RES.ResourceEvent.GROUP_LOAD_ERROR, this.onResourceLoadError, this);
                // RES.addEventListener(RES.ResourceEvent.ITEM_LOAD_ERROR, this.onItemLoadError, this);
                RES.loadGroup(key);
            };
            PreLoader.prototype.startLoading = function (e) {
                this._loadFlag = true;
                // PBMessageUtils.structByName = <any>PBMsgDict;
                //初始化模块处理
                var mm = new jy.ModuleManager();
                jy.facade.bindModuleManager(mm);
                this.initMoudleChecker();
                var cfgs = jy.DataLocator.getData(xc.ConfigKey.GongNeng);
                mm.setCfgs(cfgs);
                mm.registerHandler(0, new jy.ModuleHandler0());
                if (this._dataFlag && this._loadFlag) {
                    jy.facade.toggle(xc.ModuleId.Servers);
                }
            };
            PreLoader.prototype.initMoudleChecker = function () {
                var mm = jy.facade.mm;
                var checks;
                checks = {};
                checks[1] = new xc.ModuleChecker();
                mm.checkers = checks;
            };
            PreLoader.prototype.initRES = function () {
                this.defaultTime = Date.now();
                RES.addEventListener(RES.ResourceEvent.CONFIG_COMPLETE, this.onConfigComplete, this);
                if (true) {
                    RES.loadConfig("resource/default.res.json", "resource/");
                }
                else {
                    // RES.loadConfig(Core.domain + "/resource/default.res.json" + "?v=" + Math.random(), Core.domain + "/resource/", RES.ResourceItem.TYPE_JSON);
                }
            };
            PreLoader.prototype.onConfigComplete = function (event) {
                var key = "preload";
                // key = "preload";
                this.preloadTime = Date.now();
                RES.removeEventListener(RES.ResourceEvent.CONFIG_COMPLETE, this.onConfigComplete, this);
                RES.addEventListener(RES.ResourceEvent.GROUP_COMPLETE, this.onResourceLoadComplete, this);
                RES.addEventListener(RES.ResourceEvent.GROUP_PROGRESS, this.onResourceProgress, this);
                RES.addEventListener(RES.ResourceEvent.GROUP_LOAD_ERROR, this.onResourceLoadError, this);
                RES.addEventListener(RES.ResourceEvent.ITEM_LOAD_ERROR, this.onItemLoadError, this);
                RES.loadGroup(key);
            };
            PreLoader.prototype.onResourceProgress = function (event) {
                // let item = event.resItem;
                // let desType = item.data.des;
                // let progress = event.itemsLoaded / event.itemsTotal * 100;
                // let showString = `正在加载${[desType]}`
                // let totalString = `正在加载第${[event.itemsLoaded]}个，共${[event.itemsTotal]}个`;
                // this.loadUI.showDesc(totalString + showString);
                // this.loadUI.showProgress(event.itemsLoaded, event.itemsTotal);
                // ConfigUtils.setPreloadRes(item.url, item.name);
                // let pro = $Int((event.itemsLoaded/event.itemsTotal)*100);
                // if(RELEASE){
                //      reportProgress(pro);
                // }
            };
            PreLoader.prototype.onResourceProgress2 = function (event) {
                // let item = event.resItem;
                // let desType = item.data.des;
                // // let showString = `正在加载${[desType]}`
                // // let totalString = `正在加载第${[event.itemsLoaded]}个，共${[event.itemsTotal]}个`;
                // // this.loadUI.showDesc(totalString + showString);
                // this.loadUI.showProgress(event.itemsLoaded, event.itemsTotal);
                // ConfigUtils.setPreloadRes(item.url, item.name);
            };
            /**
           * preload资源组加载完成
           * Preload resource group is loaded
           */
            PreLoader.prototype.onResourceLoadComplete = function (event) {
                // let base = egret["baseParams"];
                // let newPlayer = base["newPlayer"];
                // if (!newPlayer) {
                //     removeDisplay(this.loadUI);
                // } else {
                //     this.loadUI.visible = false;
                // }
                // let now = Date.now();
                // if (event.groupName == "preload") {
                var m = document.getElementById("Main");
                if (m) {
                    m.style.backgroundImage = "";
                }
                RES.removeEventListener(RES.ResourceEvent.GROUP_COMPLETE, this.onResourceLoadComplete, this);
                RES.removeEventListener(RES.ResourceEvent.GROUP_LOAD_ERROR, this.onResourceLoadError, this);
                RES.removeEventListener(RES.ResourceEvent.ITEM_LOAD_ERROR, this.onItemLoadError, this);
                RES.removeEventListener(RES.ResourceEvent.GROUP_PROGRESS, this.onResourceProgress, this);
                //前期事件管理器（启动游戏后，不建议使用)
                // FacadeInterest.getInstance().start();
                //解析配置数据
                var gameRes = RES.getRes("game");
                xc.initData();
                jy.ConfigUtils.setData(gameRes);
                var ConfigKey = jy.xc.ConfigKey;
                // NameUtils.loadNameLib(gameRes.params.nameLib);
                // WordFilter.loadDirtyWord(gameRes.params.dirty);
                // // LangUtil.loadCode(gameRes.params.code);
                // DataLocator.regParser(ConfigKey.MAP, MapConfigParser);
                // DataLocator.regParser(ConfigKey.PST, PstConfigParser);
                // DataLocator.regParser(ConfigKey.ANI, AniConfigParser);
                // ResourceManager.init();
                // sui.SuiResManager.getInstance().setInlineData("lib", RES.getRes("s_libs"));
                // if (!newPlayer) {
                //     //配置cfgs
                //     DataLocator.parsePakedDatas();
                // } else {
                //     //配置数据特殊处理
                //     DataLocator.parseRegiest();
                //     this._dataFlag = true;
                //     this.startLoading();
                // }
                jy.DataLocator.parsePakedDatas();
            };
            /**
             * preload资源组加载完成
             * Preload resource group is loaded
             */
            PreLoader.prototype.onResourceLoadComplete2 = function (event) {
                var time = Date.now() - this.preload3Time;
                this.reLoaded = true;
                jy.DataLocator.parsePakedDatas();
                // removeDisplay(this.loadUI);
            };
            PreLoader.prototype.dataParsed = function (e) {
                this._dataFlag = true;
                this.startLoading();
            };
            PreLoader.prototype.onResourceLoadError = function (event) {
                jy.ThrowError("Group:" + event.groupName + " has failed to load");
                this.onResourceLoadComplete(event);
            };
            /**
           * 资源组加载出错
           *  The resource group loading failed
           */
            PreLoader.prototype.onItemLoadError = function (event) {
                jy.ThrowError("Url:" + event.resItem.url + " has failed to load");
            };
            return PreLoader;
        }());
        xc.PreLoader = PreLoader;
        __reflect(PreLoader.prototype, "jy.xc.PreLoader");
    })(xc = jy.xc || (jy.xc = {}));
})(jy || (jy = {}));
//# sourceMappingURL=PreLoader.js.map