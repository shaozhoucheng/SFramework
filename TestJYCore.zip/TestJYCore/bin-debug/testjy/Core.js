var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var jy;
(function (jy) {
    var xc;
    (function (xc) {
        /**
         * description
         * @author pb
         */
        var Core = (function () {
            function Core() {
            }
            return Core;
        }());
        xc.Core = Core;
        __reflect(Core.prototype, "jy.xc.Core");
    })(xc = jy.xc || (jy.xc = {}));
})(jy || (jy = {}));
//# sourceMappingURL=Core.js.map