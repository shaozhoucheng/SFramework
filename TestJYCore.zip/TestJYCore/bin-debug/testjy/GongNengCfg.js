var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var jy;
(function (jy) {
    var xc;
    (function (xc) {
        /*-*begin $area1*-*/
        //这里填写类上方的手写内容
        /*-*end $area1*-*/
        /**
       * 由junyouH5数据生成工具，从F://vsworkspace/LearnGit/TestPython/jsons\GongNeng.json生成
       * 创建时间：2018-05-30 16:54:32
       **/
        var GongNengCfg = (function (_super) {
            __extends(GongNengCfg, _super);
            function GongNengCfg() {
                return _super !== null && _super.apply(this, arguments) || this;
            }
            /*-*begin $area2*-*/
            //这里填写类里面的手写内容
            /*-*end $area2*-*/
            GongNengCfg.prototype.decode = function (data) {
                var i = 0;
                var local = {};
                this.id = data[i++];
                this.showtype = data[i++];
                local.showlimit0 = data[i++];
                local.showlimit1 = data[i++];
                local.showlimit2 = data[i++];
                this.limittype = data[i++];
                local.limit0 = data[i++];
                local.limit1 = data[i++];
                local.limit2 = data[i++];
                this.close = data[i++];
                this.name = data[i++];
                this.des = data[i++];
                this.type = data[i++];
                this.containerID = data[i++];
                this.help = data[i++];
                this.scale = data[i++];
                /*-*begin $decode*-*/
                _super.prototype.init.call(this, local);
                /*-*end $decode*-*/
            };
            return GongNengCfg;
        }(xc.BaseMCfg));
        xc.GongNengCfg = GongNengCfg;
        __reflect(GongNengCfg.prototype, "jy.xc.GongNengCfg");
        /*-*begin $area3*-*/
        //这里填写类下发的手写内容
        /*-*end $area3*-*/
    })(xc = jy.xc || (jy.xc = {}));
})(jy || (jy = {}));
//# sourceMappingURL=GongNengCfg.js.map