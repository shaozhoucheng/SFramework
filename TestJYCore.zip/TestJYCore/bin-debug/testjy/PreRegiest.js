var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var jy;
(function (jy) {
    var xc;
    (function (xc) {
        var PreRegiest = (function () {
            function PreRegiest() {
                this.initREG();
            }
            PreRegiest.prototype.initREG = function () {
                // //初始化模块处理
                // facade.registerInlineMediator(jy.hqg.XXPanelMediator, ModuleId.Servers)
                //注册服务
                // facade.registerInlineProxy(LoginService,ServiceName.LoginService);
                // facade.registerInlineProxy(ItemsService,ServiceName.ItemsService);
                //绑定面板处理器和功能标识
                //以下是运营活动面板
            };
            return PreRegiest;
        }());
        xc.PreRegiest = PreRegiest;
        __reflect(PreRegiest.prototype, "jy.xc.PreRegiest");
    })(xc = jy.xc || (jy.xc = {}));
})(jy || (jy = {}));
//# sourceMappingURL=PreRegiest.js.map