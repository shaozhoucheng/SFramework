var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var jy;
(function (jy) {
    var xc;
    (function (xc) {
        var ModuleChecker = (function () {
            function ModuleChecker() {
            }
            ModuleChecker.prototype.check = function (data, showtip) {
                return true;
            };
            ModuleChecker.prototype.adjustLimitDatas = function (showLimits, limits) {
                return false;
            };
            return ModuleChecker;
        }());
        xc.ModuleChecker = ModuleChecker;
        __reflect(ModuleChecker.prototype, "jy.xc.ModuleChecker", ["jy.IModuleChecker", "jy.ILimitChecker"]);
    })(xc = jy.xc || (jy.xc = {}));
})(jy || (jy = {}));
//# sourceMappingURL=ModuleChecker.js.map