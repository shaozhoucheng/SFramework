var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var jy;
(function (jy) {
    var xc;
    (function (xc) {
        var LoadingUI = (function (_super) {
            __extends(LoadingUI, _super);
            function LoadingUI() {
                var _this = _super.call(this) || this;
                _this._testurl = "https://ss2.bdstatic.com/70cFvnSh_Q1YnxGkpoWK1HF6hhy/it/u=3588772980,2454248748&fm=27&gp=0.jpg";
                _this._isReady = false;
                _this.init();
                return _this;
            }
            LoadingUI.prototype.init = function () {
                this._textField = new egret.TextField();
                this.addChild(this._textField);
                this._textField.y = 300;
                this._textField.width = 480;
                this._textField.height = 100;
                this._textField.textAlign = "center";
                // GameEngine.instance.getLayer(GameLayerID.).addChild(this);
                var loader = this._bgLoad = new egret.ImageLoader;
                loader.on(egret.Event.COMPLETE, this.onBgResLoadComplete, this);
                loader.load(this._testurl);
            };
            LoadingUI.prototype.onBgResLoadComplete = function (evt) {
                var texture = new egret.Texture();
                texture._setBitmapData(evt.currentTarget.data);
                var bg = this._bg = new egret.Bitmap(texture);
                this._bgLoad.off(egret.Event.COMPLETE, this.onBgResLoadComplete, this);
                this.addChildAt(bg, 0);
                this._isReady = true;
                if (this._asyncHelper) {
                    this._asyncHelper.readyNow();
                }
            };
            LoadingUI.prototype.addReadyExecute = function (handle, thisObj) {
                var args = [];
                for (var _i = 2; _i < arguments.length; _i++) {
                    args[_i - 2] = arguments[_i];
                }
                var _asyncHelper = this._asyncHelper;
                if (!_asyncHelper) {
                    this._asyncHelper = _asyncHelper = new jy.AsyncHelper();
                    _asyncHelper.isReady = this._isReady;
                }
                _asyncHelper.addReadyExecute(handle, thisObj, args);
            };
            /**
             * 显示加载进度面板
             *
             * @param {Function} callBack
             * @param {*} thisObj
             * @returns
             *
             * @memberOf MainLoadUI
             */
            LoadingUI.prototype.showLoadUI = function (callBack, thisObj) {
                if (!this._isReady) {
                    this.addReadyExecute(this.showLoadUI, this, callBack, thisObj);
                    return;
                }
                if (callBack) {
                    callBack.call(thisObj);
                }
            };
            /**
             * 进度
             *
             * @param {number} value
             * @param {number} max
             *
             * @memberOf MainLoadUI
             */
            LoadingUI.prototype.showProgress = function (value, max) {
                this._textField.text = value + "/" + max;
            };
            return LoadingUI;
        }(egret.Sprite));
        xc.LoadingUI = LoadingUI;
        __reflect(LoadingUI.prototype, "jy.xc.LoadingUI");
    })(xc = jy.xc || (jy.xc = {}));
})(jy || (jy = {}));
//# sourceMappingURL=LoadingUI.js.map