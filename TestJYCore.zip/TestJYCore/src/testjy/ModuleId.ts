﻿module jy.xc {
  export const ModuleId = {

    /**服务器主面板 */
    Servers: "Login",

  }
}