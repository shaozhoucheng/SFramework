module jy.xc {
    export class PreRegiest {
        public constructor() {
            this.initREG();
        }

        public initREG() {
            // //初始化模块处理
            // facade.registerInlineMediator(jy.hqg.XXPanelMediator, ModuleId.Servers)

            //注册服务
            // facade.registerInlineProxy(LoginService,ServiceName.LoginService);
            // facade.registerInlineProxy(ItemsService,ServiceName.ItemsService);



            //绑定面板处理器和功能标识

            //以下是运营活动面板


        }
    }
}