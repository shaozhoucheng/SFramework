module jy.xc{
    export class ModuleChecker implements IModuleChecker{
        
        public check(data:any[],showtip:boolean){
            return true;
        }
        
        public adjustLimitDatas(showLimits:any[],limits:any[]){
            return false;
        }
    }
}