module jy.xc {

    import Event = egret.TouchEvent;
    /**
     * description
     * @author pb
     */
    export class Core {

        public static stage: egret.Stage;

      
    }
    export const enum ShakeType {
        /**
         * 圆形
         */
        Circle = 1,
        /**
         * 方向
         */
        Direction = 2,
        /**
         * 垂直
         */
        Vertical = 3,
        /**
         * 旋转
         */
        Rotation = 4,
        /**
         * 更大强度的圆形
         */
        StrongCircle = 5
    }
}
