module jy.xc {
    export interface IConfigKey {
    	GongNeng:string;     
	}
	ConfigKey = {
		// Hero: "Hero",
		GongNeng: "GongNeng",
		// JianZhu: "JianZhu",
	}
    function rP(key: string, CfgCreator: { new (): ICfg }, idkey: string = "id") {
    	DataLocator.regCommonParser(key, CfgCreator, idkey);
    }
    function rE(key: string) {
    	DataLocator.regExtra(key);
    }
    export function initData() {
    	var C = ConfigKey;
    	var P = jy.xc;
    // 	rP(C.Hero, HeroCfg);
	rP(C.GongNeng, P.GongNengCfg);
	// rP(C.JianZhu, JianZhuCfg);

	}
}