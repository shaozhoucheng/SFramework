module jy {
    // import IModuleCfg = mvc.IModuleCfg;
	/**
	 *
	 * @author builder
	 *
	 */
    export class ModuleHandler0 implements ModuleHandler {
        public constructor() {
            // super();
        }

		/**
		 * 打开某个模块
		 * @param cfg
		 */
        public show(cfg: IModuleCfg, ...args): void {
            //找到指定模块，并打开面板
            facade.getMediator(cfg.id, this._showMediator, this, cfg, args);
        }

        public showTest(name:string)
        {
            facade.getMediator(name, this._showMediator, this, null, null);
        }
        private _showMediator(mediator: Mediator, ...args) {
            let cfg: IModuleCfg = args[0];
            let params = args[1];
            let preModuleID = params[0];
            let view: Panel = mediator.view as Panel;
            if (preModuleID) {
                // view.preModuleID = preModuleID;
            }
            let layer = GameEngine.instance.getLayer(cfg.containerID);
            layer.addChild(view);
            // if (layer) {
            //     view.show(layer);
            // } else {
            //     console.log("mediator " + mediator.name + "without the layer");
            // }
        }

        public hide(cfg: IModuleCfg): void {
            //找到指定模块，并打开面板
            // $facade.getMediator(cfg.id, this._hideMediator, this, cfg);
        }

        private _hideMediator(mediator: Mediator, args: any[]) {
            // let view: sui.Panel = mediator.view as sui.Panel;
            // view.hide();
        }
    }
}
