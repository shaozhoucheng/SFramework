module jy.xc {

    export class Game extends egret.DisplayObjectContainer {
        constructor() {
            super();
            egret.ImageLoader.crossOrigin = "anonymous";
            jy.Global.initTick();
            this.on(egret.Event.ADDED_TO_STAGE, this.onAddToStage, this);
            RES.setMaxLoadingThread(4);
        }



        private onAddToStage(event: egret.Event) {
            facade.registerInlineMediator(jy.hqg.XXPanelMediator, ModuleId.Servers);
            let stage = this.stage;
            Core.stage = stage;
            ResizeManager.getInstance().init(stage);
            GameEngine.init(stage);
            let engine = GameEngine.instance;
            // let camera = new game.Camera();
            // engine.camera = camera;
            // stage.on(egret.Event.RESIZE, () => {
            //     camera.setSize(stage.stageWidth, stage.stageHeight);
            //     sui.Panel.WIDTH = stage.stageWidth;
            //     sui.Panel.HEIGHT = stage.stageHeight;
            // }, this)
            // mvc.Facade.on(lingyu.NetEvent.WEB_COMPLETE, this.connectHandler, this);
            // mvc.Facade.on(lingyu.NetEvent.WEB_FAILED, this.failHandler, this);
            new PreLoader();
        }
        private failHandler() {
            // $reportGameStep(gameReport.SOCKET_CONN_FAIL);
        }



        //连接成功，直接拉取角色列表(后期用于拉取登入参数)
        private connectHandler() {
            // $reportGameStep(gameReport.SOCKET_CONNENT);
            // var param = egret["baseParams"];
            // Core.params = param;
            // var uid = param['uid'];
            // var pid = param['pid'];
            // new AdditionRequest();
            // if (!Core.login) {
            //     let base = egret["baseParams"];
            //     let newPlayer = base["newPlayer"];
            //     new PreRegiest();
            //     if (!newPlayer) {
            //         FightController.getInstance().removeAll();
            //         DropItemHelper.getInstance().removeAll();
            //         // new PreRegiest();
            //         AIManager.getInstance().clear();
            //         CoreFunction.systemTips = new SystemTips();
            //         //初始化技能
            //         SkillManager.init();
            //         //角标初始化
            //         getSinglon(BadgeManage).init();
            //         new ActivityDefine();
            //         alarmClock.getDate = Core.getServerDate;
            //         alarmClock.start();
            //     } else {
            //         mvc.Facade.on(lingyu.EventConst.DATA_LOCATOR, () => {
            //             FightController.getInstance().removeAll();
            //             DropItemHelper.getInstance().removeAll();
            //             CoreFunction.systemTips = new SystemTips();
            //             //初始化技能
            //             SkillManager.init();
            //             //角标初始化
            //             getSinglon(BadgeManage).init();
            //             new ActivityDefine();
            //             alarmClock.getDate = Core.getServerDate;
            //             alarmClock.start();
            //         }, this);
            //     }

            //     //


            //     $facade.getProxy(ServiceName.RoleService, (roleService: RoleService) => {
            //         roleService.getRoleList_C2S({ userId: uid, pid: pid, serverId: Core.serverVO.id, timestamp: Global.now, verify: "needAmd5", loginType: 1 });
            //         // roleService.getRoleList_C2S({ userId: "59046e2f1126887006", pid: "hoodinn", serverId:2, timestamp: Global.now, verify: "needAmd5", loginType: 1 });
            //     }, this);
            //     this.loginCompleteHandler();
            // } else {
            //     chuanqi.FightController.getInstance().removeAll();
            //     chuanqi.DropItemHelper.getInstance().removeAll();
            //     DmgEffect.dispose();
            //     chuanqi.AIManager.getInstance().clear();
            //     $facade.getProxy(ServiceName.RoleService, (roleService: RoleService) => {
            //         roleService.getRoleList_C2S({ userId: uid, pid: pid, serverId: Core.serverVO.id, timestamp: Global.now, verify: "needAmd5", loginType: 1 });
            //         //  roleService.getRoleList_C2S({ userId: "59046e2f1126887006", pid: "hoodinn", serverId:2, timestamp: Global.now, verify: "needAmd5", loginType: 1 });
            //     }, this);
            //     if (Core.roleDTO) {
            //         $facade.getProxy(ServiceName.RoleService, (roleService: RoleService) => {
            //             roleService.todoLogin(Core.roleDTO);
            //         }, this);
            //     }
            // }

        }



        private loginCompleteHandler() {
            // let facade = $facade;
            // facade.off(lingyu.NetEvent.LOGIN_COMPLETE, this.loginCompleteHandler, this);
            // this.createGameScene();
        }





        // private hero: UnitEntity;
        /**
        * 创建游戏场景
        * Create a game scene
        */
        private createGameScene(): void {

            // Core.start();
            // let $fps = FPSHelp.getInstance();
            // // let facade = $facade;

            // if (DEBUG) {
            //     getSinglon(KeyBoardManage);//键盘事件管理
            //     // new CaculatePanel();
            //     DebugPanel.getInstance();

            // }

            // let target = new NumberStep(1, 10286);

        }



    }
}