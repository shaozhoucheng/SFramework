namespace jy {
    /**
     * 可用于做Key的类型
     */
    export declare type Key = number | string;
}