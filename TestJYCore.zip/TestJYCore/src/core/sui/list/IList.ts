namespace jy {
	/**
	 *
	 * @author 
	 *
	 */
	export interface IList {
    	  getItemViewAt(idx:number):egret.DisplayObject;
	}
}
