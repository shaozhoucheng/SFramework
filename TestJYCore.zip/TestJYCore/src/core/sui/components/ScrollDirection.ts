const enum ScrollDirection {
    Vertical = 0,
    Horizon = 1
}
