namespace jy {
    /**
     * 模块参数
     * 
     * @export
     * @interface ModuleParam
     */
    export interface ModuleParam {

    }
}