namespace jy {
	/**
	 *
	 * @author 
	 *
	 */
	export interface IAsyncPanel extends IAsync, IModulePanel {

	}
}
