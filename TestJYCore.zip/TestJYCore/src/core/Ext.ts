namespace jy {
    /**
     * 扩展名常量
     * @author 3tion
     */
    export const enum Ext {
        JPG = ".jpg",
        PNG = ".png",
        WEBP = ".webp",
        BIN = ".bin",
        JSON = ".json",
    }
}