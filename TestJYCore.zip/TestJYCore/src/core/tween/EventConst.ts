declare namespace jy {

    /**
     * 区段 -1 ~ -19
     * 
     * @export
     * @enum {number}
     */
    export const enum EventConst {
        TWEEN_CHANGE = -1
    }
}