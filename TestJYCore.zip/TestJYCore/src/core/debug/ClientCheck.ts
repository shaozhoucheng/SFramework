namespace jy {
	/**
	 * 客户端检测
	 * @author 3tion
	 *
	 */
	export var ClientCheck = {
    	/**
    	 * 是否做客户端检查
    	 */
		isClientCheck: true
	}
}
