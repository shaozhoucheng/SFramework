declare namespace jy.hqg {
	/**
	 * 由导出工具生成
	 * https://github.com/eos3tion/ExportUIFromFlash
	 * 生成时间：2018-07-19 17:16:36
	 */
	export interface XXPanel extends Panel {
		btn2: Button;
		btn3: Button;
		dis1: XXPanel_dis1;
	}
	/**
	 * 由导出工具生成
	 * https://github.com/eos3tion/ExportUIFromFlash
	 * 生成时间：2018-07-19 17:16:36
	 */
	export interface XXPanel_dis1 extends egret.Sprite {
		txtLabel: egret.TextField;
		btn4: Button;
		btn1: Button;
	}

}