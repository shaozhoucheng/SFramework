namespace jy.hqg {
/**
	 * 由导出工具生成
	 * https://github.com/eos3tion/ExportUIFromFlash
	 * 生成时间：2018-07-19 17:16:36
	 */
	export class XXPanelMediator extends Mediator {
		
	    public $view:XXPanel;
	
	    constructor() {
	        super(jy.xc.ModuleId.Servers);
	    }
	
	    protected init() {

	        let v =  new Panel() as XXPanel;
	        v.bind("lib","ui.test.XXPanel");
	        this.view = v;
	    }

		public awake()
		{
			console.log("i'm in ")
		}
	}
}